/*
 * Copyright 2004 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of Sun Microsystems, Inc.
 * Use is subject to license terms.
 *
 * This is a part of the Squawk JVM.
 */
package com.syn.squawk.arm.test;

/*
 * Class to test the low-level debugger
 */
public class DebugTest {

	public void run() {
		int x;
		do1(11, 12);
		x = do2(13, 14, "hi");
		do3(15, 16);
		do4(17, 18);
	}
	
	public void do1(int a, int b) {
		int c, d;
		c = a + b;
		d = a - b;
		System.out.println("do1-1:" + c);
		System.out.println("do1-2:" + d);
	}
	public int do2(int a, int b, String s) {
		int c, d;
		c = a + b;
		d = a - b;
		System.out.println("do2-1:" + c);
		System.out.println("do2-2:" + d);
		return d;
	}
	public void do3(int a, int b) {
		int c, d;
		c = a + b;
		d = a - b;
		System.out.println("do3-1:" + c);
		System.out.println("do3-2:" + d);
	}
	public void do4(int a, int b) {
		int c, d;
		c = a + b;
		d = a - b;
		System.out.println("do4-1:" + c);
		System.out.println("do4-2:" + d);
	}
}

