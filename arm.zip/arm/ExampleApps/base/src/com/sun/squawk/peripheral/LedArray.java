/*
 * Created on 24-Nov-2004 by jn151271
 *
 */
package com.sun.squawk.peripheral;

import java.io.IOException;

/**
 * @author jn151271
 * 24-Nov-2004
 */
public interface LedArray extends Peripheral {
    public void turnOnAll() throws IOException;
    public void turnOffAll() throws IOException;
    
    public int getLedCount();
    public void turnOn(int ledIndex) throws IOException;
    public void turnOff(int ledIndex) throws IOException;
}
