/*
 * Created on 05-Dec-2004 by jn151271
 *
 */
package com.sun.squawk.peripheral;

import java.util.Hashtable;

/**
 * @author jn151271
 * 05-Dec-2004
 */ 
public class PeripheralSystem {
    public static PeripheralSystem localPeripherals = new PeripheralSystem();
    
    private Hashtable hardwareMap = new Hashtable();
    
    public static void initializeLocalAs(SystemInitialiser anInitialiser) {
        anInitialiser.install(localPeripherals);
    }


    /**
     * @param anInterface
     * @return
     */
    public static Peripheral getLocalPeripheral(Class anInterface) {
        return localPeripherals.getPeripheral(anInterface);
    }
    
    /**
     * @param anInterface
     * @param peripheral
     */
    public void addPeripheral(Class anInterface, Peripheral peripheral) {
        hardwareMap.put(anInterface,peripheral);
    }
    /**
     * @param anInterface
     * @return
     */
    public Peripheral getPeripheral(Class anInterface) {
        return (Peripheral) hardwareMap.get(anInterface);
    }

    
    
}
