/*
 * Created on 04-Dec-2004 by jn151271
 *
 */
package com.sun.squawk.peripheral;

import java.io.IOException;

import com.sun.squawk.vm.ChannelConstants;

/**
 * @author jn151271
 * 04-Dec-2004
 */
public class Register {

    public static void setValue(int address, int mask) throws IOException {
    	if ((address & 3) != 0) {
    		throw new IOException("Attempt to set value in non-word-aligned Register");
    	}
        VM.execIO(ChannelConstants.POKE,0,address,mask,0,0,0,0,null,null);
    }
    
    public static int getValue(int address) throws IOException {
       	if ((address & 3) != 0) {
    		throw new IOException("Attempt to get value from non-word-aligned Register");
    	}
        return VM.execIO(ChannelConstants.PEEK,0,address,0,0,0,0,0,null,null);
    }

}
