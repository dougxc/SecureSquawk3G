/*
 * Created on 04-Dec-2004 by jn151271
 *
 */
package com.sun.squawk.peripheral;

import java.io.IOException;

/**
 * @author jn151271
 * 04-Dec-2004
 */
public interface SwitchArray extends Peripheral{
    public int getSwitchCount();
    public boolean isSwitchOpen(int switchId) throws IOException;
    public boolean isSwitchClosed(int switchId) throws IOException;
    public void waitSwitchClosed(int switchId) throws IOException;
}
