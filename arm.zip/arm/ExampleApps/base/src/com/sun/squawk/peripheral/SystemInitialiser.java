/*
 * Created on 05-Dec-2004 by jn151271
 *
 */
package com.sun.squawk.peripheral;

/**
 * @author jn151271
 * 05-Dec-2004
 */
public interface SystemInitialiser {
    void install(PeripheralSystem theSystem);
}
