/*
 * Copyright 2004 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of Sun Microsystems, Inc.
 * Use is subject to license terms.
 *
 * This is a part of the Squawk JVM.
 */
package com.sun.squawk.peripheral;

import java.io.IOException;

public interface TimerCounter extends Peripheral {
	public abstract void configure(int mask) throws IOException;

	public abstract void enable() throws IOException;

	public abstract int read() throws IOException;

	/**
	 * @return
	 * @throws IOException
	 */
	public abstract int status() throws IOException;
}
