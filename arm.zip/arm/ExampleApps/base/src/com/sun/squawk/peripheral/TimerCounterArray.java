/*
 * Copyright 2004 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of Sun Microsystems, Inc.
 * Use is subject to license terms.
 *
 * This is a part of the Squawk JVM.
 */
package com.sun.squawk.peripheral;

public interface TimerCounterArray extends Peripheral {

	public TimerCounter getTimerCounter(int index);
}
