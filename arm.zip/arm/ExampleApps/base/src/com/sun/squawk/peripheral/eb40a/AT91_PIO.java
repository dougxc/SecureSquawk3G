/*
 * Created on 22-Nov-2004
 *
 */
package com.sun.squawk.peripheral.eb40a;

import java.io.IOException;
import java.util.Vector;

import com.sun.squawk.peripheral.Register;


 
/**
 * @author jn151271
 *  
 */
public class AT91_PIO {
    private static final int BaseAddress = 0xFFFF0000;
	
    int PIO_PER;           /* PIO Enable Register */
    int PIO_PDR;           /* PIO Disable Register */
    int PIO_PSR;           /* PIO Status Register */
    int Reserved0;
    int PIO_OER;           /* Output Enable Register */
    int PIO_ODR;           /* Output Disable Register */
    int PIO_OSR;           /* Output Status Register */
    int Reserved1;
    int PIO_IFER;          /* Input Filter Enable Register */
    int PIO_IFDR;          /* Input Filter Disable Register */
    int PIO_IFSR;          /* Input Filter Status Register */
    int Reserved2;
    int PIO_SODR;          /* Set Output Data Register */
    int PIO_CODR;          /* Clear Output Data Register */
    int PIO_ODSR;          /* Output Data Status Register */
    int PIO_PDSR;          /* Pin Data Status Register */
    int PIO_IER;           /* Interrupt Enable Register */
    int PIO_IDR;           /* Interrupt Disable Register */
    int PIO_IMR;           /* Interrupt Mask Register */
    int PIO_ISR;           /* Interrupt Status Register */
    int PIO_MDER;          /* Multi Driver Enable Register */
    int PIO_MDDR;          /* Multi Driver Disable Register */
    int PIO_MDSR;          /* Multi Driver Status Register */
    

    public static final int SENSE_BIT           = 0x1;
    public static final int OUTPUT              = 0x1;
    public static final int INPUT               = 0x0;
    public static final int FILTER_BIT          = 0x2;
    public static final int FILTER_ON           = 0x2;
    public static final int FILTER_OFF          = 0x0;
    public static final int OPENDRAIN_BIT       = 0x4;
    public static final int OPENDRAIN_ON        = 0x4;
    public static final int OPENDRAIN_OFF       = 0x0;
    public static final int INPUT_IRQ_BIT       = 0x8;
    public static final int INPUT_IRQ_ON        = 0x8;
    public static final int INPUT_IRQ_OFF       = 0x0;
    public static final int RESET_PIO_CONF = (INPUT|FILTER_OFF|OPENDRAIN_OFF|INPUT_IRQ_OFF);

    public static final int SET_OUT         = 0x0;
    public static final int CLEAR_OUT       = 0x1;

    private Vector elements = new Vector();

    private int address;

	public AT91_PIO() {
	    setAddress(BaseAddress);
	}

    /**
     * @param memory address
     */
    private void setAddress(int memoryAddress) {
        address=memoryAddress;
         PIO_PER = address;           /* PIO Enable Register */
         PIO_PDR = address + 4;           /* PIO Disable Register */
         PIO_PSR = address + 8;           /* PIO Status Register */
         Reserved0 = address + 12;
         PIO_OER = address + 16;           /* Output Enable Register */
         PIO_ODR = address + 20;           /* Output Disable Register */
         PIO_OSR = address + 24;           /* Output Status Register */
         Reserved1 = address + 28;
         PIO_IFER = address + 32;          /* Input Filter Enable Register */
         PIO_IFDR = address + 36;          /* Input Filter Disable Register */
         PIO_IFSR = address + 40;          /* Input Filter Status Register */
         Reserved2 = address + 44;
         PIO_SODR = address + 48;          /* Set Output Data Register */
         PIO_CODR = address + 52;          /* Clear Output Data Register */
         PIO_ODSR = address + 56;          /* Output Data Status Register */
         PIO_PDSR = address + 60;          /* Pin Data Status Register */
         PIO_IER = address + 64;           /* Interrupt Enable Register */
         PIO_IDR = address + 68;           /* Interrupt Disable Register */
         PIO_IMR = address + 72;           /* Interrupt Mask Register */
         PIO_ISR = address + 76;           /* Interrupt Status Register */
         PIO_MDER = address + 80;          /* Multi Driver Enable Register */
         PIO_MDDR = address + 84;          /* Multi Driver Disable Register */
         PIO_MDSR = address + 88;          /* Multi Driver Status Register */
    } 

    /**
     * @param mask
     * @param config
     * @throws IOException
     */
    public void open(int mask, int config) throws IOException {
        //System.out.println("AT91_PIO::open("+mask+","+config+")");

        //* If PIOs required to be output
        if ((config & SENSE_BIT) != 0 )
        {
            //* Defines the PIOs as output
            Register.setValue(PIO_OER,mask);
        }
        else
        {
            //* Defines the PIOs as input
            Register.setValue(PIO_ODR,mask) ;
        }

        //* If PIOs required to be filtered
        if ((config & FILTER_BIT) != 0 )
        {
            //* Enable the filter on PIOs
            Register.setValue(PIO_IFER,mask);
        }
        else
        {
            //* Disable the filter on PIOs
            Register.setValue(PIO_IFDR,mask);
        }

        //* If PIOs required to be open-drain
        if ((config & OPENDRAIN_BIT) != 0 )
        {
            //* Enable the filter on PIOs
            Register.setValue(PIO_MDER,mask);
        }
        else
        {
            //* Disable the filter on PIOs
            Register.setValue(PIO_MDSR,mask);
        }

        //TODO Need to figure out interupt stuff
        
//        //* If PIOs required for an input change interrupt
//        if ((config & PIO_INPUT_IRQ_BIT) != 0 )
//        {
//            //* Remove any interrupt */
//            x = pio_pt->pio_base->PIO_ISR ; 
//            //* Enable the Input Change Interrupt on PIOs
//            pio_pt->pio_base->PIO_IER = mask ;
//        }
//        else
//        {
//            //* Disable the Input Change Interrupt on PIOs
//            pio_pt->pio_base->PIO_IDR = mask ;
//        }

        //* Defines the pins to be controlled by PIO Controller
        Register.setValue(PIO_PER,mask);

    }

    /**
     * @param mask
     * @param state
     * @throws IOException
     */
    public void write(int mask, int state) throws IOException {
        //System.out.println("AT91_PIO::write("+mask+","+state+")");
        if (state == CLEAR_OUT )
        {
            //* Clear PIOs with data at 0 in CODR (Clear Output Data Register)
            Register.setValue(PIO_CODR,mask);
        }
        else
        {
            //* Set PIOs with data at 1 in SODR (Set Output Data Register)
            Register.setValue(PIO_SODR,mask);
        }
    }
    
    public int read() throws IOException {
        return Register.getValue(PIO_PDSR);
    }
}