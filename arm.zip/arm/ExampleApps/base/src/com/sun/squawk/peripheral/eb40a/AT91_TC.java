/*
 * Created on 07-Dec-2004
 *
 */
package com.sun.squawk.peripheral.eb40a;

import java.io.IOException;

import com.sun.squawk.peripheral.Register;
import com.sun.squawk.peripheral.TimerCounter;
 
/**
 * @author John Daniels
 * 
 * Timer counter
 *  
 */
public class AT91_TC implements TimerCounter {
	/*------------------------------------*/
	/* Timer Counter Register Definitions */
	/*------------------------------------*/
    private static final int BaseAddress = 0xFFFE0000; // base address for whole timer counter block
 
    // offsets for the registers that operate on the whole block
    private static final int TC_BCR = 0xC0;     /* Block control register */
    private static final int TC_BMR = 0xC4;	    /* Block mode register */
    
    // offsets for base of each timer counter
    private static final int TC_CHAN0 = 0;
    private static final int TC_CHAN1 = 0x40;
    private static final int TC_CHAN2 = 0x80;
    
    private static final int tcBases[]  = {TC_CHAN0, TC_CHAN1, TC_CHAN2};

    // offsets for registers of each timer counter
    private static final int TC_CCR = 0;        /* Control Register */
    private static final int TC_CMR = 4;        /* Mode Register */
    private static final int TC_CVR = 0x10;     /* Counter value */
    private static final int TC_RA  = 0x14;     /* Register A */
    private static final int TC_RB  = 0x18;     /* Register B */
    private static final int TC_RC  = 0x1C;     /* Register C */
    private static final int TC_SR  = 0x20;     /* Status Register */
    private static final int TC_IER = 0x24;     /* Interrupt Enable Register */
    private static final int TC_IDR = 0x28;     /* Interrupt Disable Register */
    private static final int TC_IMR = 0x2C;     /* Interrupt Mask Register */

	/*--------------------------------------------------------*/
	/* TC_CCR: Timer Counter Control Register Bits Definition */
	/*--------------------------------------------------------*/
	public static final int TC_CLKEN            = 0x1;
	public static final int TC_CLKDIS           = 0x2;
	public static final int TC_SWTRG            = 0x4;

	/*---------------------------------------------------------------*/
	/* TC_CMR: Timer Counter Channel Mode Register Bits Definition   */
	/*---------------------------------------------------------------*/

	/*-----------------*/
	/* Clock Selection */
	/*-----------------*/
	public static final int TC_CLKS                  = 0x7;
	public static final int TC_CLKS_MCK2             = 0x0;
	public static final int TC_CLKS_MCK8             = 0x1;
	public static final int TC_CLKS_MCK32            = 0x2;
	public static final int TC_CLKS_MCK128           = 0x3;
	public static final int TC_CLKS_MCK1024          = 0x4;

	public static final int TC_CLKS_XC0              = 0x5;
	public static final int TC_CLKS_XC1              = 0x6;
	public static final int TC_CLKS_XC2              = 0x7;

	/*-----------------*/
	/* Clock Inversion */
	/*-----------------*/
	public static final int TC_CLKI             = 0x8;

	/*------------------------*/
	/* Burst Signal Selection */
	/*------------------------*/
	public static final int TC_BURST            = 0x30;
	public static final int TC_BURST_NONE       = 0x0;
	public static final int TC_BUSRT_XC0        = 0x10;
	public static final int TC_BURST_XC1        = 0x20;
	public static final int TC_BURST_XC2        = 0x30;

	/*------------------------------------------------------*/
	/* Capture Mode : Counter Clock Stopped with RB Loading */
	/*------------------------------------------------------*/
	public static final int TC_LDBSTOP          = 0x40;

	/*-------------------------------------------------------*/
	/* Waveform Mode : Counter Clock Stopped with RC Compare */
	/*-------------------------------------------------------*/
	public static final int TC_CPCSTOP          = 0x40;

	/*-------------------------------------------------------*/
	/* Capture Mode : Counter Clock Disabled with RB Loading */
	/*--------------------------------------------------------*/
	public static final int TC_LDBDIS           = 0x80;

	/*--------------------------------------------------------*/
	/* Waveform Mode : Counter Clock Disabled with RC Compare */
	/*--------------------------------------------------------*/
	public static final int TC_CPCDIS           = 0x80;

	/*------------------------------------------------*/
	/* Capture Mode : External Trigger Edge Selection */
	/*------------------------------------------------*/
	public static final int TC_ETRGEDG                  = 0x300;
	public static final int TC_ETRGEDG_EDGE_NONE        = 0x0;
	public static final int TC_ETRGEDG_RISING_EDGE      = 0x100;
	public static final int TC_ETRGEDG_FALLING_EDGE     = 0x200;
	public static final int TC_ETRGEDG_BOTH_EDGE        = 0x300;

	/*-----------------------------------------------*/
	/* Waveform Mode : External Event Edge Selection */
	/*-----------------------------------------------*/
	public static final int TC_EEVTEDG                  = 0x300;
	public static final int TC_EEVTEDG_EDGE_NONE        = 0x0;
	public static final int TC_EEVTEDG_RISING_EDGE      = 0x100;
	public static final int TC_EEVTEDG_FALLING_EDGE     = 0x200;
	public static final int TC_EEVTEDG_BOTH_EDGE        = 0x300;

	/*--------------------------------------------------------*/
	/* Capture Mode : TIOA or TIOB External Trigger Selection */
	/*--------------------------------------------------------*/
	public static final int TC_ABETRG                   = 0x400;
	public static final int TC_ABETRG_TIOB              = 0x0;
	public static final int TC_ABETRG_TIOA              = 0x400;

	/*------------------------------------------*/
	/* Waveform Mode : External Event Selection */
	/*------------------------------------------*/
	public static final int TC_EEVT                     = 0xC00;
	public static final int TC_EEVT_TIOB                = 0x0;
	public static final int TC_EEVT_XC0                 = 0x400;
	public static final int TC_EEVT_XC1                 = 0x800;
	public static final int TC_EEVT_XC2                 = 0xC00;

	/*--------------------------------------------------*/
	/* Waveform Mode : Enable Trigger on External Event */
	/*--------------------------------------------------*/
	public static final int TC_ENETRG                   = 0x1000;

	/*----------------------------------*/
	/* RC Compare Enable Trigger Enable */
	/*----------------------------------*/
	public static final int TC_CPCTRG                   = 0x4000;

	/*----------------*/
	/* Mode Selection */
	/*----------------*/
	public static final int TC_WAVE                     = 0x8000;
	public static final int TC_CAPT                     = 0x0;

	/*-------------------------------------*/
	/* Capture Mode : RA Loading Selection */
	/*-------------------------------------*/
	public static final int TC_LDRA                     = 0x30000;
	public static final int TC_LDRA_EDGE_NONE           = 0x0;
	public static final int TC_LDRA_RISING_EDGE         = 0x10000;
	public static final int TC_LDRA_FALLING_EDGE        = 0x20000;
	public static final int TC_LDRA_BOTH_EDGE           = 0x30000;

	/*-------------------------------------------*/
	/* Waveform Mode : RA Compare Effect on TIOA */
	/*-------------------------------------------*/
	public static final int TC_ACPA                     = 0x30000;
	public static final int TC_ACPA_OUTPUT_NONE         = 0x0;
	public static final int TC_ACPA_SET_OUTPUT          = 0x10000;
	public static final int TC_ACPA_CLEAR_OUTPUT        = 0x20000;
	public static final int TC_ACPA_TOGGLE_OUTPUT       = 0x30000;

	/*-------------------------------------*/
	/* Capture Mode : RB Loading Selection */
	/*-------------------------------------*/
	public static final int TC_LDRB                     = 0xC0000;
	public static final int TC_LDRB_EDGE_NONE           = 0x0;
	public static final int TC_LDRB_RISING_EDGE         = 0x40000;
	public static final int TC_LDRB_FALLING_EDGE        = 0x80000;
	public static final int TC_LDRB_BOTH_EDGE           = 0xC0000;

	/*-------------------------------------------*/
	/* Waveform Mode : RC Compare Effect on TIOA */
	/*-------------------------------------------*/
	public static final int TC_ACPC                     = 0xC0000;
	public static final int TC_ACPC_OUTPUT_NONE         = 0x0;
	public static final int TC_ACPC_SET_OUTPUT          = 0x40000;
	public static final int TC_ACPC_CLEAR_OUTPUT        = 0x80000;
	public static final int TC_ACPC_TOGGLE_OUTPUT       = 0xC0000;

	/*-----------------------------------------------*/
	/* Waveform Mode : External Event Effect on TIOA */
	/*-----------------------------------------------*/
	public static final int TC_AEEVT                    = 0x300000;
	public static final int TC_AEEVT_OUTPUT_NONE        = 0x0;
	public static final int TC_AEEVT_SET_OUTPUT         = 0x100000;
	public static final int TC_AEEVT_CLEAR_OUTPUT       = 0x200000;
	public static final int TC_AEEVT_TOGGLE_OUTPUT      = 0x300000;

	/*-------------------------------------------------*/
	/* Waveform Mode : Software Trigger Effect on TIOA */
	/*-------------------------------------------------*/
	public static final int TC_ASWTRG                   = 0xC00000;
	public static final int TC_ASWTRG_OUTPUT_NONE       = 0x0;
	public static final int TC_ASWTRG_SET_OUTPUT        = 0x400000;
	public static final int TC_ASWTRG_CLEAR_OUTPUT      = 0x800000;
	public static final int TC_ASWTRG_TOGGLE_OUTPUT     = 0xC00000;

	/*-------------------------------------------*/
	/* Waveform Mode : RB Compare Effect on TIOB */
	/*-------------------------------------------*/
	public static final int TC_BCPB                     = 0x1000000;
	public static final int TC_BCPB_OUTPUT_NONE         = 0x0;
	public static final int TC_BCPB_SET_OUTPUT          = 0x1000000;
	public static final int TC_BCPB_CLEAR_OUTPUT        = 0x2000000;
	public static final int TC_BCPB_TOGGLE_OUTPUT       = 0x3000000;

	/*-------------------------------------------*/
	/* Waveform Mode : RC Compare Effect on TIOB */
	/*-------------------------------------------*/
	public static final int TC_BCPC                     = 0xC000000;
	public static final int TC_BCPC_OUTPUT_NONE         = 0x0;
	public static final int TC_BCPC_SET_OUTPUT          = 0x4000000;
	public static final int TC_BCPC_CLEAR_OUTPUT        = 0x8000000;
	public static final int TC_BCPC_TOGGLE_OUTPUT       = 0xC000000;

	/*-----------------------------------------------*/
	/* Waveform Mode : External Event Effect on TIOB */
	/*-----------------------------------------------*/
	public static final int TC_BEEVT                    = 0x30000000;      //* bit 29-28
	public static final int TC_BEEVT_OUTPUT_NONE        = 0x0;
	public static final int TC_BEEVT_SET_OUTPUT         = 0x10000000;      //* bit 29-28  01
	public static final int TC_BEEVT_CLEAR_OUTPUT       = 0x20000000;      //* bit 29-28  10
	public static final int TC_BEEVT_TOGGLE_OUTPUT      = 0x30000000;      //* bit 29-28  11

	/*- -----------------------------------------------*/
	/* Waveform Mode : Software Trigger Effect on TIOB */
	/*-------------------------------------------------*/
	public static final int TC_BSWTRG                   = 0xC0000000;
	public static final int TC_BSWTRG_OUTPUT_NONE       = 0x0;
	public static final int TC_BSWTRG_SET_OUTPUT        = 0x40000000;
	public static final int TC_BSWTRG_CLEAR_OUTPUT      = 0x80000000;
	public static final int TC_BSWTRG_TOGGLE_OUTPUT     = 0xC0000000;

	/*------------------------------------------------------*/
	/* TC_SR: Timer Counter Status Register Bits Definition */
	/*------------------------------------------------------*/
	public static final int TC_COVFS            = 0x1;         /* Counter Overflow Status */
	public static final int TC_LOVRS            = 0x2;         /* Load Overrun Status */
	public static final int TC_CPAS             = 0x4;         /* RA Compare Status */
	public static final int TC_CPBS             = 0x8;         /* RB Compare Status */
	public static final int TC_CPCS             = 0x10;        /* RC Compare Status */
	public static final int TC_LDRAS            = 0x20;        /* RA Loading Status */
	public static final int TC_LDRBS            = 0x40;        /* RB Loading Status */
	public static final int TC_ETRGS            = 0x80;        /* External Trigger Status */
	public static final int TC_CLKSTA           = 0x10000;     /* Clock Status */
	public static final int TC_MTIOA            = 0x20000;     /* TIOA Mirror */
	public static final int TC_MTIOB            = 0x40000;     /* TIOB Status */

	/*--------------------------------------------------------------*/
	/* TC_BCR: Timer Counter Block Control Register Bits Definition */
	/*--------------------------------------------------------------*/
	public static final int TC_SYNC             = 0x1;         /* Synchronisation Trigger */

	/*------------------------------------------------------------*/
	/*  TC_BMR: Timer Counter Block Mode Register Bits Definition */
	/*------------------------------------------------------------*/
	public static final int TC_TC0xC0S          = 0x3;        /* External Clock Signal 0 Selection */
	public static final int TC_TCLK0xC0         = 0x0;
	public static final int TC_NONEXC0          = 0x1;
	public static final int TC_TIOA1XC0         = 0x2;
	public static final int TC_TIOA2XC0         = 0x3;

	public static final int TC_TC1XC1S          = 0xC;        /* External Clock Signal 1 Selection */
	public static final int TC_TCLK1XC1         = 0x0;
	public static final int TC_NONEXC1          = 0x4;
	public static final int TC_TIOA0xC1         = 0x8;
	public static final int TC_TIOA2XC1         = 0xC;

	public static final int TC_TC2XC2S          = 0x30;       /* External Clock Signal 2 Selection */
	public static final int TC_TCLK2XC2         = 0x0;
	public static final int TC_NONEXC2          = 0x10;
	public static final int TC_TIOA0xC2         = 0x20;
	public static final int TC_TIOA1XC2         = 0x30;

	/* instance variables */
	private int baseAddress;
	
	/**
	 * @param index - the index of the tc to create (0, 1 or 2)
	 */
	public AT91_TC(int index) {
		baseAddress = tcBases[index] + BaseAddress;
	}
	
	public void configure(int mask) throws IOException {
		Register.setValue(baseAddress + TC_CMR, mask);
	}
	
	public void enable() throws IOException {
		Register.setValue(baseAddress + TC_CCR, TC_CLKEN | TC_SWTRG);
	}
	
	public int read() throws IOException {
		return Register.getValue(baseAddress + TC_CVR);
	}

	/* (non-Javadoc)
	 * @see com.sun.squawk.peripheral.TimerCounter#status()
	 */
	public int status() throws IOException {
		return Register.getValue(baseAddress + TC_SR);
	}
}
