/*
 * Copyright 2004 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of Sun Microsystems, Inc.
 * Use is subject to license terms.
 *
 * This is a part of the Squawk JVM.
 */
package com.sun.squawk.peripheral.eb40a;

import com.sun.squawk.peripheral.TimerCounter;
import com.sun.squawk.peripheral.TimerCounterArray;

public class AT91_TC_Array implements TimerCounterArray {

	/* (non-Javadoc)
	 * @see com.sun.squawk.peripheral.TimerCounterArray#getTimerCounter(int)
	 */
	public TimerCounter getTimerCounter(int index) {
		return new AT91_TC(index);
	}

}
