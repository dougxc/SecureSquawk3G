/*
 * Created on 04-Dec-2004 by jn151271
 *
 */
package com.sun.squawk.peripheral.eb40a;

import com.sun.squawk.peripheral.*;

/**
 * @author jn151271
 * 04-Dec-2004
 */
public class EB40A implements SystemInitialiser { 

    public void install(PeripheralSystem theSystem) { 
        AT91_PIO pio = new AT91_PIO();
        theSystem.addPeripheral(LedArray.class,new Leds(pio));
        theSystem.addPeripheral(SwitchArray.class,new Switches(pio));
        theSystem.addPeripheral(TimerCounterArray.class,new AT91_TC_Array());
    }
}
