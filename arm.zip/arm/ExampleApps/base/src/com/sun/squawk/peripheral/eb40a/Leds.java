/*
 * Created on 22-Nov-2004 by jn151271
 *
 */
package com.sun.squawk.peripheral.eb40a;

import java.io.IOException;

import com.sun.squawk.peripheral.LedArray;

/**
 * @author jn151271
 * 22-Nov-2004
 */
public class Leds implements LedArray { 

    private static final int LED1 = 0x10000;
    private static final int LED2 = 0x20000;
    private static final int LED3 = 0x40000;
    private static final int LED4 = 0x80000;
    private static final int LED5 = 0x00008;
    // LEDs 6-8 reserved for VM use
    //private static final int LED6 = 0x00010;
    //private static final int LED7 = 0x00020;
    //private static final int LED8 = 0x00040;
    
    private static final int ON = AT91_PIO.CLEAR_OUT;
    private static final int OFF = AT91_PIO.SET_OUT;
    
    private static final int ALL_LEDS = LED1 | LED2 | LED3 | LED4 | LED5;
    private static final int[] LED_ARRAY = {LED1 , LED2 , LED3 , LED4 , LED5};
    private AT91_PIO pio;

    /**
     * @param pio
     * @throws IOException
     */
    protected Leds(AT91_PIO pio) {
        this.pio = pio;
        try {
            pio.open(ALL_LEDS , AT91_PIO.OUTPUT);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }

    private void maskTurnOn(int led_mask) throws IOException {
        pio.write(led_mask, ON);
    }
    
    private void maskTurnOff(int led_mask) throws IOException {
        pio.write(led_mask, OFF);
    }

    /* (non-Javadoc)
     * @see com.sun.squawk.arm.hardware.LedArray#turnOnAll()
     */
    public void turnOnAll() throws IOException {
        maskTurnOn(ALL_LEDS);
    }

    /* (non-Javadoc)
     * @see com.sun.squawk.arm.hardware.LedArray#turnOffAll()
     */
    public void turnOffAll() throws IOException {
        maskTurnOff(ALL_LEDS);
    }

    /* (non-Javadoc)
     * @see com.sun.squawk.arm.hardware.LedArray#getLedCount()
     */
    public int getLedCount() {
        return LED_ARRAY.length;
    }

    /* (non-Javadoc)
     * @see com.sun.squawk.arm.hardware.LedArray#turnOn(int)
     */
    public void turnOn(int ledIndex) throws IOException {
        maskTurnOn(LED_ARRAY[ledIndex-1]);
    }

    /* (non-Javadoc)
     * @see com.sun.squawk.arm.hardware.LedArray#turnOff(int)
     */
    public void turnOff(int ledIndex) throws IOException {
        maskTurnOff(LED_ARRAY[ledIndex-1]);
    }
}
