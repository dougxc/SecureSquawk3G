/*
 * Created on 04-Dec-2004 by jn151271
 *
 */
package com.sun.squawk.peripheral.eb40a;

import java.io.IOException;

import com.sun.squawk.peripheral.SwitchArray;

/**
 * @author jn151271
 * 04-Dec-2004
 */
public class Switches implements SwitchArray {
    private static final int SWITCH1 = 0x1000;
    private static final int SWITCH2 = 0x0200;
    private static final int SWITCH3 = 0x0002;
    private static final int SWITCH4 = 0x0004;

    private static final int ALL_SWITCHES = SWITCH1 | SWITCH2 | SWITCH3 | SWITCH4;
    private static final int[] SWITCH_ARRAY = {SWITCH1,SWITCH2,SWITCH3,SWITCH4};
    
    private AT91_PIO pio;

    protected Switches(AT91_PIO pio) {
        this.pio = pio;
        try {
            pio.open(ALL_SWITCHES, AT91_PIO.INPUT);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }

    /* (non-Javadoc)
     * @see com.sun.squawk.embedded.SwitchArray#getSwitchCount()
     */
    public int getSwitchCount() {
        return 4;
    }

    /* (non-Javadoc)
     * @see com.sun.squawk.embedded.SwitchArray#isSwitchOpen(int)
     */
    public boolean isSwitchOpen(int switchId) throws IOException  {
        return ((pio.read() & SWITCH_ARRAY[switchId-1]) == SWITCH_ARRAY[switchId-1]);
    }

    /* (non-Javadoc)
     * @see com.sun.squawk.embedded.SwitchArray#isSwitchClosed(int)
     */
    public boolean isSwitchClosed(int switchId) throws IOException {
        return !isSwitchOpen(switchId);
    }

	/* (non-Javadoc)
	 * @see com.sun.squawk.peripheral.SwitchArray#waitSwitchClosed(int)
	 */
	public void waitSwitchClosed(int switchId) throws IOException {
		//TODO this implemention is strictly temporary
		while (isSwitchOpen(switchId)) {
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
			}
		}
	}

}
