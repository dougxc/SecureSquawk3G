/*
 * Created on 22-Nov-2004 by jn151271
 *
 */
package com.sun.squawk.peripheral.test;

import com.sun.squawk.peripheral.LedArray;
import com.sun.squawk.peripheral.PeripheralSystem;
import com.sun.squawk.peripheral.SwitchArray;
import com.sun.squawk.peripheral.eb40a.EB40A;

/**
 * @author jn151271 22-Nov-2004
 */
public class TestSpotHardware {

    public static void main(String[] args) {
        
        try {
            PeripheralSystem.initializeLocalAs(new EB40A());
            //LED tests
            LedArray leds = (LedArray)PeripheralSystem.getLocalPeripheral(LedArray.class);  
            System.out.println("Turning on all LEDs");
            leds.turnOnAll();
            Thread.sleep(1000);
            System.out.println("Turning off all LEDs");
            leds.turnOffAll();
            System.out.println("Running lights");
            int step = 1;
            int ledIndex = 0;
            int ledCount = leds.getLedCount();
            int repeat = 100 * ledCount;
            long start=System.currentTimeMillis();
            for (int j = 0; j < repeat; j++) {
                ledIndex += step;
                if (ledIndex == 1)
                    step = 1;
                if (ledIndex == ledCount)
                    step = -1;
                leds.turnOn(ledIndex);
                leds.turnOff(ledIndex);
            }
            long time=(System.currentTimeMillis()-start);
            System.out.println("Actuation rate = "+(repeat*2*1000/time)+" actuations/sec");
            System.out.println("Turning off all LEDs");
            leds.turnOffAll();
            
            //Switch Tests
            SwitchArray switches = (SwitchArray)PeripheralSystem.getLocalPeripheral(SwitchArray.class);  
            int tries = 1000;
            int switchCount = switches.getSwitchCount();

            System.out.println("Starting switch test...press any switches");
            System.out.println("(LEDs should light to match)");
            start=System.currentTimeMillis();
            for (int i = 0; i < tries; i++) {
                for (int j = 1; j < switchCount+1; j++) {
                    if (switches.isSwitchClosed(j)) 
                        leds.turnOn(j);
                    else
                        leds.turnOff(j);
                }
            }
            time = (System.currentTimeMillis()-start);
            leds.turnOffAll();
            System.out.println("Finished switch test");
            System.out.println((tries*switchCount) +" sample & outputs in "+time+"msec ("+(tries*switchCount*1000/time)+"/sec)");

            System.out.println("Starting switch wait test...press switch 1");
            switches.waitSwitchClosed(1);
            
            leds.turnOffAll();
            System.out.println("Finished switch test");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}