package examples;

import java.util.Random;

import com.sun.squawk.peripheral.LedArray;
import com.sun.squawk.peripheral.PeripheralSystem;
import com.sun.squawk.peripheral.SwitchArray;
import com.sun.squawk.peripheral.TimerCounter;
import com.sun.squawk.peripheral.TimerCounterArray;
import com.sun.squawk.peripheral.eb40a.AT91_TC;
import com.sun.squawk.peripheral.eb40a.EB40A;

/*
 * Copyright 2004 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of Sun Microsystems, Inc.
 * Use is subject to license terms.
 *
 * This is a part of the Squawk JVM.
 */

public class ReactionTimer {

	public static void main(String[] args) {
        try {
            PeripheralSystem.initializeLocalAs(new EB40A());

            LedArray leds = (LedArray)PeripheralSystem.getLocalPeripheral(LedArray.class);  
            SwitchArray switches = (SwitchArray)PeripheralSystem.getLocalPeripheral(SwitchArray.class);  
            TimerCounter tc = ((TimerCounterArray)PeripheralSystem.getLocalPeripheral(TimerCounterArray.class)).getTimerCounter(0);
 
            leds.turnOffAll();

            // each counter tick = 1/64th mSec approx
            tc.configure(AT91_TC.TC_CLKS_MCK1024 | AT91_TC.TC_WAVE);
            tc.enable();
            
            /*
             * get a random duration in range 1 to 5 secs
             * display a "start" sequence
             * wait for random time
             * light an LED
             * reset counter and overflow bit
             * wait for switch
             * snapshot counter
             * check for overflow
             * display time
             */
            int duration, endTime;
            Random myRand = new Random();
            
            // calibrate
            tc.enable();
            tc.status();  // read status to clear overflow bit
            switches.isSwitchClosed(1);
            int minTime = tc.read();

            while (true) {
	            duration = (Math.abs(myRand.nextInt()) % 3000) + 2000;
	            leds.turnOnAll();
	            System.out.println("Press switch 4 to start sequence");
	            System.out.println("Press switch 1 when LED 1 lights");
	            switches.waitSwitchClosed(4);
	            leds.turnOffAll();
	            Thread.sleep(duration);
	            leds.turnOn(1); 
	            tc.enable();  // restart the counter
	            tc.status();  // read status to clear overflow bit
	            while (!switches.isSwitchClosed(1));
	            endTime = tc.read() - minTime;
	            if ((tc.status() & AT91_TC.TC_COVFS) != 0) {
	            	System.out.println("Too slow!");
	            } else {
	            	System.out.println("Your reaction time was " + (endTime / 64) + "mSec");
	            }
            }
          } catch (Exception e) {
            e.printStackTrace();
        }
	}
}
