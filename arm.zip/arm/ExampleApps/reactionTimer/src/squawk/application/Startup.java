/*
 * Copyright 2004 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of Sun Microsystems, Inc.
 * Use is subject to license terms.
 *
 * This is a part of the Squawk JVM.
 */
package squawk.application;

import examples.ReactionTimer;

/*
 * The main method of this class is called by the bootstrap to start the application.
 * 
 * Edit the main method to start your application.
 * 
 */
public class Startup {

	public static void main(String[] args) {
		ReactionTimer.main(args);		
	}
}
