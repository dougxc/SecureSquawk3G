package examples;
import com.sun.squawk.peripheral.LedArray;
import com.sun.squawk.peripheral.PeripheralSystem;
import com.sun.squawk.peripheral.SwitchArray;
import com.sun.squawk.peripheral.eb40a.EB40A;

/*
 * Copyright 2004 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of Sun Microsystems, Inc.
 * Use is subject to license terms.
 *
 * This is a part of the Squawk JVM.
 */

public class SimpleExample {

	public static void main(String[] args) {
        try {
            PeripheralSystem.initializeLocalAs(new EB40A());

            LedArray leds = (LedArray)PeripheralSystem.getLocalPeripheral(LedArray.class);  
            SwitchArray switches = (SwitchArray)PeripheralSystem.getLocalPeripheral(SwitchArray.class);  

            leds.turnOffAll();

            int tries = 1000;
            int switchCount = switches.getSwitchCount();

            System.out.println("Starting simple example...press any switches");
            System.out.println("(LEDs should light to match)");
            for (int i = 0; i < tries; i++) {
                for (int j = 1; j < switchCount+1; j++) {
                    if (switches.isSwitchClosed(j)) 
                        leds.turnOn(j);
                    else
                        leds.turnOff(j);
                }
            }
            leds.turnOffAll();
            System.out.println("Finished simple example");
         } catch (Exception e) {
            e.printStackTrace();
        }
	}
}
