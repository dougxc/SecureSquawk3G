/* Main program for EB40a-flasher
 * 
 * Routine to download a file using XMODEM and flash it to a specified address
 * 
 * Part of the Squawk project
 * 
 */

int flash_addr_index = -1; // provided so that the debugger can set it if required

const unsigned int flash_offsets[3] = {0x100000, 0x140000, 0x1A0000};

int loadAndFlashAt (unsigned int addressOffsetToFlash);
	
//*----------------------------------------------------------------------------
//* Function Name       : main
//*----------------------------------------------------------------------------
int main( void ) {
	int result;
	
	if (flash_addr_index > 2) {
		// it has been changed by the debugger to an invalid value
		printf("--INVALID LOAD ADDRESS INDEX %i\n", flash_addr_index);
		exit(-1);
	}
	if (flash_addr_index < 0) {
		// it hasn't been changed by the debugger
		flash_addr_index = 1; // select the 2nd addr by default
	}
	
	result = loadAndFlashAt (flash_offsets[flash_addr_index]);
	if (result <= 0) {
		iprintf ("--Failed to load and flash\n");
	}
}

