/* EB40a-flasher
 * 
 * Routine to download a file using XMODEM and flash it to a specified address
 * 
 * Part of the Squawk project
 * 
 */

#include 	"parts/r40008/lib_r40008.h"		//* for &PIO_DESC
#include 	"parts/r40008/reg_r40008.h"
#include 	"targets/eb40a/eb40a.h"			//* MCK definition

#include    "drivers/com/com.h"
#include    "periph/aic/lib_aic.h"
#include 	"drivers/flash/lib_flash_at49.h"

#include 	"drivers/xmodem/xmodem.h"

//* --------------------------- Constant definition ---------------------------

#define EBI_BA              0xFFF00000

static char buffer[XMODEM_DATA_SIZE];

//* ------------------------------  Local variable ----------------------------
/* External Interrupt Sources Descriptor */

ComDesc         COM;
ComDesc         *Xmodem_COM;
UsartDesc 		USART_DESCRIPTOR ;

extern FlashAt49BVDef FlashTable[];
//* global value
PioCtrlDesc 	GPIO_DESC ;			   //* Global PIO description to Architecture 40

flash_word 		*FlashBaseAddress;
char   message[80];
unsigned int    flash_size=0x200000;   //* set to 2 Mbyte
FlashAt49BVDef  *flash_type =0;
flash_word 	    type;

//*----------------------------------------------------------------------------
//* Function Name       : int loadAndFlashAt (unsigned int address)
//*
//* The parameter is the offset from the base of the flash at which to 
//* write the data. This will be 0x01xxxxx if we are writing the top half
//* or 0x00xxxxx if we are writing the bottom half. The top half is "our"
//* half if the jumper is STD; the bottom half is our half if the jumper
//* is USER
//*----------------------------------------------------------------------------
int loadAndFlashAt (unsigned int addressOffsetToFlash) {
	unsigned short  cd;
	int loop, result;

    at91_pio_open ( &PIO_DESC, LED_MASK, PIO_OUTPUT ) ;
	at91_pio_write (&PIO_DESC, LED_MASK, LED_OFF ) ;

	FlashBaseAddress = (flash_word *)(EBI_BASE->EBI_CSR[0]&EBI_BA);

	COM.usart= &USART0_DESC;

    //* Set the Xmodem transaction on USART COM
    Xmodem_COM = &COM;

	// check flash
    type = flash_at49_identify( FlashBaseAddress);

    //* Open com
	cd = at91_baud_com(MCK,115200);
    at91_open_com(&COM,(COM_8_BIT|COM_PAR_NONE|COM_NBSTOP_1|COM_FLOW_CONTROL_NONE), cd);

    for (loop=0 ; loop < NB_FLASH_SUPPORTED ; loop ++)
    {
        if ( type == FlashTable[loop].flash_id )
        {
            //at91_print(&COM,FlashTable[loop].flash_name);
            flash_size = FlashTable[loop].flash_size;
            flash_type = &FlashTable[loop];
        }
    }

	FlashBaseAddress += (addressOffsetToFlash / 2); // div by 2 because the base is a word ptr

	at91_pio_write (&PIO_DESC, LED_MASK, LED_ON ) ;

    if (flash_type != 0)
    {
   		flash_at49_init_write( (EBI_BASE->EBI_CSR[0]&EBI_BA),
                               		FlashBaseAddress,
         	                        flash_type);
        result = xmodem_receive(&flash_at49_erase_write_block);
    }
    else
    {
        at91_print(&COM,"Flash not available !\n\r");
        result = 0;
    }

	at91_pio_write (&PIO_DESC, LED_MASK, LED_OFF ) ;
	
	return result;
}

