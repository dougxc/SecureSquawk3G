//*-----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*-----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name               : lib_flash_at49.c
//* Object                  : FLASH programmer for :
//*                             - AT49BV1604/AT49BV1604T
//*                             - AT49BV1614/AT49BV1604T
//*                             - AT49BV8011/AT49BV8011T
//*                             - AT49BV8011/AT49BV8011T
//*
//* 1.1 06/11/00 JPP        : Creation
//* 1.2 08/01/01 JPP        : light version
//* 1.1 29/05/01 JPP        : Adicting FLASH_AT9149BV8192A
//*-----------------------------------------------------------------------------

//* --------------------------- include file ----------------------------------

#include    "periph/stdc/std_c.h"
#include    "lib_flash_at49.h"
#include    "drivers/xmodem/xmodem.h"

//* Static data for AT49
static  flash_word *addr_base;
static  flash_word *addr_load;
static  FlashAt49BVDef *flash;

//* Static Variable for AT49
static  flash_word  *addr_prg_sector ;
static  unsigned int block  ;
static  int         nb_sector  ;
static  int         first ;
static  int         erase  ;

//* --------------------------- Static function -------------------------------
/* Defines supported flash organizations */

const OrgDef OrgAT49BV8011[] =
{
    /* 1 x 16kbytes sectors */
    {
        1,
        16*1024
    },
    /* 1 x 32 kbytes sectors */
    {
        1,
        32*1024,
    },
    /* 4 x 8 kbytes sectors */
    {
        4,
        8*1024,
    },
    /* 1 x 32 kbytes sectors */
    {
        1,
        32*1024,
    },
    /* 1 x 16kbytes sectors */
    {
        1,
        16*1024
    },
    /* 14 x 64 kbytes sectors */
    {
        14,
        64*1024,
    }
};

const OrgDef OrgAT49BV16x4[] =
{
    /* 8 x 8kbytes sectors */
    {
        8,
        8*1024
    },
    /* 2 x 32 kbytes sectors */
    {
        2,
        32*1024,
    },
    /* 30 x 64 kbytes sectors */
    {
        30,
        64*1024,
    }
};

/* Define supported flash Table */
/* Define supported flash Table */
const FlashAt49BVDef FlashTable[NB_FLASH_SUPPORTED] =
{
    {
        1024*1024,                  /* 1 M Bytes */
        "AT49BV8011",
        FLASH_AT49BV8011,
        OrgAT49BV8011,
        sizeof(OrgAT49BV8011)/sizeof(OrgDef)
    },
    {
        2*1024*1024,                /* 2 M Bytes */
        "AT49BV16x4",
        FLASH_AT49BV16x4,
        OrgAT49BV16x4,
        sizeof(OrgAT49BV16x4)/sizeof(OrgDef)
    }

};

//*----------------------------------------------------------------------------
//* Function Name       : flash_at49_identify
//* Object              : Get the device id
//* Input Parameters    : <sart_addr> Flash base address
//* Output Parameters   : device_code or 0xFFFF if bad manuf code
//*----------------------------------------------------------------------------
flash_word flash_at49_identify ( flash_word *base_addr )
//* Begin
{
    flash_word      manuf_code ;
    flash_word      device_code ;

    //* Enter Software Product Identification Mode
    *(base_addr + FLASH_SEQ_ADD1) = FLASH_CODE1;
    *(base_addr + FLASH_SEQ_ADD2) = FLASH_CODE2;
    *(base_addr + FLASH_SEQ_ADD1) = ID_IN_CODE;

    //* Read Manufacturer and device code from the device
    manuf_code  = *base_addr ;
    device_code = *(base_addr + 1) ;

    //* Exit Software Product Identification Mode
    *(base_addr + FLASH_SEQ_ADD1) = FLASH_CODE1;
    *(base_addr + FLASH_SEQ_ADD2) = FLASH_CODE2;
    *(base_addr + FLASH_SEQ_ADD1) = ID_OUT_CODE;

    if ( manuf_code != ATMEL_MANUFACTURED )
    {
        return (FLASH_AT49BV_UNKNOW);
    }

    //* Return pointer to Flash found
    return ( device_code ) ;
}

//*----------------------------------------------------------------------------
//*----------------------------------------------------------------------------
//* Function Name       : flash_wait_flash_ready
//* Object              : wait the end of write
//* Input Parameters    : <address> Adress to write
//*                       <data> data write at the  <address>
//* Output Parameters   : if data write TRUE or FALSE if time out
//*----------------------------------------------------------------------------
int flash_wait_flash_ready ( flash_word *address, flash_word data )
{
//* Begin
    int count = 0 ;

    //* While two consecutive read don't give same value or timeout
    while (( *address != data ) && ( count++ < TIME_OUT )) ;

    //* If timeout
    if ( count < TIME_OUT )
    {
        return ( TRUE ) ;
    }
    //* Else
    else
    {
        return ( FALSE ) ;
    }
    //* Endif
}
//* End
//*----------------------------------------------------------------------------
//* Function Name       : flash_at49_check_sector_erased
//* Object              : check if sector is erased
//* Input Parameters    : <sector_addr> base sector address
//*                       <size> sector size in byte
//* Output Parameters   : if data sector erase TRUE or FALSE
//*----------------------------------------------------------------------------
int flash_at49_check_sector_erased ( flash_word *sector_addr,int size)
//* Begin
{
    int    count ;
    flash_word  read_data ;

    //* For each word of the sector
    for ( count = 0 ; count < (size/2) ; count ++ )
    {
        //* Check erased value reading, if not
        if (( read_data = *(sector_addr + count)) != (flash_word)0xFFFF )
        {
            return ( FALSE ) ;
        }
        //* Endif
    }
    //* Endfor

    //* Return True
    return ( TRUE ) ;
}
//* End

//*----------------------------------------------------------------------------
//* Function Name       : flash_at49_erase_sector
//* Object              : erase flash sector
//* Input Parameters    : <base_addr> Flash base address
//*                       <sector_addr> Flash sector address
//* Output Parameters   : none
//*----------------------------------------------------------------------------
int  flash_at49_erase_sector ( flash_word *base_addr,flash_word *sector_addr)
//* Begin
{

    //* Enter Sector Erase Sequence codes
    *(base_addr + FLASH_SEQ_ADD1) = FLASH_CODE1;
    *(base_addr + FLASH_SEQ_ADD2) = FLASH_CODE2;
    *(base_addr + FLASH_SEQ_ADD1) = ERASE_SECTOR_CODE1;
    *(base_addr + FLASH_SEQ_ADD1) = FLASH_CODE1;
    *(base_addr + FLASH_SEQ_ADD2) = FLASH_CODE2;
    *sector_addr = ERASE_SECTOR_CODE2 ;
    //* Wait for Flash Ready after Erase, if timeout
    if ( flash_wait_flash_ready ( sector_addr, (flash_word)0xFFFF ) == FALSE )
    {
          return(FALSE);
    }

    return(TRUE);
}
//* End

//*----------------------------------------------------------------------------
//* Function Name       : flash_at49_write_flash
//* Object              : Write short in Flash
//* Input Parameters    :
//* Output Parameters   : none
//*----------------------------------------------------------------------------
int flash_at49_write_flash ( flash_word *base_addr,flash_word *load_addr,flash_word data )
{
    flash_word  read_data ;

    //* Enter Programming code sequence
    *(base_addr + FLASH_SEQ_ADD1) = FLASH_CODE1 ;
    *(base_addr + FLASH_SEQ_ADD2) = FLASH_CODE2 ;
    *(base_addr + FLASH_SEQ_ADD1) = WRITE_CODE ;
    *load_addr = data ;

    //* Wait for Flash ready after erasing, if timeout
    if ( flash_wait_flash_ready ( load_addr, data ) != TRUE )
    {
        return ( FALSE ) ;
    }
    //* Endif

    //* If Data written does not equal data
    if (( read_data = *load_addr ) != data )
    {
        //* Return False
        return ( FALSE );
    }
    //* Endif

    //* Return False
    return ( TRUE ) ;
}
//* End

//* --------------------------- Export function -------------------------------
//*----------------------------------------------------------------------------
//* Function Name       : flash_at49_init_write
//* Object              : check if sector is erased if not erase
//* Input Parameters    :
//* Output Parameters   : if data sector erase TRUE or FALSE
//*----------------------------------------------------------------------------
void  flash_at49_init_write ( flash_word *address_base,flash_word *address_load,FlashAt49BVDef *flash_type)
//* Begin
{
        addr_prg_sector = address_base ;
        addr_base = address_base ;
        addr_load= address_load;
        block = 0 ;
        nb_sector = 0 ;

        first = TRUE ;
        erase = FALSE ;
        flash=flash_type;
}
//*----------------------------------------------------------------------------
//* Function Name       : erase_sector
//* Object              : check if sector is erased if not erase
//* Input Parameters    : <base_addr> Flash base address
//*                       <sector_addr> base sector address
//*                       <size> sector size in byte
//* Output Parameters   : if data sector erase TRUE or FALSE
//*----------------------------------------------------------------------------
static int erase_sector ( flash_word *base_addr,flash_word *sector_addr,int size )
//* Begin
{
    int     trial = 0 ;
    //* While flash is not erased or too much erasing performed
    while (( flash_at49_check_sector_erased ( sector_addr, size ) == FALSE ) &&
           ( trial++ < NB_TRIAL_ERASE ))
    {
        if ( flash_at49_erase_sector(base_addr,sector_addr)  == FALSE )
        {
            //* return False
            return ( FALSE ) ;
        } //* Endif
    }//* EndWhile

    //* Return True
    return ( TRUE ) ;
}
//* End

//*----------------------------------------------------------------------------
//* Function Name       : flash_at49_erase_write_block
//* Object              : check if sector is erased if not erase erase and write
//* Input Parameters    : <buffer> data block addressFlash
//*                       <size> sector size in byte
//* Output Parameters   : if data sector erase TRUE or FALSE
//*----------------------------------------------------------------------------
int flash_at49_erase_write_block ( u_char *buffer,int size)
//* Begin

{
    unsigned short  data ;
    unsigned int    count;
    int         sector_found ;
    int         change_sector ;

    //* For each word read from the file
    for  ( count =0 ; count < size ; count +=2 )
    {
        //data = buffer[count];
         data =  (unsigned short) buffer[count]| (unsigned short)buffer[count+1]  << 8 ;
        //* Clear sector found flag
        sector_found = FALSE ;
        //* Clear Sector change flag
        change_sector = FALSE ;
        //* While sector not found
        while ( sector_found == FALSE )
        {
            //* If program address lower than current sector address + its size
            if (( addr_prg_sector + (flash->flash_org[block].sector_size/2) )
                > addr_load )
            {
                //* Flag sector found
                sector_found = TRUE ;
            }
            //* Else
            else
            {
                //* Flag sector change
                change_sector = TRUE ;
                //* Add current sector size to program address
                addr_prg_sector += (flash->flash_org[block].sector_size/2) ;

                //* Increment the sector number
                nb_sector++ ;
                //* If last sector in block tested
                if ( nb_sector >= flash->flash_org[block].sector_number )
                {
                    //* Re-initialize sector number in block
                    nb_sector = 0 ;
                    //* Increment block number
                    block ++ ;
                    //* If last block tested
                    if ( block >= flash->flash_block_nb )
                    {
                        //*  Error Address not found in the Flash Address Field Return False
                        return ( FALSE ) ;
                    }
                    //* Endif
                }
                //* Endif
            }
            //* EndIf
        }
        //* EndWhile

        //* Unflag Erasing
        erase = FALSE ;
        //* If new sector or first sector
        if (( change_sector == TRUE ) || ( first == TRUE ))
        {
            //* Flag Erasing
            erase = TRUE ;
        }
        //* Endif

        //* If Erasing flagged
        if ( erase == TRUE )
        {
            //* Erase, if Timeout
            if ( erase_sector ( addr_base,
                                addr_prg_sector,
                                flash->flash_org[block].sector_size) != TRUE )
            {
                //* Return False
                return ( FALSE ) ;
            }
            //* Endif
        }
        //* Endif


        //* Write the value read in Flash, if error
        if ( flash_at49_write_flash ( addr_base,addr_load, data )!= TRUE )
        {
            //* Return False
            return ( FALSE ) ;
        }
        //* Endif

        //* Increment load address
        addr_load ++ ;

        //* Remove first address to program flag
        first = FALSE ;
    }
    //* EndWhile

    //* Return result
    return (TRUE) ;
}
//* End

