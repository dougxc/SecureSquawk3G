//*----------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*----------------------------------------------------------------------------
//* File Name           : xmodem.h
//* Object              : Xmodem description file
//*						  Use conditional assembly with ARMSDT for ARM SDT
//*
//* 1.0 14/11/00 JPP    : Creation
//* 1.1 30/05/00 JPP    : Clean for AT91 CDROM
//*----------------------------------------------------------------------------

#ifndef xmodem_h
#define xmodem_h
/*-----------------------  General Constants definition ---------------------*/

 #include "periph/stdc/std_c.h"
//* --------------------------- Constant definition ---------------------------

//* time loop depending for wait sate, MCKI, and compilation flag
 #define WAIT_1S    100000
 #define WAIT_2S    (WAIT_1S*2)
 #define WAIT_3S    (WAIT_1S*8)

/*---------------------------  Constants definition -------------------------*/
/* Control Characters */
#define SOH         0x01            /* Start of Heading */
#define EOT         0x04            /* End of transmission */
#define ACK         0x06            /* Acknowledge */
#define NAK         0x15            /* Negative Acknowledge */

#define CRCCHR      'C'

#define FULL        TRUE
#define EMPTY       FALSE

#define OK          TRUE
#define NOK         FALSE

#define CRC16POLY   0x1021              /* CRC 16  polynom */

#define XMODEM_DATA_SIZE    128         /* data 128 */
#define XMODEM_FRAME_SIZE   (3+XMODEM_DATA_SIZE+2)   /* Header 3, data 128, CRC 2 */

#define NB_FRAME	3
/*---------------------------  Structure definition -------------------------*/

// Xmodem frame structure
#ifdef ARMSDT
typedef __packed struct XmodemFrame
{
    unsigned char   Header ;
    unsigned char   packet ;
    unsigned char   packet_crc ;
    unsigned char   data[XMODEM_DATA_SIZE];
    unsigned char   crc_lsb;
    unsigned char   crc_msb;

} XmodemFrame ;
#else
#ifdef ARM_ELF_GCC

typedef   struct XmodemFrame
{
    unsigned char   Header  ;
    unsigned char   packet 		__attribute__ ((packed)) ;
    unsigned char   packet_crc  __attribute__ ((packed)) ;
    unsigned char   data[XMODEM_DATA_SIZE] __attribute__ ((packed));
    unsigned char   crc_lsb		__attribute__ ((packed));
    unsigned char   crc_msb 	__attribute__ ((packed));

} XmodemFrame ;

#else

#pragma pack
typedef struct XmodemFrame
{
    unsigned char   Header ;
    unsigned char   packet ;
    unsigned char   packet_crc ;
    unsigned char   data[XMODEM_DATA_SIZE];
    unsigned char   crc_lsb;
    unsigned char   crc_msb;

} XmodemFrame ;

#endif /* ARM_ELF_GCC */

#endif /* ARMSDT */
/*---------------------------  Function Prototyping -------------------------*/

extern int xmodem_receive(int (*write_function)(u_char *ptr_data,int size));
extern int xmodem_transmit_function(void (*read_function)(int address,char *ptr_data,int size),u_int len);
extern int xmodem_transmit(u_char *bufptr,u_int len);

#endif /* xmodem_h */
