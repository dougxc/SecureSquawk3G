//*----------------------------------------------------------------------------
//*         ATMEL Microcontroller Software Support  -  ROUSSET  -
//*----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*----------------------------------------------------------------------------
//* File Name           : lib_r40008.c
//* Object              : AT91r40008 Descriptor File.
//*
//* 1.0 06/08/01  PF    : Creation
//*----------------------------------------------------------------------------

#include    "lib_r40008.h"

/*-----------------*/
/* PIO Controllers */
/*-----------------*/

/* Instantiate PIO Controllers Pointers */
const StructPIO *Pio   = PIO_BASE ;

/* PIO Controller Descriptor */
const PioCtrlDesc PIO_DESC =
{
    PIO_BASE,
    PIO_ID,
    NB_PIO
} ;


/*-------------------------------*/
/* Advanced Interrupt Controller */
/*-------------------------------*/

/* IRQ0 Descriptor */
const ExtIrqDesc    IRQ0_DESC =
{
    &PIO_DESC,
    IRQ0_ID,
    PIOIRQ0
} ;

/* IRQ1 Descriptor */
const ExtIrqDesc    IRQ1_DESC =
{
    &PIO_DESC,
    IRQ1_ID,
    PIOIRQ1
} ;

/* IRQ2 Descriptor */
const ExtIrqDesc    IRQ2_DESC =
{
    &PIO_DESC,
    IRQ2_ID,
    PIOIRQ2
} ;


/* FIQ Descriptor */
const ExtIrqDesc    FIQ_DESC =
{
    &PIO_DESC,
    FIQ_ID,
    PIOFIQ,
} ;

/*-------*/
/* USART */
/*-------*/

/* Usart 0 Descriptor */
const UsartDesc USART0_DESC =
{
    USART0_BASE,
    &PIO_DESC,
    PIORXD0,
    PIOTXD0,
    PIOSCK0,
    US0_ID ,
} ;

/* Usart 1 Descriptor */
const UsartDesc USART1_DESC =
{
    USART1_BASE ,
    &PIO_DESC,
    PIORXD1,
    PIOTXD1,
    PIOSCK1,
    US1_ID ,
} ;


/*------------------------*/
/* Timer Counter Channels */
/*------------------------*/

/* Timer Counter Channel 0 Descriptor */
const TCDesc TC0_DESC =
{
    TC0_BASE,
    &PIO_DESC,
    TC0_ID,
    PIOTIOA0,
    PIOTIOB0,
    PIOTCLK0
} ;

/* Timer Counter Channel 1 Descriptor */
const TCDesc TC1_DESC =
{
    TC1_BASE,
    &PIO_DESC,
    TC1_ID,
    PIOTIOA1,
    PIOTIOB1,
    PIOTCLK1
} ;

/* Timer Counter Channel 2 Descriptor */
const TCDesc TC2_DESC =
{
    TC2_BASE,
    &PIO_DESC,
    TC2_ID,
    PIOTIOA2,
    PIOTIOB2,
    PIOTCLK2
} ;

/* Timer Counter Block Descriptor */
const TCBlockDesc TCB_DESC =
{
    &TC0_DESC,
    &TC1_DESC,
    &TC2_DESC,
} ;

/* WatchDog Descriptor */
