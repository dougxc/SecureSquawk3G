//*---------------------------------------------------------------------------
//*         ATMEL Microcontroller Software Support  -  ROUSSET  -
//*---------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*-----------------------------------------------------------------------------
//* File Name           : lib_r40008.h
//* Object              : AT91r40008 Definition File
//*
//* 1.0 06/08/01  PF    : Creation
//*---------------------------------------------------------------------------

#ifndef lib_r40008_h
#define lib_r40008_h

#include    "parts/r40008/r40008.h"

/*----------------------------*/
/* Special Function Registers */
/*----------------------------*/
#include    "periph/special_function/lib_sf.h"

/*------------------------*/
/* External Bus Interface */
/*------------------------*/
#include    "periph/ebi/lib_ebi.h"

/*--------------------------*/
/* Power Saving Controller  */
/*--------------------------*/
#include    "periph/power_saving/lib_power_save.h"

/*-------------------------------*/
/* Advanced Interrupt Controller */
/*-------------------------------*/

#include    "periph/aic/lib_aic.h"
#include    "periph/aic/ext_irq/lib_ext_irq.h"

/* Descriptor */
extern const ExtIrqDesc     IRQ0_DESC ;  /* IRQ0 Descriptor */
extern const ExtIrqDesc     IRQ1_DESC ;  /* IRQ1 Descriptor */
extern const ExtIrqDesc     IRQ2_DESC ;  /* IRQ2 Descriptor */
extern const ExtIrqDesc     FIQ_DESC ;   /* FIQ Descriptor */

/*-------------------------*/
/* Parallel I/O Controller */
/*-------------------------*/
#include    "periph/pio/lib_pio.h"

/* Descriptor */
extern const PioCtrlDesc PIO_DESC ;         /* PIO Controller Descriptor */

/*--------*/
/* USARTs */
/*--------*/
/* Definition file */
#include    "periph/usart/lib_usart.h"

/* USART descriptor */
extern const UsartDesc USART0_DESC ;        /* USART 0 Descriptor */
extern const UsartDesc USART1_DESC ;        /* USART 1 Descriptor */


/*----------*/
/* Watchdog */
/*----------*/
/* Definition file */
//#include    "periph/watchdog/lib_wd.h"

/* Descriptor */
//extern const WDDesc WD_DESC ;        /* Watchdog descriptor */

/*---------------*/
/* Timer Counter */
/*---------------*/
#include    "periph/timer_counter/lib_tc.h"


/* Descriptor */
extern const TCDesc TC0_DESC ;          /* Timer Counter Channel 0 Descriptor */
extern const TCDesc TC1_DESC ;          /* Timer Counter Channel 2 Descriptor */
extern const TCDesc TC2_DESC ;          /* Timer Counter Channel 2 Descriptor */

extern const TCBlockDesc TCB_DESC ;     /* Timer Counter Block Descriptor */

#endif /* lib_r40008_h */
