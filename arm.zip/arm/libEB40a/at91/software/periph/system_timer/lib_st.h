//*--------------------------------------------------------------------------------------
//*         ATMEL Microcontroller Software Support  -  ROUSSET  -
//*--------------------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*--------------------------------------------------------------------------------------
//* File Name           : lib_st.h
//* Object              : System Timer Function Prototyping.
//*
//* 1.0 23/05/00  PFi   : Creation
//* 1.1 14/02/02  PFi   : New function has been added. See /* New */
//* 1.2 18/02/02  PFi   : #define ST_BASE ((StructST *) 0xFFFF8000) has been removed
//*                     : and has been added in the m42800.h file.
//*--------------------------------------------------------------------------------------

#ifndef lib_st_h
#define lib_st_h

#include    "periph/system_timer/st.h"
#include    "periph/aic/lib_aic.h"
#include    "periph/stdc/lib_err.h"

/*-----------------------------------------------*/
/* System Timer Descriptor Structure Definition  */
/*----*------------------------------------------*/
typedef struct
{
    StructST        *st_base ;          /* Peripheral base address */
    TypeAICHandler  *AsmSTHandler ;     /* Assembly interrupt handler */
    u_char          PeriphId ;          /* Peripheral Identifier */
} STDesc ;


/* System Timer Interrupt Handler (written in assembly) */
extern void at91_st_irq_asm_handler ( void ) ;

extern void at91_st_irq_c_handler (void) ;

/* Function Prototyping */
/* General Function */
extern u_int at91_st_get_status ( const STDesc *st_pt ) ;
extern void at91_st_enable_interrupt ( const STDesc *st_pt, u_int irq, TypeAICHandler *AsmSTHandler) ;
extern void at91_st_disable_interrupt ( const STDesc *st_pt, u_int irq ) ;

/* Watchdog Timer functions */
extern void at91_st_wd_mode ( const STDesc *st_pt, u_int wd_mode ) ;
extern void at91_st_wd_rearm ( const STDesc *st_pt ) ;

/* Real Time Timer functions */ /* New */
extern void at91_st_set_prescaler ( const STDesc *st_pt, u_short pres ) ;
extern u_int at91_st_get_prescaler ( const STDesc *st_pt ) ;
extern u_int at91_st_get_rtt_value ( const STDesc *st_pt ) ;


/* Period Interval Timer functions */ /* New */
extern void at91_st_set_piv ( const STDesc *st_pt, u_short piv ) ;
extern u_int at91_st_get_piv ( const STDesc *st_pt ) ;

void at91_st_set_almv ( const STDesc *st_pt, u_short almv ) ;
u_int at91_st_get_almv ( const STDesc *st_pt ) ;

#endif /* lib_st_h */