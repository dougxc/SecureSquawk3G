// Watchdog timer

#include "periph/wd/wd.h"

#include "periph/aic/lib_aic.h"

// watchdog timer register addresses
#define WD_BASE 0xFFFF8000
#define WD_OMR  (WD_BASE + 0x0) // Set overflow mode in here
#define WD_CMR  (WD_BASE + 0x4) // Set clock mode in here
#define WD_CR   (WD_BASE + 0x8) // Write to this to reset counter
#define WD_SR   (WD_BASE + 0xC) // Read this to see if overflow has occured

// WD_OMR bits
// the WD_OMR_KEY is the special pattern that must be written in WD_OMR
// to permit writing to this register
#define WD_OMR_KEY		0x2340
#define WD_OMR_WDEN		1		// enable
#define WD_OMR_IRQEN	4		// enable IRQ

// WD_CMR bits
// the WD_CMR_KEY is the special pattern that must be written in WD_CMR
// to permit writing to this register
#define WD_CMR_KEY            0x3700
#define WD_CMR_WDCLKS_MCK8    0
#define WD_CMR_WDCLKS_MCK32   1
#define WD_CMR_WDCLKS_MCK128  2
#define WD_CMR_WDCLKS_MCK1024 3
#define WD_CMR_HPCV_ALL_BITS  0x3C // init counter with all upper bits set
#define WD_CMR_HPCV_VAL4_BITS  0x10 // init counter with upper bits set to 4
#define WD_CMR_HPCV_VAL9_BITS  0x24 // init counter with upper bits set to 9

// WD_CR bits
// the WD_CR_RESTART_KEY is the special pattern that must be written in WD_CR
// to reset the timer
#define WD_CR_RESTART_KEY     0xC071

// WD_SR bits
#define WD_SR_OVF     1

// Interrupt source number for watchdog
#define WD_INT_SRC    7

#ifdef AIC_BASE
#undef AIC_BASE
#endif

#define AIC_BASE	0xFFFFF000
#define AIC_SMR		(AIC_BASE + 0x0)
#define AIC_ISR		(AIC_BASE + 0x108)
#define AIC_IPR		(AIC_BASE + 0x10C)
#define AIC_ICCR	(AIC_BASE + 0x128)

#define AIC_SMR_SOURCETYPE_INT_EDGE 0x20
#define AIC_SMR_PRI_7				0x7
#define AIC_SMR_PRI_1				0x1

unsigned int clock_counter = 0;

extern void wd_int_hndl();

void init_watchdog_timer() {
	volatile u_int * regPtr;

	// initialise the timer
	regPtr = (u_int*) WD_CMR;
	*regPtr = WD_CMR_KEY | WD_CMR_HPCV_VAL9_BITS | WD_CMR_WDCLKS_MCK32;
	if (*regPtr != (WD_CMR_HPCV_VAL9_BITS | WD_CMR_WDCLKS_MCK32)) {
		printf("Failed to write WD_CMR\n");
	}
	regPtr = (u_int*) WD_CR;
	*regPtr = WD_CR_RESTART_KEY;
	regPtr = (u_int*) WD_OMR;
	*regPtr = WD_OMR_KEY | WD_OMR_WDEN | WD_OMR_IRQEN; // enable
	if (*regPtr != (WD_OMR_WDEN | WD_OMR_IRQEN)) {
		printf("Failed to write WD_OMR\n");
	}
	// timer should now be running

	// set up interrupt
	at91_irq_open ( WD_INT_SRC,
                    AIC_SMR_PRI_7,					// priority
                    AIC_SMR_SOURCETYPE_INT_EDGE,	// edge triggered
                    &wd_int_hndl);
}

void restart_watchdog_interrupt() {
	// set up interrupt
	at91_irq_open ( WD_INT_SRC,
                    AIC_SMR_PRI_7,					// priority
                    AIC_SMR_SOURCETYPE_INT_EDGE,	// edge triggered
                    &wd_int_hndl);
}

long long getMilliseconds() {
	return ((long long)clock_counter * 1000000000LL) / CLOCK_TICKS_PER_MILLION_SECS;
}
