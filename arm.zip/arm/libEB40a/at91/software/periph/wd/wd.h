// DEFINITIONS FOR SYSTEM TIMER

// you can't change this unless you also change init_watchdog_timer to suit
#define CLOCK_TICKS_PER_MILLION_SECS 50355233

long long getMilliseconds();

