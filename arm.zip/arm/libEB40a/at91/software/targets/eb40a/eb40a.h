//*----------------------------------------------------------------------------
//*         ATMEL Microcontroller Software Support  -  ROUSSET  -
//*----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*----------------------------------------------------------------------------
//* File Name           : eb40a.h
//* Object              : AT91R40008 Evaluation Board Features Definition File.
//*
//* 1.0 23/05/00  PF    : Creation
//*----------------------------------------------------------------------------
#ifndef eb40a_h
#define eb40a_h

#include    "parts/r40008/r40008.h"      /* library definition */


/*----------------------------------------*/
/* AT91EB40a External Memories Definition */
/*----------------------------------------*/

/* Flash Memory : AT49BV1614 1M*16 */
#define FLASH_BASE      ((u_int *)0x01000000)
#define FLASH_SIZE      (2*1024*1024)                /* byte */

/* SRAM : size is depending on devices fitted on the board */
#define EXT_SRAM_BASE           ((u_int *)0x02000000)
#define EXT_SRAM_DEFAULT_SIZE   (256*1024)
#define EXT_SRAM_LIMIT  (EXT_SRAM_BASE+EXT_SRAM_SIZE)

/*---------------------------------------------------------------------------*/
/* EBI Initialization Data                                                   */
/*---------------------------------------------------------------------------*/
/* The EBI User Interface Image which is copied by the boot.                 */
/* 25 MHz master clock assumed.                                           */
/* That's hardware! Details in the Electrical Datasheet of the AT91 device.  */
/* EBI Base Address is added at the end for commodity in copy code.          */
/*---------------------------------------------------------------------------*/
#define EBI_CSR_0       ((u_int *)(FLASH_BASE | 0x2539)    /* 0x01000000, 16MB, 2 tdf, 16 bits, 2 WS  */
#define EBI_CSR_1       ((u_int *)(EXT_SRAM_BASE | 0x2121) /* 0x02000000, 16MB, 0 hold, 16 bits, 1 WS */
#define EBI_CSR_2       ((u_int *)0x20000000)       /* unused */
#define EBI_CSR_3       ((u_int *)0x30000000)       /* unused */
#define EBI_CSR_4       ((u_int *)0x40000000)       /* unused */
#define EBI_CSR_5       ((u_int *)0x50000000)       /* unused */
#define EBI_CSR_6       ((u_int *)0x60000000)       /* unused */
#define EBI_CSR_7       ((u_int *)0x70000000)       /* unused */

/*-----------------*/
/* Leds Definition */
/*-----------------*/
#define LED1            P16
#define LED2            P17
#define LED3            P18
#define LED4            P19
#define LED5            P3
#define LED6            P4
#define LED7            P5
#define LED8            P6

#define LED_PIO_CTRL    1
#define LED_MASK        (LED1|LED2|LED3|LED4|LED5|LED6|LED7|LED8)

#define LED_ON          PIO_CLEAR_OUT
#define LED_OFF         PIO_SET_OUT

/*-------------------------*/
/* Push Buttons Definition */
/*-------------------------*/
#define SW1_MASK        (1<<12)
#define SW2_MASK        (1<<9)
#define SW3_MASK        (1<<1)
#define SW4_MASK        (1<<2)
#define SW_MASK         (SW1_MASK|SW2_MASK|SW3_MASK|SW4_MASK)

#define SW1             (1<<12)
#define SW2             (1<<9)
#define SW3             (1<<1)
#define SW4             (1<<2)

#define PIO_SW1         (1<<12)
#define PIO_SW2         (1<<9)
#define PIO_SW3         (1<<1)
#define PIO_SW4         (1<<2)

/*--------------------------*/
/* Serial EEPROM Definition */
/*--------------------------*/

#define SCL             (1<<8)
#define SDA             (1<<7)
#define PIO_SCL         (1<<8)
#define PIO_SDA         (1<<7)


/*--------------*/
/* Master Clock */
/*--------------*/

#define MCK             66000000
#define MCKKHz          (MCK/1000)

#endif /* eb40a_h */
