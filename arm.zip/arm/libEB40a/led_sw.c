
#include "periph/pio/lib_pio.h"
#include "targets/eb40a/eb40a.h"

/* Instantiate PIO Controllers Pointers */
//const StructPIO *Pio   = PIO_BASE ;

/* PIO Controller Descriptor */
extern const PioCtrlDesc PIO_DESC;

void configure_leds_and_sws ( void )
{
    //* define led at PIO output
    at91_pio_open ( &PIO_DESC, LED_MASK, PIO_OUTPUT );

    //* define switch at PIO input
    at91_pio_open ( &PIO_DESC, SW_MASK, PIO_INPUT );
}

void turn_off_all_leds (void)
{
	at91_pio_write ( &PIO_DESC, LED1 | LED2 | LED3 | LED4 | LED5 | LED6 | LED7 | LED8, LED_OFF );
}

u_int convertJavaSwMaskToCMask (u_int jmask) {
	u_int result = 0;
	if (jmask & 1) result = result | SW1;
	if (jmask & 2) result = result | SW2;
	if (jmask & 4) result = result | SW3;
	if (jmask & 8) result = result | SW4;
	return result;
}

int sw_is_pressed (u_int switch_mask)
{
	int cMask = convertJavaSwMaskToCMask(switch_mask);
	return (~at91_pio_read (&PIO_DESC) & cMask ) == cMask;
}

u_int convertJavaLEDMaskToCMask (u_int jmask) {
	u_int result = 0;
	if (jmask & 1) result = result | LED1;
	if (jmask & 2) result = result | LED2;
	if (jmask & 4) result = result | LED3;
	if (jmask & 8) result = result | LED4;
	if (jmask & 16) result = result | LED5;
	if (jmask & 32) result = result | LED6;
	if (jmask & 64) result = result | LED7;
	if (jmask & 128) result = result | LED8;
	return result;
}

void turn_on_leds (u_int leds)
{
		at91_pio_write ( &PIO_DESC, convertJavaLEDMaskToCMask(leds) & LED_MASK, LED_ON );
}

void turn_off_leds (u_int leds)
{
        at91_pio_write ( &PIO_DESC, convertJavaLEDMaskToCMask(leds) & LED_MASK, LED_OFF );
}
