#include	"stdio.h"
#include	"sys/time.h"

#include 	"parts/r40008/lib_r40008.h"		//* for &PIO_DESC
#include 	"parts/r40008/reg_r40008.h"
#include 	"targets/eb40a/eb40a.h"			//* MCK definition

#include    "drivers/com/com.h"
#include    "periph/aic/lib_aic.h"
#include 	"drivers/flash/lib_flash_at49.h"

#include 	"drivers/xmodem/xmodem.h"

#include	"periph/wd/wd.h"

ComDesc         *Xmodem_COM;

extern char __stack_end;
extern char __bss_end;
extern int	clock_counter;

extern u_int get_cpsr();
extern u_int get_aic_imr();
extern u_int get_aic_ipr();
extern u_int peek(u_int);
	

void runMallocTest();
void runTimerTest();
void runTimeOfDayTest();
void runTimeCalibrationTest();
void runInputTest();

int main(int argc, char *argv[]) {
	//printf("cpsr = 0x%x; imr = 0x%x; ipr = 0x%x\n", get_cpsr(), get_aic_imr(), get_aic_ipr());
	//printf("0x18 = 0x%x\n", peek(0x18));
	//printf("0x18+0x20 = 0x%x\n", peek(0x18+0x20));
	init_watchdog_timer();
	
	//runMallocTest();
	//runTimerTest();
	//runTimeOfDayTest();
	//runTimeCalibrationTest();
	//xmodemtest();
	runInputTest();
	
	return 0;
}

void runInputTest() {
	
	printf("Starting input test\n");
	printf("Echoing 10 characters using low level routines\n");
	char buf[100];
	int i, count;
	for (i = 0; i < 10; i++) {
		do {count = _read(0, &buf, 1);} while (count < 1);
		if (count != 1) {
			printf("FAILED: read count not 1\n");
			break;
		}
		count = _write(1, &buf, 1);
	}	
	printf("finished low level input test\n");

	printf("Testing input buffer - enter 5 characters\n");
	long long start = getMilliseconds();
	// wait
	while (getMilliseconds() - start < 8000);
	count = _read(0, &buf, 5);
	if (count != 5) {
		printf("FAILED: read count was %i not 5\n", count);
	}
	printf("finished input buffer test\n");

	printf("Testing fgets - enter a string terminiting with ctrl-j\n");
	fgets(buf, 100, stdin);
	printf("Length: %i Data: %s", strlen(buf), buf);
	printf("finished input test\n");
}
	
void runTimeCalibrationTest() {

	printf ("Waiting for 10 secs\n");
	long long start = getMilliseconds();
	long long finish = start + 10000;
	
	while (getMilliseconds() < finish);
	
	printf ("Done!\n");
}

void runTimeOfDayTest() {
	struct timeval tv;
	long long count = 0;
    gettimeofday(&tv, NULL);
    printf("Got time - secs: %i usecs: %i\n", tv.tv_sec, tv.tv_usec);
	while (count < 1000000) {
    	//printf("Got time - secs: %i usecs: %i\n", tv.tv_sec, tv.tv_usec);
		count++;
	}
    gettimeofday(&tv, NULL);
    printf("Got time - secs: %i usecs: %i\n", tv.tv_sec, tv.tv_usec);
	count = 0;
	while (count < 1000000) {
		count++;
	}
    gettimeofday(&tv, NULL);
    printf("Got time - secs: %i usecs: %i\n", tv.tv_sec, tv.tv_usec);
	count = 0;
	while (count < 1000000) {
		count++;
	}
    gettimeofday(&tv, NULL);
    printf("Got time - secs: %i usecs: %i\n", tv.tv_sec, tv.tv_usec);
	count = 0;
	while (count < 1000000) {
		count++;
	}
    gettimeofday(&tv, NULL);
    printf("Got time - secs: %i usecs: %i\n", tv.tv_sec, tv.tv_usec);
	count = 0;
	while (count < 1000000) {
		count++;
	}
    gettimeofday(&tv, NULL);
    printf("Got time - secs: %i usecs: %i\n", tv.tv_sec, tv.tv_usec);
	count = 0;
	while (count < 1000000) {
		count++;
	}
    gettimeofday(&tv, NULL);
    printf("Got time - secs: %i usecs: %i\n", tv.tv_sec, tv.tv_usec);
	count = 0;
	while (count < 1000000) {
		count++;
	}
    gettimeofday(&tv, NULL);
    printf("Got time - secs: %i usecs: %i\n", tv.tv_sec, tv.tv_usec);
	count = 0;
	while (count < 1000000) {
		count++;
	}
    gettimeofday(&tv, NULL);
    printf("Got time - secs: %i usecs: %i\n", tv.tv_sec, tv.tv_usec);
	count = 0;
	while (count < 1000000) {
		count++;
	}
    gettimeofday(&tv, NULL);
    printf("Got time - secs: %i usecs: %i\n", tv.tv_sec, tv.tv_usec);
}

void runTimerTest() {
	long long count;
	printf("Starting timer tests\n");
	// timer should now be running
	int i;
    for (i = 0; i < 10; i++) {
    	count = 0;
    	while (count < 1000000) {
    		count++;
    	}
    	printf("counter = %i\n", clock_counter);
    	printf("cpsr = 0x%x; imr = 0x%x; ipr = 0x%x\n", get_cpsr(), get_aic_imr(), get_aic_ipr());
    	printf("0x18 = 0x%x\n", peek(0x18));
    	printf("0x18+0x20 = 0x%x\n", peek(0x18+0x20));
    	//init_watchdog_timer();
    }
}
	
void runMallocTest() {
  
  	void * buffer, * firstMalloc;
  	int expcount, total;
  	
  	total = &__stack_end - &__bss_end;
  	expcount = total / 1024;
  	firstMalloc = 0;
  	
	int count = -1;
	do {
		count++;
		buffer = malloc (1024);
		if (firstMalloc == 0) {
			firstMalloc = buffer;
		}
	} while (buffer != 0);
	count++;
	free(firstMalloc);
	printf ("Malloc test\n");
	printf ("First malloc addr: 0x%x; bss end: 0x%x\n", firstMalloc, &__bss_end);
	printf ("Expect to allocate %i blocks totalling 0x%x before failure\n", expcount, total);
	printf ("Allocated %i blocks totalling 0x%x before failure\n", count, count * 1024);

}
