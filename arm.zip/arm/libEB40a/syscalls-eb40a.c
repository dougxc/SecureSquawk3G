#include "sys/time.h"
#include "periph/wd/wd.h"

extern	int	clock_counter;

int _gettimeofday(struct timeval *tp, struct timezone *tzp) {
	long long sec = clock_counter;
	sec = sec * 1000000 / CLOCK_TICKS_PER_MILLION_SECS;
	tp->tv_sec = (long) sec;
	long long usec = clock_counter;
	usec = (usec * 1000000) % CLOCK_TICKS_PER_MILLION_SECS;
	usec = usec * 1000000 / CLOCK_TICKS_PER_MILLION_SECS;
	tp->tv_usec = (long) usec;
	return 0;
}

void _exit (int code){
	while(1);
}

int _close(int file){
    return -1;
}

#include <errno.h>
#undef errno
extern int errno;
int _execve(char *name, char **argv, char **env){
  errno=ENOMEM;
  return -1;
}

#undef errno
extern int errno;
int _fork() {
  errno=EAGAIN;
  return -1;
}

#include <sys/stat.h>
int _fstat(int file, struct stat *st) {
  st->st_mode = S_IFCHR;
  return 0;
}

int _getpid() {
  return 1;
}

int _isatty(int file){
   return 1;
}

int isatty(int file){
   return 1;
}

#undef errno
extern int errno;
int _kill(int pid, int sig){
  errno=EINVAL;
  return(-1);
}

#undef errno
extern int errno;
int _link(char *old, char *new){
  errno=EMLINK;
  return -1;
}

int _lseek(int file, int ptr, int dir){
    return 0;
}

/* OPEN
 * 
 * Opens a file
 * 
 * This version returns 1, the id of STDOUT. So all file open requests
 * will succeed, but it will only be possible to write
 */
int _open(const char *name, int flags, int mode){
    return 1;
}

/* sbrk 
Increase program data space. As malloc and related functions depend on this, it is useful to have a working implementation. The following suffices for a standalone system; it exploits the symbol end automatically defined by the GNU linker.  */

caddr_t _sbrk(int incr){
  extern char end;		/* Defined by the linker */
  static char *heap_end;
  char *prev_heap_end;
  char check;
 
  if (heap_end == 0) {
    heap_end = &end;
  }
  prev_heap_end = heap_end;
  if (heap_end + incr > (&check - 100))
    {
      //Heap and stack collision
      return 0;
    }

  heap_end += incr;
  return (caddr_t) prev_heap_end;
}

int _stat(const char *file, struct stat *st) {
  st->st_mode = S_IFCHR;
  return 0;
}

#include <sys/times.h>

int _times(struct tms *buf){
  return -1;
}

#undef errno
extern int errno;
int _unlink(char *name){
  errno=ENOENT;
  return -1; 
}

#undef errno
extern int errno;
int _wait(int *status) {
  errno=ECHILD;
  return -1;
}

#include <parts/r40008/lib_r40008.h>
#include "targets/eb40a/eb40a.h"
#include "drivers/com/com.h"

int _serial_port_initialised = 0;
ComDesc         _COM;

void _init_serial_port() {
	unsigned short cd;
    if (!_serial_port_initialised) {
		//* Open com
		_COM.usart= &USART0_DESC;
		cd = at91_baud_com(MCK,115200);
		at91_open_com(&_COM,(COM_8_BIT|COM_PAR_NONE|COM_NBSTOP_1|COM_FLOW_CONTROL_NONE), cd);
		_serial_port_initialised = 1;
    }
}

/* read
 * 
 * Read one or more characters from stdin. Blocks until a character
 * is available
 */
int _read(int file, char *ptr, int len){
	int result;
	int noChar, index;

	if (file != 0) {
		// only read from stdin
        errno = EINVAL;
		return -1;
	}

	if (len == 0) {
		return 0;
	}
	
	_init_serial_port();
	
    if ( at91_usart_get_status(_COM.usart) & (US_OVRE | US_PARE) )
    {
        //* Reset Status Bits
        at91_usart_trig_cmd(_COM.usart, US_RSTSTA);
        errno = EIO;
        return -1;
    }
	// care here becuase the comment on at91_getch suggests it
	// returns TRUE if it got a char, but in fact it returns FALSE
	index = 0;
	// always wait for at least one char
	do {noChar = at91_getch(&_COM , &result);} while (noChar);
	ptr[index++] = (char)(result & 0xff);
	--len;
	// see if there are any more
	while (!noChar && (len > 0)) {
		noChar = at91_getch(&_COM , &result);
		if (!noChar) {
			ptr[index++] = (char)(result & 0xff);
			--len;
		}
	}
	return index;
}

/* read
 * 
 * Read one or more characters from stdin. Blocks until a character
 * is available
 *
#define MAX__READ_INPUT_SIZE 199
char _input_buffer[MAX__READ_INPUT_SIZE + 1];
 
int _readFrame(int file, char *ptr, int len){
	int result;
	int noChar, index;

	if (file != 0) {
		// only read from stdin
        errno = EINVAL;
		return -1;
	}

	if (len > MAX__READ_INPUT_SIZE) {
		// too big
        errno = EINVAL;
		return -1;
	}

	if (len == 0) {
		return 0;
	}
	
	_init_serial_port();
	
    if ( at91_usart_get_status(_COM.usart) & (US_OVRE | US_PARE) )
    {
        //* Reset Status Bits
        at91_usart_trig_cmd(_COM.usart, US_RSTSTA);
        errno = EIO;
        return -1;
    }

/*
 * if has received enough bytes or has received nl
 *    
    if ( at91_usart_get_status(_COM.usart) & (US_ENDRX) )
	return index;
}
*/

#define MAX__WRITE_OUTPUT_SIZE 511
char _output_buffer[MAX__WRITE_OUTPUT_SIZE + 1];

/* write 
 * Write a character to a file. `libc' subroutines will use this system routine
 * for output to all files, including stdout.
 */
int _write(int file, char *ptr, int len){
	int i;
	
	if (len > MAX__WRITE_OUTPUT_SIZE) {
        errno = EINVAL;
		return -1;
	}
	
	_init_serial_port();

	// wait for previous transfer to finish
	at91_usart_wait_frame_sent(_COM.usart);
	
	// copy string into output buffer
	for (i = 0; i<len; i++) {
		_output_buffer[i] = ptr[i];
	}

	if (_output_buffer[i-1] == '\n') {
		// last character was newline - replace with CRLF
		_output_buffer[i-1] = '\r';
		_output_buffer[i] = '\n';
		i++;
	}
	
	at91_usart_send_frame (_COM.usart, _output_buffer , i) ; 
    return len;
}

