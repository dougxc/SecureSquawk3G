#include 	"parts/r40008/lib_r40008.h"		//* for &PIO_DESC
#include 	"parts/r40008/reg_r40008.h"
#include 	"targets/eb40a/eb40a.h"			//* MCK definition

#include    "drivers/com/com.h"

#include 	"drivers/xmodem/xmodem.h"

//* --------------------------- Constant definition ---------------------------

static char buffer[XMODEM_DATA_SIZE];

//* ------------------------------  Local variable ----------------------------
/* External Interrupt Sources Descriptor */

ComDesc         COM;
ComDesc         *Xmodem_COM;

int do_write_block ( u_char *buffer,int size);

void xmodemtest( void )
{
	unsigned short  cd;

    configure_leds_and_sws();

	COM.usart= &USART1_DESC;

    //* Set the Xmodem transaction on USART COM
    Xmodem_COM = &COM;

    //* Open com
	cd = at91_baud_com(MCK,115200);
    at91_open_com(&COM,(COM_8_BIT|COM_PAR_NONE|COM_NBSTOP_1|COM_FLOW_CONTROL_NONE), cd);

    //* print header
    at91_print(&COM,"XModem Tests - send file to SERIAL B now\n\r");

	turn_off_all_leds();

    xmodem_receive(&do_write_block);

	turn_on_leds(0xf);
}

int do_write_block ( u_char *buffer,int size) {
	static int count = 0;
	count++;
	if (count == 5) return 0; else return 1;
}
