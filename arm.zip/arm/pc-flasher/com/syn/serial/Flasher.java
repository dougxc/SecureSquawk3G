/*
 * Created on Nov 3, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.syn.serial;

import gnu.io.CommPortIdentifier;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.UnsupportedCommOperationException;

import java.io.BufferedInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;

/**
 * @author danielsj
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Flasher {

	/* Control Characters */
	static final byte SOH = 0x01;            /* Start of Heading */
	static final byte EOT = 0x04;            /* End of transmission */
	static final byte ACK = 0x06;            /* Acknowledge */
	static final byte NAK = 0x15;            /* Negative Acknowledge */
	static final byte CRCCHR = 'C';

	static final int CRC16POLY = 0x1021;              /* CRC 16  polynom */

	static final int XMODEM_DATA_SIZE = 128;         /* data 128 */
	static final int XMODEM_FRAME_SIZE = (3+XMODEM_DATA_SIZE+2);   /* Header 3, data 128, CRC 2 */
	static final int MAX_FILE_SIZE = 0x5FFF0;

	SerialPort serialPort = null;
	BufferedInputStream in = null;
    OutputStream out = null;
    InputStream fis = null;
	
	public static void main(String[] args){
		new Flasher().run(args);
	}
	
	public void run(String[] args) {
        byte[] buf = new byte[XMODEM_DATA_SIZE];
        int len;
        int error;
        int total = 0;
        int packetNum = 1;
        String port = null;

        if (args.length < 1) {
			System.out.println("Missing file name argument");
			return;
		}

        String fileName = args[0];
        
		if (args.length > 1) {
			// get port number
			port = args[1];
		} else {
			port = "COM2";
		}

		try {
			File inputFile = new File(fileName);
			fis = new FileInputStream(inputFile);
			if (inputFile.length() > MAX_FILE_SIZE) {
				System.out.println("File " + fileName + "("+ inputFile.length() + " bytes) is larger than the");
				System.out.println("maximum permitted size of " + MAX_FILE_SIZE + " - it may overwrite other memory sections");
				return;
			}
			initComms(port);
			System.out.println("Writing " + fileName + "("+ inputFile.length() + " bytes) to " + port);
			
			flushInput();

			//* wait for start signal
			waitForChar(CRCCHR);

	        while ((len = fis.read(buf)) > 0) {
	        	while (len < XMODEM_DATA_SIZE) {
	        		// didn't read a full frame
	        		// pad with 0
	        		buf[len] = 0;
	        		len++;
	        	}
	            if ((error = xmodem_transmit_frame(buf, packetNum)) > 0) {
	            	throw new IOException("XModem transmit failure: " + error + " pkt: " + (packetNum) + " buf: " + bufPrint(buf));
	            }
	            total = total + len;
	            //System.out.println("Written pkt: " + (packetNum) + " sent " + total + " of "+ inputFile.length());
				packetNum = (packetNum + 1) % 256;
	        }
	    	// send end of file
	    	out.write (EOT);
	    	byte reply = getInputChar();
	    	if (reply != NAK && reply != ACK) {
	    		throw new IOException("XModem EOT failure - received: " + reply);
	    	}
	    	//out.write (EOT);
	        fis.close();
            System.out.println("Done");
		} catch (IOException e) {
			e.printStackTrace();
		}
		tidyUp();
	}
	
	/**
	 * 
	 * @param buf
	 * @param packetNum
	 * @return 0 if okay, or error code otherwise
	 * @throws IOException
	 */
	protected int xmodem_transmit_frame(byte[] buf, int packetNum) throws IOException
	{
	    int retryCount = 5;
	    int status;
	    int crc;
	    byte lastChar;

	    do {
		    status = -1;
		    // send header
	        out.write(SOH);
	        out.write(packetNum);
	        out.write(0xFF - packetNum);
	
	        // send data frame
	        out.write(buf , 0, XMODEM_DATA_SIZE);
	
	        // determine CRC
	        crc = calcrc(buf, XMODEM_DATA_SIZE);
	
	        // send CRC
	        out.write (crc >> 8);
	        out.write(crc);
	
	        // wait ACK
	        // ignore spurious CRCCHR
	        do {
	        	lastChar = getInputChar();
	        } while (lastChar == CRCCHR);
	        
	        switch (lastChar)
	        {
	            case NAK: //* retransmit the last frame
	            	System.out.print("X");
	                --retryCount;
	                if (retryCount == 0) {
	                	status = 1;
	                }
	            break;
	
	            case ACK://* Continue
	            	System.out.print(".");
	            	if (packetNum % 64 == 0) {
	            		System.out.println();
	            	}
	            	status = 0;
	            break;
	
	            default: // Stop the transmission
	                // send NACK
	            	status = 2;
	            	out.write(NAK);
	            break;
	        }
	    } while (status < 0);
	    
	    return (status);
	}

	protected int calcrc(byte[] buf, int count)
	{
	    int crc, cmpt, index;

	    crc = 0;
	    index = 0;
	    //* For  all char
	    while (--count >= 0) {
	        crc = crc ^ buf[index++] << 8;
	        //* For All bit
	        for (cmpt = 0; cmpt < 8; cmpt++)
	        {
	            if ((crc & 0x8000) != 0)
	                crc = crc << 1 ^ CRC16POLY;
	            else
	                crc = crc << 1;
	        }
	    }
	    return (crc & 0xFFFF);
	}

	protected void initComms(String portName) throws IOException {
		
	    CommPortIdentifier portId = null;
	    Enumeration portList;
	    int retryCount = 5;
	    
	    while (portId == null && retryCount > 0) {
		    portList = CommPortIdentifier.getPortIdentifiers();
	
	        while (portList.hasMoreElements()) {
	        	CommPortIdentifier nextPortId = (CommPortIdentifier) portList.nextElement();
	            if (nextPortId.getPortType() == CommPortIdentifier.PORT_SERIAL) {
	                if (nextPortId.getName().equals(portName)) {
	                    portId = nextPortId;
	                    break;
	                }
	            }
	        }
	        if (portId == null) {
	        	--retryCount;
				System.out.println("Port " + portName + " unavailable... retrying...");
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e1) {};
	        }
	    }

        if (portId == null) {
        	throw new IOException(portName + " not found");
        }

        try {
        	serialPort = (SerialPort) portId.open("Flasher", 2000);
        } catch (PortInUseException e) {
        	throw new IOException(portName + " is in use");
        }

        try {
            serialPort.disableReceiveThreshold();
            serialPort.enableReceiveTimeout(20000);
            serialPort.setSerialPortParams(115200,
                SerialPort.DATABITS_8,
                SerialPort.STOPBITS_1,
                SerialPort.PARITY_NONE);
        } catch (UnsupportedCommOperationException e) {
        	throw new IOException(e.getMessage());
        }
		
        in = new BufferedInputStream (serialPort.getInputStream());
		out = serialPort.getOutputStream();
	}

	protected byte waitForChar (byte sample) throws IOException {
		byte result;
		do {
			result = getInputChar();	
		} while (result != sample);
		return result;
	}
	
	protected void flushInput() throws IOException {	
		while (in.available() > 0) {
			getInputChar();
		}
	}

	protected byte getInputChar() throws IOException {	
		byte[] serBuf = new byte[1]; 
		int bytesRead = 0;
		bytesRead = in.read(serBuf);
		if (bytesRead == -1) {
			// timeout or EOF
			throw new EOFException();
		}
		return serBuf[0];
	}

	protected void write(String s) throws IOException {
        out.write(s.getBytes());
	}

	protected void tidyUp() {
		//	 clean up code to close serial ports and all streams
		if (serialPort != null) {
			serialPort.close();
		}
	}

	protected String bufPrint(byte[] buf) {
		String result = "";
		int i;
		for (i = 0; i <= 127; i++) {
			result = result + buf[i] + " ";
		}
		return result;
	}

}
