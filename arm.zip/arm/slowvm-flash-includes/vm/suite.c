/*
 * Copyright 2004 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of Sun Microsystems, Inc.
 * Use is subject to license terms.
 *
 * This is a part of the Squawk JVM.
 */


/**
 * This file contains functions for loading the bootstrap suite from a file and relocating the
 * contained object memory. The structure of an object memory file is described in the javadoc
 * comment of the java.lang.ObjectMemory class.
 */

// Uncomment to enable tracing of the bootstrap suite file as it's read
//#define TRACE_SUITE

/**
 * Wrapper for a file input stream that provides a subset of the functionality
 * of the java.io.DataInputStream class.
 */
typedef struct {
    ByteAddress in;  // the byte array
    UWord size;      // the size of the byte array
    UWord pos;       // the current read position
} DataInputStream;

/**
 * Initializes a DataInputStream.
 *
 * @param  dis   the DataInputStream to initialize
 * @param  file  the name of the file to initialize the stream from
 */
void DataInputStream_open(DataInputStream *dis, const char *file) {
    (*dis).size = getFileSize(file);
    if ((*dis).size == -1) {
        printf("No such file '%s'\n", file);
        stopVM(-1);
    }

    (*dis).in = newBuffer((*dis).size, "DataInputStream_open", true);
    if (readFile(file, (*dis).in, (*dis).size) != (*dis).size) {
        printf("Error reading '%s'\n", file);
        stopVM(-1);
    }
    (*dis).pos = 0;
}

/**
 * Returns the number of bytes that can still be read from a DataInputStream stream.
 *
 * @param  dis   the DataInputStream to query
 * @return the number of available bytes
 */
unsigned int DataInputStream_available(DataInputStream *dis) {
    return (*dis).size - (*dis).pos;
}

/**
 * Returns the number of bytes that have been read from a DataInputStream stream.
 *
 * @param  dis   the DataInputStream to query
 * @return the number of bytes that have been read
 */
unsigned int DataInputStream_readSoFar(DataInputStream *dis) {
    return (*dis).pos;
}

/**
 * Reads an unsigned byte from a DataInputStream.
 *
 * @param  dis    the DataInputStream to read from
 * @param  prefix the prefix used when tracing this read
 * @return the value read
 */
UWord DataInputStream_readUnsignedByte(DataInputStream *dis, const char *prefix) {
    UWord value;

    if ((*dis).pos >= (*dis).size) {
        fatalVMError("EOFException");
    }

    value = (*dis).in[(*dis).pos++];
#ifdef TRACE_SUITE
    if (prefix != null) {
        fprintf(stderr, "%s:%u\n", prefix, (value & 0xFF));
    }
#endif /* TRACE_SUITE */
    return value & 0xFF;
}

/**
* Reads an unsigned short from a DataInputStream.
 *
 * @param  dis    the DataInputStream to read from
 * @param  prefix the prefix used when tracing this read
 * @return the value read
 */
UWord DataInputStream_readUnsignedShort(DataInputStream *dis, const char *prefix) {
    int b1 = DataInputStream_readUnsignedByte(dis, null);
    int b2 = DataInputStream_readUnsignedByte(dis, null);
    UWord value = ((b1 << 8) + (b2 << 0)) & 0xFFFF;
#ifdef TRACE_SUITE
    fprintf(stderr, "%s:%u\n", prefix, value);
#endif /* TRACE_SUITE */
    return value;
}

/**
 * Reads an int from a DataInputStream.
 *
 * @param  dis    the DataInputStream to read from
 * @param  prefix the prefix used when tracing this read
 * @return the value read
 */
int DataInputStream_readInt(DataInputStream *dis, const char *prefix) {
    int b1 = DataInputStream_readUnsignedByte(dis, null);
    int b2 = DataInputStream_readUnsignedByte(dis, null);
    int b3 = DataInputStream_readUnsignedByte(dis, null);
    int b4 = DataInputStream_readUnsignedByte(dis, null);
    UWord value = ((b1 << 24) + (b2 << 16) + (b3 << 8) + (b4 << 0));
#ifdef TRACE_SUITE
    fprintf(stderr, "%s:%u\n", prefix, value);
#endif /* TRACE_SUITE */
    return value;
}

/**
 * Reads some bytes from a DataInputStream into a buffer.
 *
 * @param  dis    the DataInputStream to read from
 * @param  buf    the buffer to store into
 * @param  size   the size of the buffer which also specifies the number of bytes to read
 * @param  prefix the prefix used when tracing this read
 * @return the value read
 */
void DataInputStream_readFully(DataInputStream *dis, ByteAddress buf, UWord size, const char *prefix) {
    unsigned int i = 0;
    while (i != size) {
        buf[i++] = DataInputStream_readUnsignedByte(dis, null);
    }
#ifdef TRACE_SUITE
    fprintf(stderr, format("%s:{read %W bytes}\n"), prefix, size);
#endif /* TRACE_SUITE */
}

/**
 * Skips a number of bytes in a DataInputStream.
 *
 * @param  dis    the DataInputStream to operate on
 * @param  n      the number of bytes to skip
 * @param  prefix the prefix used when tracing this read
 */
void DataInputStream_skip(DataInputStream *dis, UWord n, const char* prefix) {
    unsigned int i = 0;
    while (i++ != n) {
        DataInputStream_readUnsignedByte(dis, null);
    }
#ifdef TRACE_SUITE
    fprintf(stderr, format("%s:{skipped %W bytes}\n"), prefix, n);
#endif /* TRACE_SUITE */
}

/**
 * Closes a DataInputStream.
 *
 * @param dis  the DataInputStream to close
 */
void DataInputStream_close(DataInputStream *dis) {
    if ((*dis).in != null) {
        freeBuffer((*dis).in);
        (*dis).in = null;
    }
}

/**
 * Loads the bootstrap suite from a file into a given buffer.
 *
 * @param file    the name of the file to load from
 * @param buffer  the buffer into which the object memory is to be loaded
 * @param size    the size of the buffer. This must at least equal to the size of the file
 * @param suite   OUT: the pointer to the suite
 * @param hash    OUT: the hash of the object memory in canonical form
 * @return the size of the object memory
 */
UWord loadBootstrapSuite(const char *file,
                        Address buffer,
                        UWord   size,
                        Address *suite,
                        int     *hash)
{
    DataInputStream dis;
    UWord suiteOffset;
    ByteAddress oopMap;
    UWord oopMapLength;
    unsigned int i;
    int attributes;
    boolean hasTypemap;
    int pad;

    if (size < getFileSize(file)) {
        fatalVMError("buffer size is too small for ROM suite");
    }

    /*
     * Try to open the suite file.
     */
    DataInputStream_open(&dis, file);

    /*
     * Read 'magic'
     */
    if (DataInputStream_readInt(&dis, "magic") != 0xdeadbeef) {
        fatalVMError("magic in bootstrap suite is incorrect");
    }

    /*
     * Read (and ignore for now) version identifiers
     */
    DataInputStream_readUnsignedShort(&dis, "minor_version");
    DataInputStream_readUnsignedShort(&dis, "major_version");

    /*
     * Read 'attributes'
     */
    attributes = DataInputStream_readInt(&dis, "attributes");
    hasTypemap = ((attributes & java_lang_ObjectMemoryLoader_ATTRIBUTE_TYPEMAP) != 0);
    if (((attributes & java_lang_ObjectMemoryLoader_ATTRIBUTE_32BIT) != 0) == SQUAWK_64) {
        fatalVMError("word size in bootstrap suite is incorrect");
    }

    /*
     * Read and ignore 'parent_hash'
     */
    DataInputStream_readInt(&dis, "parent_hash");

    /*
     * Read the length of 'parent_url' and verify that it is 0
     */
    if (DataInputStream_readUnsignedShort(&dis, "parent_url") != 0) {
        fatalVMError("bootstrap suite should have no parent");
    }

    /*
     * Read 'root'
     */
    suiteOffset = DataInputStream_readInt(&dis, "root");

    /*
     * Read 'size'
     */
    size = DataInputStream_readInt(&dis, "size");

    /*
     * Read 'oopmap'
     */
    oopMapLength = ((size / HDR_BYTES_PER_WORD) + 7) / 8;
    oopMap = (ByteAddress)buffer + size;
    DataInputStream_readFully(&dis, oopMap, oopMapLength, "oopmap");

    /*
     * Skip the padding for 'memory' to be word aligned
     */
    pad = roundUpToWord(DataInputStream_readSoFar(&dis)) - DataInputStream_readSoFar(&dis);
    DataInputStream_skip(&dis, pad, "padding");

    /*
     * Read 'memory'
     */
    DataInputStream_readFully(&dis, buffer, size, "memory");

    /*
     * Calculate the hash of the object memory while it is still in canonical form.
     */
    *hash = size;
    for (i = 0; i != size; ++i) {
        setType((ByteAddress)buffer + i, AddressType_BYTE, 1);
        *hash += getByte(buffer, i);
    }

    /*
     * Relocate all the pointers in the object memory.
     */
#ifdef TRACE_SUITE
    {
    FILE *pointers = fopen("squawk.suite.pointers", "w");
    int cardinality = 0;
#endif /* TRACE_SUITE */

    for (i = 0; i != oopMapLength; ++i) {
        int oopMapByte = oopMap[i];
        int bit;

        for (bit = 0; bit != 8; ++bit) {
            if ((oopMapByte & (1 << bit)) != 0) {
                int offset = (i * 8) + bit;
                UWord pointer;
                setType((UWordAddress)buffer + offset, AddressType_UWORD, HDR_BYTES_PER_WORD);
                pointer = getUWord(buffer, offset);
                if (pointer != 0) {
                    setUWord(buffer, offset, pointer + (UWord)buffer);
                }
#ifdef TRACE_SUITE
                ++cardinality;
                fprintf(pointers, format("%A: %A -> %A\n"), offset*HDR_BYTES_PER_WORD, pointer, pointer + (UWord)buffer);
#endif /* TRACE_SUITE */
            }
        }
    }

#ifdef TRACE_SUITE
    fprintf(stderr, "oopmap:{cardinality = %d}\n", cardinality);
    fclose(pointers);
    }
#endif /* TRACE_SUITE */


    /*
     * Initialize the suite pointer.
     */
    *suite = (ByteAddress)buffer + suiteOffset;

#if TYPEMAP
    if (hasTypemap) {
        ByteAddress p = buffer;
        int i;

        for (i = 0; i != size; ++i) {
            char type = DataInputStream_readUnsignedByte(&dis, "type");
            setType(p, type, 1);
            p++;
        }
    }
#endif /* TYPEMAP */

    /*
     * Close the data input stream.
     */
    DataInputStream_close(&dis);

    return size;
}

#ifdef FLASH_MEMORY

// the next definition needs to be kept in sync with suite converter
#define NUMBER_OF_BYTES_IN_BYTECODE_HEADER (3 * sizeof(UWord))

UWord loadBootstrapSuiteFromFlash(
                        Address *romStart,
                        Address *suite,
                        int     *hash) {

    // ROM start at the flash address set at link time
    extern int * __javabytecodes_start;
    Address javabytecodesbase = &__javabytecodes_start;
    *suite = (void *)getUWord(javabytecodesbase, 0);
    *hash = (int)getUWord(javabytecodesbase, 1);
    UWord size=getUWord(javabytecodesbase, 2);
    *romStart=(void *)(javabytecodesbase + NUMBER_OF_BYTES_IN_BYTECODE_HEADER);
    return size;
}
#endif
