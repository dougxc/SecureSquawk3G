/*
 * Copyright 2004 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of Sun Microsystems, Inc.
 * Use is subject to license terms.
 *
 * This is a part of the Squawk JVM.
 */

void openTraceFile() {
    if (!traceFileOpen) {
        if (traceFile == NULL) {
            traceFile = fopen("trace", "w");
        }
        traceFileOpen = true;
        fprintf(traceFile, format("*TRACE*:*ROM*:%A:%A:*NVM*:%A:%A\n"),
                java_lang_VM_romStart, java_lang_VM_romEnd, java_lang_GC_nvmStart, java_lang_GC_nvmEnd);
    }
}

/**
 * Write a trace record.
 */
#ifdef MACROIZE
void trace(ByteAddress ip, UWordAddress fp, UWordAddress sp, int opcode) {
#else
void trace(ByteAddress xxxip, UWordAddress xxxfp, UWordAddress xxxsp, int opcode) {
#endif
#ifdef TRACE
    ByteAddress saveip = ip;
    UWordAddress xfp = fp;
    int level = -1;
    char *precode  = "";
    char *maincode = getOpcodeName(opcode);
    char value[4096];
    char resultType[4];
    int nlocals;
    ByteAddress mid;
    int threadId = -1;
    int fparm;
    jlong flparm;

    Address current = java_lang_Thread_currentThread;
    if (current != 0) {
        threadId = java_lang_Thread_threadNumber(current);
    }

    openTraceFile();
    if (opcode == OPC_EXTEND) {
        mid = ip - 1;
        level++;
    } else if (opcode == OPC_EXTEND0) {
        mid = ip - 1;
        level++;
    } else {
        mid = (ByteAddress)getMP();
    }
    nlocals = getLocalCount(mid);
    value[0] = '\0';
    resultType[0] = '\0';
    switch (opcode) {
        case OPC_WIDE_M1: {
            precode = "wide_m1 ";
            maincode = getOpcodeName(fetchUByte());
            sprintf(value, " %d", 0xFFFFFF00|fetchUByte());
            break;
        }
        case OPC_WIDE_0: {
            precode = "wide_0 ";
            maincode = getOpcodeName(fetchUByte());
            sprintf(value, " %d", fetchUByte());
            break;
        }
        case OPC_WIDE_1: {
            precode = "wide_1 ";
            maincode = getOpcodeName(fetchUByte());
            sprintf(value, " %d", 0x100|fetchUByte());
            break;
        }
        case OPC_WIDE_SHORT: {
            precode = "wide_short ";
            maincode = getOpcodeName(fetchUByte());
            fetchShort(); sprintf(value, " %d", fparm);
            break;
        }
        case OPC_WIDE_INT: {
            precode = "wide_int ";
            maincode = getOpcodeName(fetchUByte());
            fetchInt(); sprintf(value, " %d", fparm);
            break;
        }
        case OPC_ESCAPE: {
            int eopcode = fetchUByte()+256;
            switch (eopcode) {
#ifdef java_lang_VM_fcmpl
                case OPC_CONST_FLOAT: {
                    fetchInt(); sprintf(value, " %f", ib2f(fparm));
                    break;
                }
                case OPC_CONST_DOUBLE: {
                    fetchLong(); sprintf(value, format(" %D"), lb2d(flparm));
                    break;
                }
#endif /* java_lang_VM_fcmpl */
                default: {
                    precode = "escape ";
                    maincode = getOpcodeName(eopcode);
                    if (eopcode >= OPC_FIRST_ESCAPE_PARM_BYTECODE && eopcode < OPC_FIRST_ESCAPE_PARM_BYTECODE+OPC_ESCAPE_PARM_BYTECODE_COUNT) {
                        sprintf(value, " %d", fetchUByte());
                    }
                    break;
                }
            }
            break;
        }
        case OPC_ESCAPE_WIDE_M1: {
            precode = "escape_wide_m1 ";
            maincode = getOpcodeName(fetchUByte()+256);
            sprintf(value, " %d", 0xFFFFFF00|fetchUByte());
            break;
        }
        case OPC_ESCAPE_WIDE_0: {
            precode = "escape_wide_0 ";
            maincode = getOpcodeName(fetchUByte()+256);
            sprintf(value, " %d", fetchUByte());
            break;
        }
        case OPC_ESCAPE_WIDE_1: {
            precode = "escape_wide_1 ";
            maincode = getOpcodeName(fetchUByte()+256);
            sprintf(value, " %d", 0x100|fetchUByte());
            break;
        }
        case OPC_ESCAPE_WIDE_SHORT: {
            precode = "escape_wide_short ";
            maincode = getOpcodeName(fetchUByte()+256);
            fetchShort(); sprintf(value, " %d", fparm);
            break;
        }
        case OPC_ESCAPE_WIDE_INT: {
            precode = "escape_wide_int ";
            maincode = getOpcodeName(fetchUByte()+256);
            fetchInt(); sprintf(value, " %d", fparm);
            break;
        }
        case OPC_CONST_BYTE: {
            sprintf(value, " %d", fetchByte());
            break;
        }
        case OPC_CONST_SHORT: {
            fetchShort(); sprintf(value, " %d", fparm);
            break;
        }
        case OPC_CONST_CHAR: {
            fetchUShort(); sprintf(value, " %d", fparm);
            break;
        }
        case OPC_CONST_INT: {
            fetchInt(); sprintf(value, " %d", fparm);
            break;
        }
        case OPC_CONST_LONG: {
            fetchLong(); sprintf(value, format(" %L"), flparm);
            break;
        }
        default: {
            if (opcode >= OPC_FIRST_PARM_BYTECODE && opcode < OPC_FIRST_PARM_BYTECODE+OPC_PARM_BYTECODE_COUNT) {
                sprintf(value, " %d", fetchUByte());
            }
            break;
        }
    }
    while (xfp != 0) {
        level++;
        if (level > 2000) {
            fatalVMError("**Levels too deep - infinite recursion?**");
        }
        xfp = (UWordAddress)getObject(xfp, FP_returnFP);
    }

    fprintf(traceFile, format("*TRACE*:%d:%d:%A:%d:"), threadId, level, mid, (int)(saveip-1-mid));

    /*
     * Dump the local and stack values
     */
    if (opcode == OPC_EXTEND || opcode == OPC_EXTEND0) {
        int nstack = getStackCount(mid);
        fprintf(traceFile, format("max_locals=%d, max_stack=%d, remaining stack=%d"), nlocals, nstack, (sp - sl));
    } else {
        UWordAddress p   = fp;
        UWordAddress sp0 = fp - nlocals;
#if ROM_REVERSE_PARAMETERS
        UWordAddress xsp = sp;
#else
        UWordAddress xsp = fp - nlocals - getStackCount(mid) + 1;
#endif
        fprintf(traceFile, "[");
        while (p >= xsp) {
#if TYPEMAP
            UWord value = getUWordTyped(p, 0, getType(p));
#else
            UWord value = getUWordTyped(p, 0, 0);
#endif
            if (value == DEADBEEF) {
                fprintf(traceFile, "X");
            } else {
                fprintf(traceFile, format("%W"), value);
            }
#if TYPEMAP
            fprintf(traceFile, ":%c", getTypeMnemonic(getType(p)));
#endif /* TYPEMAP */
            --p;
            if (p == sp0) {
                fprintf(traceFile, "] {");
#if !ROM_REVERSE_PARAMETERS
                p = sp - 1;
#endif
            } else if (p >= xsp) {
                fprintf(traceFile, " ");
            }
        }
        fprintf(traceFile, "}");
    }

#if TYPEMAP
    resultType[0] = ':';
    resultType[1] = getTypeMnemonic(getMutationType());
    resultType[2] = ' ';
    resultType[3] = 0;
#endif /* TYPEMAP */

    fprintf(traceFile, format("~{70} %s%s%s%s ~{100} sp=%A  bcount=%L sp-sl=%d\n"), precode, maincode, resultType, value, sp, getBranchCount(), (sp - sl));
    fflush(traceFile);
    ip = saveip;
#endif
}

//void closeTraceFile(void) {
//    if(traceFileOpen) {
//        fprintf(traceFile, "\n+++ Trace file closed +++\n");
//        traceFileOpen = false;
//        fclose(traceFile);
//    }
//}

void printStackTracePrim(ByteAddress traceIP, UWordAddress traceFP, const char* msg) {
    int recursionLevel = 0;

    openTraceFile();
    if (msg != null) {
        fprintf(traceFile, format("*STACKTRACEMSG*:%L:%s\n"), getBranchCount(), msg);
        fflush(traceFile);
    }

    while (traceFP != 0) {
        ByteAddress traceMP = (ByteAddress)getObject(traceFP, FP_method);

        fprintf(traceFile, format("*STACKTRACE*:%A:%d\n"), traceMP, (int)(traceIP-1-traceMP));
        fflush(traceFile);

        recursionLevel++;
        if (recursionLevel > 2000) {
            fatalVMError("**Levels too deep - infinite recursion?**");
            fflush(traceFile);
        }
        traceIP = (ByteAddress)getObject(traceFP, FP_returnIP);
        traceFP = (UWordAddress)getObject(traceFP, FP_returnFP);
    }
}

void printStackTrace(const char *msg) {
#ifndef MACROIZE
    printStackTracePrim(ip, fp, msg);
#else
#ifdef TRACE
    printStackTracePrim(lastIP, lastFP, msg);
#else
    fprintf(traceFile, "MACROIZE precluded stack trace\n");
#endif
#endif
}
