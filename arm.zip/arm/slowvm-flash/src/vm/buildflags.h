#define BUILD_FLAGS "/O2 /Ogityb2 /Gs /DIOPORT"
