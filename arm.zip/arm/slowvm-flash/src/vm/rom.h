/*
* Copyright 2004 Sun Microsystems, Inc. All Rights Reserved.
*
* This software is the proprietary information of Sun Microsystems, Inc.
* Use is subject to license terms.
*
* This is a part of the Squawk JVM.
*/
#define java_lang_Object 1
#define java_lang_String 2
#define java_lang_Throwable 3
#define java_lang_Throwable_detailMessage(oop) getObject(oop, 0)
#define java_lang_Throwable_backtraceMP(oop) getObject(oop, 1)
#define java_lang_Throwable_backtraceIP(oop) getObject(oop, 2)
#define java_lang_Class 4
#define java_lang_Class_self(oop) getObject(oop, 0)
#define java_lang_Class_virtualMethods(oop) getObject(oop, 1)
#define java_lang_Class_staticMethods(oop) getObject(oop, 2)
#define java_lang_Class_name(oop) getObject(oop, 3)
#define java_lang_Class_componentType(oop) getObject(oop, 4)
#define java_lang_Class_superType(oop) getObject(oop, 5)
#define java_lang_Class_interfaces(oop) getObject(oop, 6)
#define java_lang_Class_interfaceVTableMaps(oop) getObject(oop, 7)
#define java_lang_Class_objects(oop) getObject(oop, 8)
#define java_lang_Class_oopMap(oop) getObject(oop, 9)
#define java_lang_Class_oopMapWord(oop) getUWord(oop, 10)
#define java_lang_Class_classID(oop) getInt(oop, 11)
#define java_lang_Class_modifiers(oop) getInt(oop, 12)
#define java_lang_Class_state(oop) getInt(oop, 13)
#define java_lang_Class_instanceSize(oop) getShort(oop, 28)
#define java_lang_Class_staticFieldsSize(oop) getShort(oop, 29)
#define java_lang_Class_refStaticFieldsSize(oop) getShort(oop, 30)
#define java_lang_Class_indexForInit(oop) getShort(oop, 31)
#define java_lang_Class_indexForClinit(oop) getShort(oop, 32)
#define java_lang_Class_indexForMain(oop) getShort(oop, 33)
#define java_lang_Class_initModifiers(oop) getByte(oop, 68)
#define java_lang_Class_mustClinit(oop) getByte(oop, 69)
#define java_lang_Class_FINALIZE_SLOT 9
#define java_lang_Class_STATE_NOTINITIALIZED 0
#define java_lang_Class_STATE_INITIALIZING 1
#define java_lang_Class_STATE_INITIALIZED 2
#define java_lang_Class_STATE_FAILED 3
#define VOID 5
#define BOOLEAN 6
#define BYTE 7
#define CHAR 8
#define SHORT 9
#define INT 10
#define LONG 11
#define FLOAT 13
#define DOUBLE 14
#define java_lang_StringOfBytes 26
#define java_lang_Address 34
#define java_lang_UWord 36
#define java_lang_Offset 38
#define java_lang_Unsafe 39
#define java_lang_StringBuffer 47
#define java_lang_StringBuffer_value(oop) getObject(oop, 0)
#define java_lang_StringBuffer_count(oop) getInt(oop, 1)
#define java_lang_StringBuffer_shared(oop) getByte(oop, 8)
#define java_io_PrintStream 48
#define java_io_PrintStream_charOut(oop) getObject(oop, 0)
#define java_io_PrintStream_byteOut(oop) getObject(oop, 1)
#define java_io_PrintStream_trouble(oop) getByte(oop, 8)
#define java_io_PrintStream_closing(oop) getByte(oop, 9)
#define java_lang_Klass_KlassInitializationState 51
#define java_lang_Klass_KlassInitializationState_next(oop) getObject(oop, 0)
#define java_lang_Klass_KlassInitializationState_thread(oop) getObject(oop, 1)
#define java_lang_Klass_KlassInitializationState_klass(oop) getObject(oop, 2)
#define java_lang_Klass_KlassInitializationState_classState(oop) getObject(oop, 3)
#define java_io_InputStream 52
#define java_lang_Member 53
#define java_lang_Member_metadata(oop) getObject(oop, 0)
#define java_lang_Member_id(oop) getInt(oop, 1)
#define java_lang_ClassFileMethod 54
#define java_lang_ClassFileMethod_returnType(oop) getObject(oop, 3)
#define java_lang_ClassFileMethod_parameterTypes(oop) getObject(oop, 4)
#define java_lang_ClassFileMethod_code(oop) getObject(oop, 5)
#define java_lang_ClassFileField 56
#define java_lang_ClassFileField_type(oop) getObject(oop, 3)
#define java_lang_MethodBody 58
#define java_lang_MethodBody_definingMethod(oop) getObject(oop, 0)
#define java_lang_MethodBody_index(oop) getInt(oop, 1)
#define java_lang_MethodBody_maxStack(oop) getInt(oop, 2)
#define java_lang_MethodBody_parametersCount(oop) getInt(oop, 3)
#define java_lang_MethodBody_exceptionTable(oop) getObject(oop, 4)
#define java_lang_MethodBody_metadata(oop) getObject(oop, 5)
#define java_lang_MethodBody_localTypes(oop) getObject(oop, 6)
#define java_lang_MethodBody_code(oop) getObject(oop, 7)
#define java_lang_MethodBody_typeMap(oop) getObject(oop, 8)
#define java_lang_MethodBody_FMT_LARGE 128
#define java_lang_MethodBody_FMT_E 1
#define java_lang_MethodBody_FMT_R 2
#define java_lang_MethodBody_FMT_T 4
#define com_sun_squawk_util_Vector 59
#define com_sun_squawk_util_Vector_elementData(oop) getObject(oop, 0)
#define com_sun_squawk_util_Vector_elementCount(oop) getInt(oop, 1)
#define com_sun_squawk_util_Vector_capacityIncrement(oop) getInt(oop, 2)
#define java_lang_Method 60
#define java_lang_Field 61
#define java_lang_KlassMetadata 62
#define java_lang_KlassMetadata_definedClass(oop) getObject(oop, 0)
#define java_lang_KlassMetadata_symbols(oop) getObject(oop, 1)
#define java_lang_KlassMetadata_virtualMethodsMetadata(oop) getObject(oop, 2)
#define java_lang_KlassMetadata_staticMethodsMetadata(oop) getObject(oop, 3)
#define java_lang_KlassMetadata_sourceFile(oop) getObject(oop, 4)
#define java_lang_Thread 63
#define java_lang_Thread_time(oop) getLongAtWord(oop, 0)
#define java_lang_Thread_isolate(oop) getObject(oop, 2)
#define java_lang_Thread_stack(oop) getObject(oop, 3)
#define java_lang_Thread_target(oop) getObject(oop, 4)
#define java_lang_Thread_stackSize(oop) getInt(oop, 5)
#define java_lang_Thread_nextThread(oop) getObject(oop, 6)
#define java_lang_Thread_nextTimerThread(oop) getObject(oop, 7)
#define java_lang_Thread_joiners(oop) getObject(oop, 8)
#define java_lang_Thread_monitor(oop) getObject(oop, 9)
#define java_lang_Thread_threadNumber(oop) getInt(oop, 10)
#define java_lang_Thread_monitorDepth(oop) getShort(oop, 22)
#define java_lang_Thread_state(oop) getByte(oop, 46)
#define java_lang_Thread_priority(oop) getByte(oop, 47)
#define java_lang_Thread_inqueue(oop) getByte(oop, 48)
#define java_lang_Thread_isDaemon(oop) getByte(oop, 49)
#define java_lang_Thread_INITIAL_STACK_SIZE -1
#define java_lang_Thread_MIN_STACK_SIZE -1
#define java_lang_Thread_MIN_PRIORITY 1
#define java_lang_Thread_NORM_PRIORITY 5
#define java_lang_Thread_MAX_PRIORITY 10
#define java_lang_Thread_NEW -1
#define java_lang_Thread_ALIVE -1
#define java_lang_Thread_DEAD -1
#define java_lang_Thread_MONITOR -1
#define java_lang_Thread_CONDVAR -1
#define java_lang_Thread_RUN -1
#define java_lang_Thread_EVENT -1
#define java_lang_Thread_JOIN -1
#define java_lang_Thread_ISOLATEJOIN -1
#define java_lang_Thread_HIBERNATEDRUN -1
#define com_sun_squawk_util_IntHashtable 64
#define com_sun_squawk_util_IntHashtable_table(oop) getObject(oop, 0)
#define com_sun_squawk_util_IntHashtable_count(oop) getInt(oop, 1)
#define com_sun_squawk_util_IntHashtable_threshold(oop) getInt(oop, 2)
#define com_sun_squawk_util_IntHashtable_loadFactorPercent 75
#define com_sun_squawk_util_Hashtable 65
#define com_sun_squawk_util_Hashtable_entryTable(oop) getObject(oop, 0)
#define com_sun_squawk_util_Hashtable_backupTable(oop) getObject(oop, 1)
#define com_sun_squawk_util_Hashtable_count(oop) getInt(oop, 2)
#define com_sun_squawk_util_Hashtable_threshold(oop) getInt(oop, 3)
#define com_sun_squawk_util_Hashtable_loadFactorPercent 75
#define com_sun_squawk_util_BitSet 66
#define com_sun_squawk_util_BitSet_bits(oop) getObject(oop, 0)
#define com_sun_squawk_util_BitSet_bytesInUse(oop) getInt(oop, 1)
#define com_sun_squawk_util_BitSet_bitsAreExternal(oop) getByte(oop, 8)
#define com_sun_squawk_util_ArrayHashtable 67
#define com_sun_squawk_util_ArrayHashtable_table(oop) getObject(oop, 0)
#define com_sun_squawk_util_ArrayHashtable_count(oop) getInt(oop, 1)
#define com_sun_squawk_util_ArrayHashtable_threshold(oop) getInt(oop, 2)
#define com_sun_squawk_util_ArrayHashtable_loadFactorPercent 75
#define com_sun_squawk_vm_AddressType 68
#define AddressType_UNDEFINED 0
#define AddressType_ANY 1
#define AddressType_BYTECODE 2
#define AddressType_BYTE 3
#define AddressType_SHORT 4
#define AddressType_INT 5
#define AddressType_FLOAT 6
#define AddressType_LONG 7
#define AddressType_LONG2 8
#define AddressType_DOUBLE 9
#define AddressType_DOUBLE2 10
#define AddressType_REF 11
#define AddressType_UWORD 12
#define AddressType_TYPE_MASK 15
#define AddressType_MUTATION_TYPE_SHIFT 4
#define AddressType_UNDEFINED_WORD 0
#define AddressType_ANY_WORD 16843009
#define com_sun_squawk_vm_ChannelConstants 69
#define ChannelConstants_CHANNEL_GENERIC 1
#define ChannelConstants_CHANNEL_GUIIN 2
#define ChannelConstants_CHANNEL_GUIOUT 3
#define ChannelConstants_GUIIN_REPAINT 0
#define ChannelConstants_GUIIN_KEY 1
#define ChannelConstants_GUIIN_MOUSE 2
#define ChannelConstants_GUIIN_EXIT 3
#define ChannelConstants_GUIIN_HIBERNATE 4
#define ChannelConstants_RESULT_OK 0
#define ChannelConstants_RESULT_BADCONTEXT -1
#define ChannelConstants_RESULT_EXCEPTION -2
#define ChannelConstants_RESULT_BADPARAMETER -3
#define ChannelConstants_GLOBAL_CREATECONTEXT 1
#define ChannelConstants_GLOBAL_DELETECONTEXT 2
#define ChannelConstants_GLOBAL_HIBERNATECONTEXT 3
#define ChannelConstants_GLOBAL_GETEVENT 4
#define ChannelConstants_GLOBAL_WAITFOREVENT 5
#define ChannelConstants_CONTEXT_GETCHANNEL 6
#define ChannelConstants_CONTEXT_FREECHANNEL 7
#define ChannelConstants_CONTEXT_GETRESULT 8
#define ChannelConstants_CONTEXT_GETRESULT_2 9
#define ChannelConstants_CONTEXT_GETERROR 10
#define ChannelConstants_OPENCONNECTION 11
#define ChannelConstants_CLOSECONNECTION 12
#define ChannelConstants_ACCEPTCONNECTION 13
#define ChannelConstants_OPENINPUT 14
#define ChannelConstants_CLOSEINPUT 15
#define ChannelConstants_WRITEREAD 16
#define ChannelConstants_READBYTE 17
#define ChannelConstants_READSHORT 18
#define ChannelConstants_READINT 19
#define ChannelConstants_READLONG 20
#define ChannelConstants_READBUF 21
#define ChannelConstants_SKIP 22
#define ChannelConstants_AVAILABLE 23
#define ChannelConstants_MARK 24
#define ChannelConstants_RESET 25
#define ChannelConstants_MARKSUPPORTED 26
#define ChannelConstants_OPENOUTPUT 27
#define ChannelConstants_FLUSH 28
#define ChannelConstants_CLOSEOUTPUT 29
#define ChannelConstants_WRITEBYTE 30
#define ChannelConstants_WRITESHORT 31
#define ChannelConstants_WRITEINT 32
#define ChannelConstants_WRITELONG 33
#define ChannelConstants_WRITEBUF 34
#define ChannelConstants_SETWINDOWNAME 35
#define ChannelConstants_SCREENWIDTH 36
#define ChannelConstants_SCREENHEIGHT 37
#define ChannelConstants_BEEP 38
#define ChannelConstants_SETOFFSCREENMODE 39
#define ChannelConstants_FLUSHSCREEN 40
#define ChannelConstants_CREATEIMAGE 41
#define ChannelConstants_CREATEMEMORYIMAGE 42
#define ChannelConstants_GETIMAGE 43
#define ChannelConstants_IMAGEWIDTH 44
#define ChannelConstants_IMAGEHEIGHT 45
#define ChannelConstants_DRAWIMAGE 46
#define ChannelConstants_FLUSHIMAGE 47
#define ChannelConstants_CREATEFONTMETRICS 48
#define ChannelConstants_FONTSTRINGWIDTH 49
#define ChannelConstants_FONTGETHEIGHT 50
#define ChannelConstants_FONTGETASCENT 51
#define ChannelConstants_FONTGETDESCENT 52
#define ChannelConstants_SETFONT 53
#define ChannelConstants_SETCOLOR 54
#define ChannelConstants_SETCLIP 55
#define ChannelConstants_DRAWSTRING 56
#define ChannelConstants_DRAWLINE 57
#define ChannelConstants_DRAWOVAL 58
#define ChannelConstants_DRAWRECT 59
#define ChannelConstants_FILLRECT 60
#define ChannelConstants_DRAWROUNDRECT 61
#define ChannelConstants_FILLROUNDRECT 62
#define ChannelConstants_FILLARC 63
#define ChannelConstants_FILLPOLYGON 70
#define ChannelConstants_REPAINT 71
#define ChannelConstants_INTERNAL_SETSTREAM 1000
#define ChannelConstants_INTERNAL_OPENSTREAM 1001
#define ChannelConstants_INTERNAL_PRINTCHAR 1002
#define ChannelConstants_INTERNAL_PRINTSTRING 1003
#define ChannelConstants_INTERNAL_PRINTINT 1004
#define ChannelConstants_INTERNAL_PRINTUWORD 1005
#define ChannelConstants_INTERNAL_PRINTOFFSET 1006
#define ChannelConstants_INTERNAL_PRINTLONG 1007
#define ChannelConstants_INTERNAL_PRINTADDRESS 1008
#define ChannelConstants_INTERNAL_GETTIME_LOW 1009
#define ChannelConstants_INTERNAL_GETTIME_HIGH 1010
#define ChannelConstants_INTERNAL_STOPVM 1011
#define ChannelConstants_INTERNAL_COPYBYTES 1012
#define ChannelConstants_INTERNAL_PRINTCONFIGURATION 1013
#define ChannelConstants_INTERNAL_PRINTGLOBALOOPNAME 1014
#define ChannelConstants_INTERNAL_PRINTGLOBALS 1015
#define ChannelConstants_INTERNAL_MATH 1016
#define ChannelConstants_INTERNAL_GETPATHSEPARATORCHAR 1017
#define ChannelConstants_INTERNAL_GETFILESEPARATORCHAR 1018
#define ChannelConstants_DUMMY 999
#define ChannelConstants_CHANNEL_LED 101
#define ChannelConstants_CHANNEL_SW 102
#define ChannelConstants_LED_OFF 201
#define ChannelConstants_LED_ON 202
#define ChannelConstants_SW_READ 203
#define ChannelConstants_PEEK 301
#define ChannelConstants_POKE 302
#define com_sun_squawk_vm_CID 70
#define CID_NULL 0
#define CID_OBJECT 1
#define CID_STRING 2
#define CID_THROWABLE 3
#define CID_CLASS 4
#define CID_VOID 5
#define CID_BOOLEAN 6
#define CID_BYTE 7
#define CID_CHAR 8
#define CID_SHORT 9
#define CID_INT 10
#define CID_LONG 11
#define CID_LONG2 12
#define CID_FLOAT 13
#define CID_DOUBLE 14
#define CID_DOUBLE2 15
#define CID_OBJECT_ARRAY 16
#define CID_STRING_ARRAY 17
#define CID_BOOLEAN_ARRAY 18
#define CID_BYTE_ARRAY 19
#define CID_CHAR_ARRAY 20
#define CID_SHORT_ARRAY 21
#define CID_INT_ARRAY 22
#define CID_LONG_ARRAY 23
#define CID_FLOAT_ARRAY 24
#define CID_DOUBLE_ARRAY 25
#define CID_STRING_OF_BYTES 26
#define CID_LOCAL 27
#define CID_GLOBAL 28
#define CID_LOCAL_ARRAY 29
#define CID_GLOBAL_ARRAY 30
#define CID_GLOBAL_ARRAYARRAY 31
#define CID_BYTECODE 32
#define CID_BYTECODE_ARRAY 33
#define CID_ADDRESS 34
#define CID_ADDRESS_ARRAY 35
#define CID_UWORD 36
#define CID_UWORD_ARRAY 37
#define CID_OFFSET 38
#define CID_UNSAFE 39
#define CID_LAST_CLASS_ID 39
#define com_sun_squawk_vm_CS 71
#define CS_klass 0
#define CS_next 1
#define CS_firstVariable 2
#define com_sun_squawk_vm_FieldOffsets 72
#define FieldOffsets_CIDSHIFT 32
#define FieldOffsets_OOP 4294967296
#define FieldOffsets_INT 42949672960
#define FieldOffsets_SHORT 38654705664
#define FieldOffsets_java_lang_Klass_self 4294967296
#define FieldOffsets_java_lang_ObjectAssociation_klass 4294967296
#define FieldOffsets_java_lang_Klass_virtualMethods 4294967297
#define FieldOffsets_java_lang_ObjectAssociation_virtualMethods 4294967297
#define FieldOffsets_java_lang_Klass_staticMethods 4294967298
#define FieldOffsets_java_lang_Klass_name 4294967299
#define FieldOffsets_java_lang_Klass_componentType 4294967300
#define FieldOffsets_java_lang_Klass_superType 4294967301
#define FieldOffsets_java_lang_Klass_objects 4294967304
#define FieldOffsets_java_lang_Klass_classID 42949672971
#define FieldOffsets_java_lang_Klass_modifiers 42949672972
#define FieldOffsets_java_lang_Klass_instanceSize 38654705692
#define FieldOffsets_com_sun_squawk_util_Hashtable_entryTable 4294967296
#define FieldOffsets_java_lang_Thread_isolate 4294967298
#define FieldOffsets_java_lang_Thread_stack 4294967299
#define com_sun_squawk_vm_FP 73
#define FP_parm0 3
#define FP_returnIP 2
#define FP_returnFP 1
#define FP_local0 0
#define FP_method 0
#define FP_FIXED_FRAME_SIZE 3
#define com_sun_squawk_vm_Global 74
#define Global_INT -8608480570021773312
#define Global_OOP -7378697632060801024
#define Global_ADDR -6148914694099828736
#define Global_TAGMASK -4294967296
#define com_sun_squawk_vm_HDR 75
#define HDR_BYTES_PER_WORD 4
#define HDR_LOG2_BYTES_PER_WORD 2
#define HDR_BITS_PER_WORD 32
#define HDR_LOG2_BITS_PER_WORD 5
#define HDR_klass -1
#define HDR_length -2
#define HDR_methodDefiningClass -3
#define HDR_methodInfoStart -13
#define HDR_basicHeaderSize 4
#define HDR_arrayHeaderSize 8
#define HDR_headerTagBits 2
#define HDR_headerTagMask 3
#define HDR_basicHeaderTag 0
#define HDR_arrayHeaderTag 1
#define HDR_methodHeaderTag 3
#define HDR_forwardPointerBit 2
#define com_sun_squawk_vm_MathOpcodes 76
#define MathOpcodes_SIN 1
#define MathOpcodes_COS 2
#define MathOpcodes_TAN 3
#define MathOpcodes_ASIN 4
#define MathOpcodes_ACOS 5
#define MathOpcodes_ATAN 6
#define MathOpcodes_EXP 7
#define MathOpcodes_LOG 8
#define MathOpcodes_SQRT 9
#define MathOpcodes_CEIL 10
#define MathOpcodes_FLOOR 11
#define MathOpcodes_ATAN2 12
#define MathOpcodes_POW 13
#define MathOpcodes_IEEE_REMAINDER 14
#define MathOpcodes_DUMMY 999
#define com_sun_squawk_vm_MethodOffsets 77
#define MethodOffsets_java_lang_VM_do_startup 1
#define MethodOffsets_java_lang_VM_do_undefinedNativeMethod 2
#define MethodOffsets_java_lang_VM_do_callRun 3
#define MethodOffsets_java_lang_VM_do_getStaticOop 4
#define MethodOffsets_java_lang_VM_do_getStaticInt 5
#define MethodOffsets_java_lang_VM_do_getStaticLong 6
#define MethodOffsets_java_lang_VM_do_putStaticOop 7
#define MethodOffsets_java_lang_VM_do_putStaticInt 8
#define MethodOffsets_java_lang_VM_do_putStaticLong 9
#define MethodOffsets_java_lang_VM_do_yield 10
#define MethodOffsets_java_lang_VM_do_nullPointerException 11
#define MethodOffsets_java_lang_VM_do_arrayIndexOutOfBoundsException 12
#define MethodOffsets_java_lang_VM_do_arithmeticException 13
#define MethodOffsets_java_lang_VM_do_arrayOopStore 14
#define MethodOffsets_java_lang_VM_do_findSlot 15
#define MethodOffsets_java_lang_VM_do_monitorenter 16
#define MethodOffsets_java_lang_VM_do_monitorexit 17
#define MethodOffsets_java_lang_VM_do_instanceof 18
#define MethodOffsets_java_lang_VM_do_checkcast 19
#define MethodOffsets_java_lang_VM_do_lookup_b 20
#define MethodOffsets_java_lang_VM_do_lookup_s 21
#define MethodOffsets_java_lang_VM_do_lookup_i 22
#define MethodOffsets_java_lang_VM_do_class_clinit 23
#define MethodOffsets_java_lang_VM_do_new 24
#define MethodOffsets_java_lang_VM_do_newarray 25
#define MethodOffsets_java_lang_VM_do_newdimension 26
#define MethodOffsets_java_lang_VM_do_lcmp 27
#define com_sun_squawk_vm_Mnemonics 78
#define com_sun_squawk_vm_Native 79
#define Native_java_lang_VM_addToClassStateCache 0
#define Native_java_lang_VM_allocate 1
#define Native_java_lang_VM_allocateVirtualStack 2
#define Native_java_lang_VM_asKlass 3
#define Native_java_lang_VM_asThread 4
#define Native_java_lang_VM_callStaticNoParm 5
#define Native_java_lang_VM_callStaticOneParm 6
#define Native_java_lang_VM_deadbeef 7
#define Native_java_lang_VM_executeCIO 8
#define Native_java_lang_VM_executeCOG 9
#define Native_java_lang_VM_executeGC 10
#define Native_java_lang_VM_fatalVMError 11
#define Native_java_lang_VM_getBranchCount 12
#define Native_java_lang_VM_getFP 13
#define Native_java_lang_VM_getGlobalAddr 14
#define Native_java_lang_VM_getGlobalAddrCount 15
#define Native_java_lang_VM_getGlobalInt 16
#define Native_java_lang_VM_getGlobalIntCount 17
#define Native_java_lang_VM_getGlobalOop 18
#define Native_java_lang_VM_getGlobalOopCount 19
#define Native_java_lang_VM_getGlobalOopTable 20
#define Native_java_lang_VM_getMP 21
#define Native_java_lang_VM_getPreviousFP 22
#define Native_java_lang_VM_getPreviousIP 23
#define Native_java_lang_VM_hasVirtualMonitorObject 24
#define Native_java_lang_VM_hashcode 25
#define Native_java_lang_VM_invalidateClassStateCache 26
#define Native_java_lang_VM_isBigEndian 27
#define Native_java_lang_VM_removeVirtualMonitorObject 28
#define Native_java_lang_VM_serviceResult 29
#define Native_java_lang_VM_setGlobalAddr 30
#define Native_java_lang_VM_setGlobalInt 31
#define Native_java_lang_VM_setGlobalOop 32
#define Native_java_lang_VM_setPreviousFP 33
#define Native_java_lang_VM_setPreviousIP 34
#define Native_java_lang_VM_setWriteBarrier 35
#define Native_java_lang_VM_threadSwitch 36
#define Native_java_lang_VM_zeroWords 37
#define Native_java_lang_Address_add 38
#define Native_java_lang_Address_addOffset 39
#define Native_java_lang_Address_and 40
#define Native_java_lang_Address_diff 41
#define Native_java_lang_Address_eq 42
#define Native_java_lang_Address_fromObject 43
#define Native_java_lang_Address_hi 44
#define Native_java_lang_Address_hieq 45
#define Native_java_lang_Address_isMax 46
#define Native_java_lang_Address_isZero 47
#define Native_java_lang_Address_lo 48
#define Native_java_lang_Address_loeq 49
#define Native_java_lang_Address_max 50
#define Native_java_lang_Address_ne 51
#define Native_java_lang_Address_or 52
#define Native_java_lang_Address_roundDown 53
#define Native_java_lang_Address_roundDownToWord 54
#define Native_java_lang_Address_roundUp 55
#define Native_java_lang_Address_roundUpToWord 56
#define Native_java_lang_Address_sub 57
#define Native_java_lang_Address_subOffset 58
#define Native_java_lang_Address_toObject 59
#define Native_java_lang_Address_toUWord 60
#define Native_java_lang_Address_zero 61
#define Native_java_lang_UWord_and 62
#define Native_java_lang_UWord_eq 63
#define Native_java_lang_UWord_fromPrimitive 64
#define Native_java_lang_UWord_hi 65
#define Native_java_lang_UWord_hieq 66
#define Native_java_lang_UWord_isMax 67
#define Native_java_lang_UWord_isZero 68
#define Native_java_lang_UWord_lo 69
#define Native_java_lang_UWord_loeq 70
#define Native_java_lang_UWord_max 71
#define Native_java_lang_UWord_ne 72
#define Native_java_lang_UWord_or 73
#define Native_java_lang_UWord_toInt 74
#define Native_java_lang_UWord_toOffset 75
#define Native_java_lang_UWord_toPrimitive 76
#define Native_java_lang_UWord_zero 77
#define Native_java_lang_Offset_add 78
#define Native_java_lang_Offset_eq 79
#define Native_java_lang_Offset_fromPrimitive 80
#define Native_java_lang_Offset_ge 81
#define Native_java_lang_Offset_gt 82
#define Native_java_lang_Offset_isZero 83
#define Native_java_lang_Offset_le 84
#define Native_java_lang_Offset_lt 85
#define Native_java_lang_Offset_ne 86
#define Native_java_lang_Offset_sub 87
#define Native_java_lang_Offset_toInt 88
#define Native_java_lang_Offset_toPrimitive 89
#define Native_java_lang_Offset_toUWord 90
#define Native_java_lang_Offset_zero 91
#define Native_java_lang_Unsafe_charAt 92
#define Native_java_lang_Unsafe_copyTypes 93
#define Native_java_lang_Unsafe_getAsByte 94
#define Native_java_lang_Unsafe_getAsUWord 95
#define Native_java_lang_Unsafe_getByte 96
#define Native_java_lang_Unsafe_getChar 97
#define Native_java_lang_Unsafe_getInt 98
#define Native_java_lang_Unsafe_getLong 99
#define Native_java_lang_Unsafe_getLongAtWord 100
#define Native_java_lang_Unsafe_getObject 101
#define Native_java_lang_Unsafe_getShort 102
#define Native_java_lang_Unsafe_getType 103
#define Native_java_lang_Unsafe_getUWord 104
#define Native_java_lang_Unsafe_setAddress 105
#define Native_java_lang_Unsafe_setByte 106
#define Native_java_lang_Unsafe_setChar 107
#define Native_java_lang_Unsafe_setInt 108
#define Native_java_lang_Unsafe_setLong 109
#define Native_java_lang_Unsafe_setLongAtWord 110
#define Native_java_lang_Unsafe_setObject 111
#define Native_java_lang_Unsafe_setShort 112
#define Native_java_lang_Unsafe_setType 113
#define Native_java_lang_Unsafe_setUWord 114
#define Native_java_lang_CheneyCollector_memoryProtect 115
#define Native_java_lang_ServiceOperation_cioExecute 116
#define Native_java_lang_VM_lcmp 117
#define Native_ENTRY_COUNT 118
#define com_sun_squawk_vm_OPC 80
#define OPC_CONST_0 0
#define OPC_CONST_1 1
#define OPC_CONST_2 2
#define OPC_CONST_3 3
#define OPC_CONST_4 4
#define OPC_CONST_5 5
#define OPC_CONST_6 6
#define OPC_CONST_7 7
#define OPC_CONST_8 8
#define OPC_CONST_9 9
#define OPC_CONST_10 10
#define OPC_CONST_11 11
#define OPC_CONST_12 12
#define OPC_CONST_13 13
#define OPC_CONST_14 14
#define OPC_CONST_15 15
#define OPC_OBJECT_0 16
#define OPC_OBJECT_1 17
#define OPC_OBJECT_2 18
#define OPC_OBJECT_3 19
#define OPC_OBJECT_4 20
#define OPC_OBJECT_5 21
#define OPC_OBJECT_6 22
#define OPC_OBJECT_7 23
#define OPC_OBJECT_8 24
#define OPC_OBJECT_9 25
#define OPC_OBJECT_10 26
#define OPC_OBJECT_11 27
#define OPC_OBJECT_12 28
#define OPC_OBJECT_13 29
#define OPC_OBJECT_14 30
#define OPC_OBJECT_15 31
#define OPC_LOAD_0 32
#define OPC_LOAD_1 33
#define OPC_LOAD_2 34
#define OPC_LOAD_3 35
#define OPC_LOAD_4 36
#define OPC_LOAD_5 37
#define OPC_LOAD_6 38
#define OPC_LOAD_7 39
#define OPC_LOAD_8 40
#define OPC_LOAD_9 41
#define OPC_LOAD_10 42
#define OPC_LOAD_11 43
#define OPC_LOAD_12 44
#define OPC_LOAD_13 45
#define OPC_LOAD_14 46
#define OPC_LOAD_15 47
#define OPC_STORE_0 48
#define OPC_STORE_1 49
#define OPC_STORE_2 50
#define OPC_STORE_3 51
#define OPC_STORE_4 52
#define OPC_STORE_5 53
#define OPC_STORE_6 54
#define OPC_STORE_7 55
#define OPC_STORE_8 56
#define OPC_STORE_9 57
#define OPC_STORE_10 58
#define OPC_STORE_11 59
#define OPC_STORE_12 60
#define OPC_STORE_13 61
#define OPC_STORE_14 62
#define OPC_STORE_15 63
#define OPC_LOADPARM_0 64
#define OPC_LOADPARM_1 65
#define OPC_LOADPARM_2 66
#define OPC_LOADPARM_3 67
#define OPC_LOADPARM_4 68
#define OPC_LOADPARM_5 69
#define OPC_LOADPARM_6 70
#define OPC_LOADPARM_7 71
#define OPC_WIDE_M1 72
#define OPC_WIDE_0 73
#define OPC_WIDE_1 74
#define OPC_WIDE_SHORT 75
#define OPC_WIDE_INT 76
#define OPC_ESCAPE 77
#define OPC_ESCAPE_WIDE_M1 78
#define OPC_ESCAPE_WIDE_0 79
#define OPC_ESCAPE_WIDE_1 80
#define OPC_ESCAPE_WIDE_SHORT 81
#define OPC_ESCAPE_WIDE_INT 82
#define OPC_CATCH 83
#define OPC_CONST_NULL 84
#define OPC_CONST_M1 85
#define OPC_CONST_BYTE 86
#define OPC_CONST_SHORT 87
#define OPC_CONST_CHAR 88
#define OPC_CONST_INT 89
#define OPC_CONST_LONG 90
#define OPC_OBJECT 91
#define OPC_LOAD 92
#define OPC_LOAD_I2 93
#define OPC_STORE 94
#define OPC_STORE_I2 95
#define OPC_LOADPARM 96
#define OPC_LOADPARM_I2 97
#define OPC_STOREPARM 98
#define OPC_STOREPARM_I2 99
#define OPC_INC 100
#define OPC_DEC 101
#define OPC_INCPARM 102
#define OPC_DECPARM 103
#define OPC_GOTO 104
#define OPC_IF_EQ_O 105
#define OPC_IF_NE_O 106
#define OPC_IF_CMPEQ_O 107
#define OPC_IF_CMPNE_O 108
#define OPC_IF_EQ_I 109
#define OPC_IF_NE_I 110
#define OPC_IF_LT_I 111
#define OPC_IF_LE_I 112
#define OPC_IF_GT_I 113
#define OPC_IF_GE_I 114
#define OPC_IF_CMPEQ_I 115
#define OPC_IF_CMPNE_I 116
#define OPC_IF_CMPLT_I 117
#define OPC_IF_CMPLE_I 118
#define OPC_IF_CMPGT_I 119
#define OPC_IF_CMPGE_I 120
#define OPC_IF_EQ_L 121
#define OPC_IF_NE_L 122
#define OPC_IF_LT_L 123
#define OPC_IF_LE_L 124
#define OPC_IF_GT_L 125
#define OPC_IF_GE_L 126
#define OPC_IF_CMPEQ_L 127
#define OPC_IF_CMPNE_L 128
#define OPC_IF_CMPLT_L 129
#define OPC_IF_CMPLE_L 130
#define OPC_IF_CMPGT_L 131
#define OPC_IF_CMPGE_L 132
#define OPC_GETSTATIC_I 133
#define OPC_GETSTATIC_O 134
#define OPC_GETSTATIC_L 135
#define OPC_CLASS_GETSTATIC_I 136
#define OPC_CLASS_GETSTATIC_O 137
#define OPC_CLASS_GETSTATIC_L 138
#define OPC_PUTSTATIC_I 139
#define OPC_PUTSTATIC_O 140
#define OPC_PUTSTATIC_L 141
#define OPC_CLASS_PUTSTATIC_I 142
#define OPC_CLASS_PUTSTATIC_O 143
#define OPC_CLASS_PUTSTATIC_L 144
#define OPC_GETFIELD_I 145
#define OPC_GETFIELD_B 146
#define OPC_GETFIELD_S 147
#define OPC_GETFIELD_C 148
#define OPC_GETFIELD_O 149
#define OPC_GETFIELD_L 150
#define OPC_THIS_GETFIELD_I 151
#define OPC_THIS_GETFIELD_B 152
#define OPC_THIS_GETFIELD_S 153
#define OPC_THIS_GETFIELD_C 154
#define OPC_THIS_GETFIELD_O 155
#define OPC_THIS_GETFIELD_L 156
#define OPC_PUTFIELD_I 157
#define OPC_PUTFIELD_B 158
#define OPC_PUTFIELD_S 159
#define OPC_PUTFIELD_O 160
#define OPC_PUTFIELD_L 161
#define OPC_THIS_PUTFIELD_I 162
#define OPC_THIS_PUTFIELD_B 163
#define OPC_THIS_PUTFIELD_S 164
#define OPC_THIS_PUTFIELD_O 165
#define OPC_THIS_PUTFIELD_L 166
#define OPC_INVOKEVIRTUAL_I 167
#define OPC_INVOKEVIRTUAL_V 168
#define OPC_INVOKEVIRTUAL_L 169
#define OPC_INVOKEVIRTUAL_O 170
#define OPC_INVOKESTATIC_I 171
#define OPC_INVOKESTATIC_V 172
#define OPC_INVOKESTATIC_L 173
#define OPC_INVOKESTATIC_O 174
#define OPC_INVOKESUPER_I 175
#define OPC_INVOKESUPER_V 176
#define OPC_INVOKESUPER_L 177
#define OPC_INVOKESUPER_O 178
#define OPC_INVOKENATIVE_I 179
#define OPC_INVOKENATIVE_V 180
#define OPC_INVOKENATIVE_L 181
#define OPC_INVOKENATIVE_O 182
#define OPC_FINDSLOT 183
#define OPC_EXTEND 184
#define OPC_INVOKESLOT_I 185
#define OPC_INVOKESLOT_V 186
#define OPC_INVOKESLOT_L 187
#define OPC_INVOKESLOT_O 188
#define OPC_RETURN_V 189
#define OPC_RETURN_I 190
#define OPC_RETURN_L 191
#define OPC_RETURN_O 192
#define OPC_TABLESWITCH_I 193
#define OPC_TABLESWITCH_S 194
#define OPC_EXTEND0 195
#define OPC_ADD_I 196
#define OPC_SUB_I 197
#define OPC_AND_I 198
#define OPC_OR_I 199
#define OPC_XOR_I 200
#define OPC_SHL_I 201
#define OPC_SHR_I 202
#define OPC_USHR_I 203
#define OPC_MUL_I 204
#define OPC_DIV_I 205
#define OPC_REM_I 206
#define OPC_NEG_I 207
#define OPC_I2B 208
#define OPC_I2S 209
#define OPC_I2C 210
#define OPC_ADD_L 211
#define OPC_SUB_L 212
#define OPC_MUL_L 213
#define OPC_DIV_L 214
#define OPC_REM_L 215
#define OPC_AND_L 216
#define OPC_OR_L 217
#define OPC_XOR_L 218
#define OPC_NEG_L 219
#define OPC_SHL_L 220
#define OPC_SHR_L 221
#define OPC_USHR_L 222
#define OPC_L2I 223
#define OPC_I2L 224
#define OPC_THROW 225
#define OPC_POP_1 226
#define OPC_POP_2 227
#define OPC_MONITORENTER 228
#define OPC_MONITOREXIT 229
#define OPC_CLASS_MONITORENTER 230
#define OPC_CLASS_MONITOREXIT 231
#define OPC_ARRAYLENGTH 232
#define OPC_NEW 233
#define OPC_NEWARRAY 234
#define OPC_NEWDIMENSION 235
#define OPC_CLASS_CLINIT 236
#define OPC_BBTARGET_SYS 237
#define OPC_BBTARGET_APP 238
#define OPC_INSTANCEOF 239
#define OPC_CHECKCAST 240
#define OPC_ALOAD_I 241
#define OPC_ALOAD_B 242
#define OPC_ALOAD_S 243
#define OPC_ALOAD_C 244
#define OPC_ALOAD_O 245
#define OPC_ALOAD_L 246
#define OPC_ASTORE_I 247
#define OPC_ASTORE_B 248
#define OPC_ASTORE_S 249
#define OPC_ASTORE_O 250
#define OPC_ASTORE_L 251
#define OPC_LOOKUP_I 252
#define OPC_LOOKUP_B 253
#define OPC_LOOKUP_S 254
#define OPC_RES_0 255
#define OPC_OBJECT_WIDE 256
#define OPC_LOAD_WIDE 257
#define OPC_LOAD_I2_WIDE 258
#define OPC_STORE_WIDE 259
#define OPC_STORE_I2_WIDE 260
#define OPC_LOADPARM_WIDE 261
#define OPC_LOADPARM_I2_WIDE 262
#define OPC_STOREPARM_WIDE 263
#define OPC_STOREPARM_I2_WIDE 264
#define OPC_INC_WIDE 265
#define OPC_DEC_WIDE 266
#define OPC_INCPARM_WIDE 267
#define OPC_DECPARM_WIDE 268
#define OPC_GOTO_WIDE 269
#define OPC_IF_EQ_O_WIDE 270
#define OPC_IF_NE_O_WIDE 271
#define OPC_IF_CMPEQ_O_WIDE 272
#define OPC_IF_CMPNE_O_WIDE 273
#define OPC_IF_EQ_I_WIDE 274
#define OPC_IF_NE_I_WIDE 275
#define OPC_IF_LT_I_WIDE 276
#define OPC_IF_LE_I_WIDE 277
#define OPC_IF_GT_I_WIDE 278
#define OPC_IF_GE_I_WIDE 279
#define OPC_IF_CMPEQ_I_WIDE 280
#define OPC_IF_CMPNE_I_WIDE 281
#define OPC_IF_CMPLT_I_WIDE 282
#define OPC_IF_CMPLE_I_WIDE 283
#define OPC_IF_CMPGT_I_WIDE 284
#define OPC_IF_CMPGE_I_WIDE 285
#define OPC_IF_EQ_L_WIDE 286
#define OPC_IF_NE_L_WIDE 287
#define OPC_IF_LT_L_WIDE 288
#define OPC_IF_LE_L_WIDE 289
#define OPC_IF_GT_L_WIDE 290
#define OPC_IF_GE_L_WIDE 291
#define OPC_IF_CMPEQ_L_WIDE 292
#define OPC_IF_CMPNE_L_WIDE 293
#define OPC_IF_CMPLT_L_WIDE 294
#define OPC_IF_CMPLE_L_WIDE 295
#define OPC_IF_CMPGT_L_WIDE 296
#define OPC_IF_CMPGE_L_WIDE 297
#define OPC_GETSTATIC_I_WIDE 298
#define OPC_GETSTATIC_O_WIDE 299
#define OPC_GETSTATIC_L_WIDE 300
#define OPC_CLASS_GETSTATIC_I_WIDE 301
#define OPC_CLASS_GETSTATIC_O_WIDE 302
#define OPC_CLASS_GETSTATIC_L_WIDE 303
#define OPC_PUTSTATIC_I_WIDE 304
#define OPC_PUTSTATIC_O_WIDE 305
#define OPC_PUTSTATIC_L_WIDE 306
#define OPC_CLASS_PUTSTATIC_I_WIDE 307
#define OPC_CLASS_PUTSTATIC_O_WIDE 308
#define OPC_CLASS_PUTSTATIC_L_WIDE 309
#define OPC_GETFIELD_I_WIDE 310
#define OPC_GETFIELD_B_WIDE 311
#define OPC_GETFIELD_S_WIDE 312
#define OPC_GETFIELD_C_WIDE 313
#define OPC_GETFIELD_O_WIDE 314
#define OPC_GETFIELD_L_WIDE 315
#define OPC_THIS_GETFIELD_I_WIDE 316
#define OPC_THIS_GETFIELD_B_WIDE 317
#define OPC_THIS_GETFIELD_S_WIDE 318
#define OPC_THIS_GETFIELD_C_WIDE 319
#define OPC_THIS_GETFIELD_O_WIDE 320
#define OPC_THIS_GETFIELD_L_WIDE 321
#define OPC_PUTFIELD_I_WIDE 322
#define OPC_PUTFIELD_B_WIDE 323
#define OPC_PUTFIELD_S_WIDE 324
#define OPC_PUTFIELD_O_WIDE 325
#define OPC_PUTFIELD_L_WIDE 326
#define OPC_THIS_PUTFIELD_I_WIDE 327
#define OPC_THIS_PUTFIELD_B_WIDE 328
#define OPC_THIS_PUTFIELD_S_WIDE 329
#define OPC_THIS_PUTFIELD_O_WIDE 330
#define OPC_THIS_PUTFIELD_L_WIDE 331
#define OPC_INVOKEVIRTUAL_I_WIDE 332
#define OPC_INVOKEVIRTUAL_V_WIDE 333
#define OPC_INVOKEVIRTUAL_L_WIDE 334
#define OPC_INVOKEVIRTUAL_O_WIDE 335
#define OPC_INVOKESTATIC_I_WIDE 336
#define OPC_INVOKESTATIC_V_WIDE 337
#define OPC_INVOKESTATIC_L_WIDE 338
#define OPC_INVOKESTATIC_O_WIDE 339
#define OPC_INVOKESUPER_I_WIDE 340
#define OPC_INVOKESUPER_V_WIDE 341
#define OPC_INVOKESUPER_L_WIDE 342
#define OPC_INVOKESUPER_O_WIDE 343
#define OPC_INVOKENATIVE_I_WIDE 344
#define OPC_INVOKENATIVE_V_WIDE 345
#define OPC_INVOKENATIVE_L_WIDE 346
#define OPC_INVOKENATIVE_O_WIDE 347
#define OPC_FINDSLOT_WIDE 348
#define OPC_EXTEND_WIDE 349
#define OPC_DUMMY 0
#define OPC_CONST_0_COUNT 16
#define OPC_OBJECT_0_COUNT 16
#define OPC_LOAD_0_COUNT 16
#define OPC_STORE_0_COUNT 16
#define OPC_LOADPARM_0_COUNT 8
#define OPC_RES_0_COUNT 1
#define OPC_BYTECODE_COUNT 256
#define OPC_FIRST_PARM_BYTECODE 91
#define OPC_PARM_BYTECODE_COUNT 94
#define OPC_FIRST_ESCAPE_PARM_BYTECODE -1
#define OPC_ESCAPE_PARM_BYTECODE_COUNT 0
#define OPC_FIRST_WIDE_PSEUDOCODE 256
#define OPC_FIRST_ESCAPE_WIDE_PSEUDOCODE -1
#define OPC_PSEUDOCODE_COUNT 94
#define OPC_WIDE_DELTA 165
#define OPC_ESCAPE_WIDE_DELTA 0
#define com_sun_squawk_vm_SC 81
#define SC_next 0
#define SC_owner 1
#define SC_lastFP 2
#define SC_lastIP 3
#define SC_guard 4
#define SC_limit 5
#define SC_oopMap 3
#define com_sun_squawk_util_Hashtable_HashtableEnumerator 82
#define com_sun_squawk_util_Hashtable_HashtableEnumerator_index(oop) getInt(oop, 0)
#define com_sun_squawk_util_Hashtable_HashtableEnumerator_table(oop) getObject(oop, 1)
#define com_sun_squawk_util_Hashtable_HashtableEnumerator_entry(oop) getObject(oop, 2)
#define com_sun_squawk_util_Hashtable_HashtableEnumerator_this_0(oop) getObject(oop, 3)
#define com_sun_squawk_util_Hashtable_HashtableEnumerator_keys(oop) getByte(oop, 16)
#define com_sun_squawk_util_HashtableEntry 83
#define com_sun_squawk_util_HashtableEntry_hash(oop) getInt(oop, 0)
#define com_sun_squawk_util_HashtableEntry_key(oop) getObject(oop, 1)
#define com_sun_squawk_util_HashtableEntry_value(oop) getObject(oop, 2)
#define com_sun_squawk_util_HashtableEntry_next(oop) getObject(oop, 3)
#define com_sun_squawk_util_ArgsUtilities 84
#define com_sun_squawk_util_ArrayHashtable_ArrayHashtableEnumerator 85
#define com_sun_squawk_util_ArrayHashtable_ArrayHashtableEnumerator_index(oop) getInt(oop, 0)
#define com_sun_squawk_util_ArrayHashtable_ArrayHashtableEnumerator_table(oop) getObject(oop, 1)
#define com_sun_squawk_util_ArrayHashtable_ArrayHashtableEnumerator_entry(oop) getObject(oop, 2)
#define com_sun_squawk_util_ArrayHashtable_ArrayHashtableEnumerator_this_0(oop) getObject(oop, 3)
#define com_sun_squawk_util_ArrayHashtable_ArrayHashtableEnumerator_keys(oop) getByte(oop, 16)
#define com_sun_squawk_util_ArrayHashtableEntry 86
#define com_sun_squawk_util_ArrayHashtableEntry_hash(oop) getInt(oop, 0)
#define com_sun_squawk_util_ArrayHashtableEntry_key(oop) getObject(oop, 1)
#define com_sun_squawk_util_ArrayHashtableEntry_value(oop) getObject(oop, 2)
#define com_sun_squawk_util_ArrayHashtableEntry_next(oop) getObject(oop, 3)
#define com_sun_squawk_util_Arrays 87
#define com_sun_squawk_util_Comparer 88
#define com_sun_squawk_util_Assert 89
#define com_sun_squawk_util_BitSetTable 90
#define com_sun_squawk_util_DataInputUTF8Decoder 91
#define com_sun_squawk_util_IntHashtable_HashtableEnumerator 92
#define com_sun_squawk_util_IntHashtable_HashtableEnumerator_index(oop) getInt(oop, 0)
#define com_sun_squawk_util_IntHashtable_HashtableEnumerator_table(oop) getObject(oop, 1)
#define com_sun_squawk_util_IntHashtable_HashtableEnumerator_entry(oop) getObject(oop, 2)
#define com_sun_squawk_util_IntHashtable_HashtableEnumerator_this_0(oop) getObject(oop, 3)
#define com_sun_squawk_util_IntHashtable_HashtableEnumerator_keys(oop) getByte(oop, 16)
#define com_sun_squawk_util_IntHashtableEntry 93
#define com_sun_squawk_util_IntHashtableEntry_key(oop) getInt(oop, 0)
#define com_sun_squawk_util_IntHashtableEntry_value(oop) getObject(oop, 1)
#define com_sun_squawk_util_IntHashtableEntry_next(oop) getObject(oop, 2)
#define com_sun_squawk_util_IntHashtableVisitor 94
#define com_sun_squawk_util_LineReader 95
#define com_sun_squawk_util_LineReader_in(oop) getObject(oop, 0)
#define com_sun_squawk_util_LongHashtable_HashtableEnumerator 96
#define com_sun_squawk_util_LongHashtable_HashtableEnumerator_index(oop) getInt(oop, 0)
#define com_sun_squawk_util_LongHashtable_HashtableEnumerator_table(oop) getObject(oop, 1)
#define com_sun_squawk_util_LongHashtable_HashtableEnumerator_entry(oop) getObject(oop, 2)
#define com_sun_squawk_util_LongHashtable_HashtableEnumerator_this_0(oop) getObject(oop, 3)
#define com_sun_squawk_util_LongHashtable_HashtableEnumerator_keys(oop) getByte(oop, 16)
#define com_sun_squawk_util_LongHashtable 97
#define com_sun_squawk_util_LongHashtable_table(oop) getObject(oop, 0)
#define com_sun_squawk_util_LongHashtable_count(oop) getInt(oop, 1)
#define com_sun_squawk_util_LongHashtable_threshold(oop) getInt(oop, 2)
#define com_sun_squawk_util_LongHashtable_loadFactorPercent 75
#define com_sun_squawk_util_LongHashtableEntry 98
#define com_sun_squawk_util_LongHashtableEntry_key(oop) getLongAtWord(oop, 0)
#define com_sun_squawk_util_LongHashtableEntry_value(oop) getObject(oop, 2)
#define com_sun_squawk_util_LongHashtableEntry_next(oop) getObject(oop, 3)
#define com_sun_squawk_util_Stack 99
#define com_sun_squawk_util_StructuredFileInputStream 100
#define com_sun_squawk_util_StructuredFileInputStream_filePath(oop) getObject(oop, 0)
#define com_sun_squawk_util_StructuredFileInputStream_in(oop) getObject(oop, 1)
#define com_sun_squawk_util_StructuredFileInputStream_traceFeature(oop) getObject(oop, 2)
#define com_sun_squawk_util_Tracer 101
#define com_sun_squawk_util_VectorEnumerator 102
#define com_sun_squawk_util_VectorEnumerator_vector(oop) getObject(oop, 0)
#define com_sun_squawk_util_VectorEnumerator_count(oop) getInt(oop, 1)
#define com_sun_squawk_util_VectorEnumerator_isBaseClass(oop) getByte(oop, 8)
#define com_sun_squawk_io_connections_ClasspathConnection 103
#define com_sun_squawk_io_j2me_channel_ChannelInputStream 104
#define com_sun_squawk_io_j2me_channel_ChannelInputStream_parent(oop) getObject(oop, 1)
#define com_sun_squawk_io_j2me_channel_ChannelInputStream_channelID(oop) getInt(oop, 2)
#define com_sun_squawk_io_j2me_channel_Protocol 105
#define com_sun_squawk_io_j2me_channel_Protocol_channelID(oop) getInt(oop, 0)
#define com_sun_squawk_io_j2me_channel_Protocol_useCount(oop) getInt(oop, 1)
#define com_sun_squawk_io_j2me_channel_ChannelOutputStream 106
#define com_sun_squawk_io_j2me_channel_ChannelOutputStream_parent(oop) getObject(oop, 1)
#define com_sun_squawk_io_j2me_channel_ChannelOutputStream_channelID(oop) getInt(oop, 2)
#define com_sun_squawk_io_j2me_classpath_Protocol 107
#define com_sun_squawk_io_j2me_classpath_Protocol_classPathArray(oop) getObject(oop, 0)
#define com_sun_squawk_io_j2me_classpath_Protocol_MULTIPLEINSTANCESCHECK(oop) getByte(oop, 4)
#define com_sun_squawk_io_j2me_debug_Protocol 108
#define com_sun_squawk_io_j2me_debug_Protocol_opened(oop) getByte(oop, 0)
#define com_sun_squawk_io_j2me_debug_Protocol_err(oop) getByte(oop, 1)
#define com_sun_squawk_io_j2me_debug_PrivateOutputStream 109
#define com_sun_squawk_io_j2me_debug_PrivateOutputStream_parent(oop) getObject(oop, 0)
#define com_sun_squawk_io_j2me_http_Protocol_PrivateInputStream 110
#define com_sun_squawk_io_j2me_http_Protocol_PrivateInputStream_bytesleft(oop) getInt(oop, 0)
#define com_sun_squawk_io_j2me_http_Protocol_PrivateInputStream_bytesread(oop) getInt(oop, 1)
#define com_sun_squawk_io_j2me_http_Protocol_PrivateInputStream_this_0(oop) getObject(oop, 2)
#define com_sun_squawk_io_j2me_http_Protocol_PrivateInputStream_chunked(oop) getByte(oop, 12)
#define com_sun_squawk_io_j2me_http_Protocol_PrivateInputStream_eof(oop) getByte(oop, 13)
#define com_sun_squawk_io_j2me_http_Protocol_PrivateOutputStream 111
#define com_sun_squawk_io_j2me_http_Protocol_PrivateOutputStream_output(oop) getObject(oop, 0)
#define com_sun_squawk_io_j2me_http_Protocol_PrivateOutputStream_this_0(oop) getObject(oop, 1)
#define com_sun_squawk_io_j2me_http_Protocol 112
#define com_sun_squawk_io_j2me_http_Protocol_index(oop) getInt(oop, 0)
#define com_sun_squawk_io_j2me_http_Protocol_url(oop) getObject(oop, 1)
#define com_sun_squawk_io_j2me_http_Protocol_protocol(oop) getObject(oop, 2)
#define com_sun_squawk_io_j2me_http_Protocol_host(oop) getObject(oop, 3)
#define com_sun_squawk_io_j2me_http_Protocol_file(oop) getObject(oop, 4)
#define com_sun_squawk_io_j2me_http_Protocol_ref(oop) getObject(oop, 5)
#define com_sun_squawk_io_j2me_http_Protocol_query(oop) getObject(oop, 6)
#define com_sun_squawk_io_j2me_http_Protocol_port(oop) getInt(oop, 7)
#define com_sun_squawk_io_j2me_http_Protocol_responseCode(oop) getInt(oop, 8)
#define com_sun_squawk_io_j2me_http_Protocol_responseMsg(oop) getObject(oop, 9)
#define com_sun_squawk_io_j2me_http_Protocol_reqProperties(oop) getObject(oop, 10)
#define com_sun_squawk_io_j2me_http_Protocol_headerFields(oop) getObject(oop, 11)
#define com_sun_squawk_io_j2me_http_Protocol_headerFieldNames(oop) getObject(oop, 12)
#define com_sun_squawk_io_j2me_http_Protocol_headerFieldValues(oop) getObject(oop, 13)
#define com_sun_squawk_io_j2me_http_Protocol_method(oop) getObject(oop, 14)
#define com_sun_squawk_io_j2me_http_Protocol_opens(oop) getInt(oop, 15)
#define com_sun_squawk_io_j2me_http_Protocol_mode(oop) getInt(oop, 16)
#define com_sun_squawk_io_j2me_http_Protocol_in(oop) getObject(oop, 17)
#define com_sun_squawk_io_j2me_http_Protocol_out(oop) getObject(oop, 18)
#define com_sun_squawk_io_j2me_http_Protocol_streamConnnection(oop) getObject(oop, 19)
#define com_sun_squawk_io_j2me_http_Protocol_streamOutput(oop) getObject(oop, 20)
#define com_sun_squawk_io_j2me_http_Protocol_streamInput(oop) getObject(oop, 21)
#define com_sun_squawk_io_j2me_http_Protocol_stringbuffer(oop) getObject(oop, 22)
#define com_sun_squawk_io_j2me_http_Protocol_http_version(oop) getObject(oop, 23)
#define com_sun_squawk_io_j2me_http_Protocol_connected(oop) getByte(oop, 96)
#define com_sun_squawk_io_j2me_resource_Protocol 113
#define com_sun_squawk_io_j2me_resource_Protocol_pathConnection(oop) getObject(oop, 0)
#define com_sun_squawk_io_j2me_resource_Protocol_name(oop) getObject(oop, 1)
#define com_sun_squawk_io_j2me_flash_Protocol_MemoryInputStream 114
#define com_sun_squawk_io_j2me_flash_Protocol_MemoryInputStream_parent(oop) getObject(oop, 0)
#define com_sun_squawk_io_j2me_flash_Protocol_MemoryInputStream_currentMemoryPointer(oop) getInt(oop, 1)
#define com_sun_squawk_io_j2me_flash_Protocol_MemoryInputStream_this_0(oop) getObject(oop, 2)
#define com_sun_squawk_io_j2me_flash_Protocol 115
#define com_sun_squawk_io_j2me_flash_Protocol_memoryBase(oop) getInt(oop, 0)
#define com_sun_squawk_io_ConnectionBase 116
#define com_sun_cldc_i18n_j2me_ISO8859_1_Reader 117
#define com_sun_cldc_i18n_j2me_ISO8859_1_Writer 118
#define com_sun_cldc_i18n_j2me_ISO8859_1_Writer_buf(oop) getObject(oop, 3)
#define com_sun_cldc_i18n_j2me_ISO8859_1_Writer_BUFFERSIZE 32
#define com_sun_cldc_i18n_uclc_DefaultCaseConverter 119
#define com_sun_cldc_i18n_Helper 120
#define com_sun_cldc_i18n_StreamReader 121
#define com_sun_cldc_i18n_StreamReader_in(oop) getObject(oop, 2)
#define com_sun_cldc_i18n_StreamWriter 122
#define com_sun_cldc_i18n_StreamWriter_out(oop) getObject(oop, 2)
#define com_sun_cldc_io_connections_HttpConnection 123
#define com_sun_cldc_io_connections_HttpConnection_HTTP_OK 200
#define com_sun_cldc_io_connections_HttpConnection_HTTP_CREATED 201
#define com_sun_cldc_io_connections_HttpConnection_HTTP_ACCEPTED 202
#define com_sun_cldc_io_connections_HttpConnection_HTTP_NOT_AUTHORITATIVE 203
#define com_sun_cldc_io_connections_HttpConnection_HTTP_NO_CONTENT 204
#define com_sun_cldc_io_connections_HttpConnection_HTTP_RESET 205
#define com_sun_cldc_io_connections_HttpConnection_HTTP_PARTIAL 206
#define com_sun_cldc_io_connections_HttpConnection_HTTP_MULT_CHOICE 300
#define com_sun_cldc_io_connections_HttpConnection_HTTP_MOVED_PERM 301
#define com_sun_cldc_io_connections_HttpConnection_HTTP_MOVED_TEMP 302
#define com_sun_cldc_io_connections_HttpConnection_HTTP_SEE_OTHER 303
#define com_sun_cldc_io_connections_HttpConnection_HTTP_NOT_MODIFIED 304
#define com_sun_cldc_io_connections_HttpConnection_HTTP_USE_PROXY 305
#define com_sun_cldc_io_connections_HttpConnection_HTTP_TEMP_REDIRECT 307
#define com_sun_cldc_io_connections_HttpConnection_HTTP_BAD_REQUEST 400
#define com_sun_cldc_io_connections_HttpConnection_HTTP_UNAUTHORIZED 401
#define com_sun_cldc_io_connections_HttpConnection_HTTP_PAYMENT_REQUIRED 402
#define com_sun_cldc_io_connections_HttpConnection_HTTP_FORBIDDEN 403
#define com_sun_cldc_io_connections_HttpConnection_HTTP_NOT_FOUND 404
#define com_sun_cldc_io_connections_HttpConnection_HTTP_BAD_METHOD 405
#define com_sun_cldc_io_connections_HttpConnection_HTTP_NOT_ACCEPTABLE 406
#define com_sun_cldc_io_connections_HttpConnection_HTTP_PROXY_AUTH 407
#define com_sun_cldc_io_connections_HttpConnection_HTTP_CLIENT_TIMEOUT 408
#define com_sun_cldc_io_connections_HttpConnection_HTTP_CONFLICT 409
#define com_sun_cldc_io_connections_HttpConnection_HTTP_GONE 410
#define com_sun_cldc_io_connections_HttpConnection_HTTP_LENGTH_REQUIRED 411
#define com_sun_cldc_io_connections_HttpConnection_HTTP_PRECON_FAILED 412
#define com_sun_cldc_io_connections_HttpConnection_HTTP_ENTITY_TOO_LARGE 413
#define com_sun_cldc_io_connections_HttpConnection_HTTP_REQ_TOO_LONG 414
#define com_sun_cldc_io_connections_HttpConnection_HTTP_UNSUPPORTED_TYPE 415
#define com_sun_cldc_io_connections_HttpConnection_HTTP_UNSUPPORTED_RANGE 416
#define com_sun_cldc_io_connections_HttpConnection_HTTP_EXPECT_FAILED 417
#define com_sun_cldc_io_connections_HttpConnection_HTTP_INTERNAL_ERROR 500
#define com_sun_cldc_io_connections_HttpConnection_HTTP_NOT_IMPLEMENTED 501
#define com_sun_cldc_io_connections_HttpConnection_HTTP_BAD_GATEWAY 502
#define com_sun_cldc_io_connections_HttpConnection_HTTP_UNAVAILABLE 503
#define com_sun_cldc_io_connections_HttpConnection_HTTP_GATEWAY_TIMEOUT 504
#define com_sun_cldc_io_connections_HttpConnection_HTTP_VERSION 505
#define com_sun_cldc_io_DateParser 124
#define com_sun_cldc_io_DateParser_year(oop) getInt(oop, 0)
#define com_sun_cldc_io_DateParser_month(oop) getInt(oop, 1)
#define com_sun_cldc_io_DateParser_day(oop) getInt(oop, 2)
#define com_sun_cldc_io_DateParser_hour(oop) getInt(oop, 3)
#define com_sun_cldc_io_DateParser_minute(oop) getInt(oop, 4)
#define com_sun_cldc_io_DateParser_second(oop) getInt(oop, 5)
#define com_sun_cldc_io_DateParser_milli(oop) getInt(oop, 6)
#define com_sun_cldc_io_DateParser_tzoffset(oop) getInt(oop, 7)
#define com_sun_cldc_io_DateParser_days_in_month(oop) getObject(oop, 8)
#define com_sun_cldc_io_DateParser_month_shorts(oop) getObject(oop, 9)
#define com_sun_cldc_io_DateParser_weekday_shorts(oop) getObject(oop, 10)
#define com_sun_cldc_io_DateParser_JAN_1_1_JULIAN_DAY 1721426
#define com_sun_cldc_util_j2me_CalendarImpl 125
#define com_sun_cldc_util_j2me_TimeZoneImpl 126
#define com_sun_cldc_util_j2me_TimeZoneImpl_ID(oop) getObject(oop, 0)
#define com_sun_cldc_util_j2me_TimeZoneImpl_startMonth(oop) getInt(oop, 1)
#define com_sun_cldc_util_j2me_TimeZoneImpl_startDay(oop) getInt(oop, 2)
#define com_sun_cldc_util_j2me_TimeZoneImpl_startDayOfWeek(oop) getInt(oop, 3)
#define com_sun_cldc_util_j2me_TimeZoneImpl_startTime(oop) getInt(oop, 4)
#define com_sun_cldc_util_j2me_TimeZoneImpl_endMonth(oop) getInt(oop, 5)
#define com_sun_cldc_util_j2me_TimeZoneImpl_endDay(oop) getInt(oop, 6)
#define com_sun_cldc_util_j2me_TimeZoneImpl_endDayOfWeek(oop) getInt(oop, 7)
#define com_sun_cldc_util_j2me_TimeZoneImpl_endTime(oop) getInt(oop, 8)
#define com_sun_cldc_util_j2me_TimeZoneImpl_startYear(oop) getInt(oop, 9)
#define com_sun_cldc_util_j2me_TimeZoneImpl_rawOffset(oop) getInt(oop, 10)
#define com_sun_cldc_util_j2me_TimeZoneImpl_monthLength(oop) getObject(oop, 11)
#define com_sun_cldc_util_j2me_TimeZoneImpl_startMode(oop) getInt(oop, 12)
#define com_sun_cldc_util_j2me_TimeZoneImpl_endMode(oop) getInt(oop, 13)
#define com_sun_cldc_util_j2me_TimeZoneImpl_dstSavings(oop) getInt(oop, 14)
#define com_sun_cldc_util_j2me_TimeZoneImpl_useDaylight(oop) getByte(oop, 60)
#define com_sun_cldc_util_j2me_TimeZoneImpl_ONE_MINUTE 60000
#define com_sun_cldc_util_j2me_TimeZoneImpl_ONE_HOUR 3600000
#define com_sun_cldc_util_j2me_TimeZoneImpl_ONE_DAY 86400000
#define com_sun_cldc_util_j2me_TimeZoneImpl_millisPerHour 3600000
#define com_sun_cldc_util_j2me_TimeZoneImpl_millisPerDay 86400000
#define com_sun_cldc_util_j2me_TimeZoneImpl_DOM_MODE 1
#define com_sun_cldc_util_j2me_TimeZoneImpl_DOW_IN_MONTH_MODE 2
#define com_sun_cldc_util_j2me_TimeZoneImpl_DOW_GE_DOM_MODE 3
#define com_sun_cldc_util_j2me_TimeZoneImpl_DOW_LE_DOM_MODE 4
#define com_sun_cldc_util_TimeZoneImplementation 127
#define java_lang_InterruptedException 128
#define java_lang_Exception 129
#define java_lang_ClassNotFoundException 130
#define java_lang_InstantiationException 131
#define java_lang_IllegalAccessException 132
#define java_lang_RuntimeException 133
#define java_lang_IndexOutOfBoundsException 134
#define java_lang_LinkageError 135
#define java_lang_Error 136
#define java_lang_ArithmeticException 137
#define java_lang_ArrayIndexOutOfBoundsException 138
#define java_lang_ArrayStoreException 139
#define java_lang_Boolean 140
#define java_lang_Boolean_value(oop) getByte(oop, 0)
#define java_lang_Byte 141
#define java_lang_Byte_value(oop) getByte(oop, 0)
#define java_lang_Byte_MIN_VALUE -128
#define java_lang_Byte_MAX_VALUE 127
#define java_lang_NumberFormatException 142
#define java_lang_IllegalArgumentException 143
#define java_lang_ByteBufferDecoder 144
#define java_lang_ByteBufferDecoder_buf(oop) getObject(oop, 0)
#define java_lang_ByteBufferDecoder_pos(oop) getInt(oop, 1)
#define java_lang_GeneralDecoder 145
#define java_lang_ByteBufferEncoder 146
#define java_lang_ByteBufferEncoder_count(oop) getInt(oop, 0)
#define java_lang_ByteBufferEncoder_buffer(oop) getObject(oop, 1)
#define java_lang_Character 147
#define java_lang_Character_value(oop) getUShort(oop, 0)
#define java_lang_Character_MIN_RADIX 2
#define java_lang_Character_MAX_RADIX 36
#define java_lang_CheneyCollector 148
#define java_lang_CheneyCollector_copyObjectGraphCB(oop) getObject(oop, 1)
#define java_lang_CheneyCollector_fromSpaceStartPointer(oop) getObject(oop, 2)
#define java_lang_CheneyCollector_fromSpaceEndPointer(oop) getObject(oop, 3)
#define java_lang_CheneyCollector_toSpaceStartPointer(oop) getObject(oop, 4)
#define java_lang_CheneyCollector_toSpaceEndPointer(oop) getObject(oop, 5)
#define java_lang_CheneyCollector_toSpaceAllocationPointer(oop) getObject(oop, 6)
#define java_lang_CheneyCollector_HashTableKlass(oop) getObject(oop, 7)
#define java_lang_CheneyCollector_ThreadKlass(oop) getObject(oop, 8)
#define java_lang_CheneyCollector_IsolateKlass(oop) getObject(oop, 9)
#define java_lang_CheneyCollector_ObjectMemoryKlass(oop) getObject(oop, 10)
#define java_lang_CheneyCollector_theIsolate(oop) getObject(oop, 11)
#define java_lang_CheneyCollector_decoder(oop) getObject(oop, 12)
#define java_lang_CheneyCollector_collecting(oop) getByte(oop, 52)
#define java_lang_CheneyCollector_expectingCopyObjectGraphSecondPass(oop) getByte(oop, 53)
#define java_lang_GarbageCollector 149
#define java_lang_GarbageCollector_finalizers(oop) getObject(oop, 0)
#define java_lang_ObjectMemorySerializer_ControlBlock 150
#define java_lang_ObjectMemorySerializer_ControlBlock_memory(oop) getObject(oop, 0)
#define java_lang_ObjectMemorySerializer_ControlBlock_size(oop) getInt(oop, 1)
#define java_lang_ObjectMemorySerializer_ControlBlock_oopMap(oop) getObject(oop, 2)
#define java_lang_ObjectMemorySerializer_ControlBlock_root(oop) getInt(oop, 3)
#define java_lang_ObjectMemorySerializer 151
#define java_lang_Klass_State 152
#define java_lang_Klass_State_DEFINED 0
#define java_lang_Klass_State_LOADING 1
#define java_lang_Klass_State_LOADED 2
#define java_lang_Klass_State_CONVERTING 3
#define java_lang_Klass_State_CONVERTED 4
#define java_lang_Klass_State_ERROR 5
#define java_lang_Klass_1 153
#define java_lang_Isolate 154
#define java_lang_Isolate_mainClassName(oop) getObject(oop, 0)
#define java_lang_Isolate_args(oop) getObject(oop, 1)
#define java_lang_Isolate_openSuite(oop) getObject(oop, 2)
#define java_lang_Isolate_bootstrapSuite(oop) getObject(oop, 3)
#define java_lang_Isolate_childThreads(oop) getObject(oop, 4)
#define java_lang_Isolate_parentIsolate(oop) getObject(oop, 5)
#define java_lang_Isolate_childIsolates(oop) getObject(oop, 6)
#define java_lang_Isolate_state(oop) getInt(oop, 7)
#define java_lang_Isolate_exitCode(oop) getInt(oop, 8)
#define java_lang_Isolate_parentSuiteSourceURL(oop) getObject(oop, 9)
#define java_lang_Isolate_classPath(oop) getObject(oop, 10)
#define java_lang_Isolate_channelContext(oop) getInt(oop, 11)
#define java_lang_Isolate_hibernatedContext(oop) getInt(oop, 12)
#define java_lang_Isolate_guiIn(oop) getInt(oop, 13)
#define java_lang_Isolate_guiOut(oop) getInt(oop, 14)
#define java_lang_Isolate_monitorHashtable(oop) getObject(oop, 15)
#define java_lang_Isolate_translator(oop) getObject(oop, 16)
#define java_lang_Isolate_classStateQueue(oop) getObject(oop, 17)
#define java_lang_Isolate_internedStrings(oop) getObject(oop, 18)
#define java_lang_Isolate_finalizers(oop) getObject(oop, 19)
#define java_lang_Isolate_hibernatedRunThreads(oop) getObject(oop, 20)
#define java_lang_Isolate_hibernatedTimerThreads(oop) getObject(oop, 21)
#define java_lang_Isolate_hibernatedStackChunks(oop) getObject(oop, 22)
#define java_lang_Isolate_joiners(oop) getObject(oop, 23)
#define java_lang_Isolate_properties(oop) getObject(oop, 24)
#define java_lang_Isolate_openSuiteHack(oop) getObject(oop, 25)
#define java_lang_Isolate_classKlassInitialized(oop) getByte(oop, 104)
#define java_lang_Isolate_isTckTest(oop) getByte(oop, 105)
#define java_lang_Isolate_NEW 0
#define java_lang_Isolate_ALIVE 1
#define java_lang_Isolate_HIBERNATED 2
#define java_lang_Isolate_EXITED 3
#define java_lang_Runnable 155
#define java_lang_VMBufferDecoder 156
#define java_lang_VMBufferDecoder_oop(oop) getObject(oop, 0)
#define java_lang_VMBufferDecoder_offset(oop) getInt(oop, 1)
#define java_lang_Suite 157
#define java_lang_Suite_sno(oop) getInt(oop, 0)
#define java_lang_Suite_classes(oop) getObject(oop, 1)
#define java_lang_Suite_name(oop) getObject(oop, 2)
#define java_lang_Suite_classPath(oop) getObject(oop, 3)
#define java_lang_Suite_metadatas(oop) getObject(oop, 4)
#define java_lang_Suite_parent(oop) getObject(oop, 5)
#define java_lang_Suite_childCount(oop) getInt(oop, 6)
#define java_lang_Suite_configuration(oop) getObject(oop, 7)
#define java_lang_Suite_closed(oop) getByte(oop, 32)
#define java_lang_Suite_APPLICATION 0
#define java_lang_Suite_LIBRARY 1
#define java_lang_Suite_EXTENDABLE_LIBRARY 2
#define java_lang_Suite_DEBUG 3
#define java_lang_Finalizer 158
#define java_lang_Finalizer_object(oop) getObject(oop, 0)
#define java_lang_Finalizer_isolate(oop) getObject(oop, 1)
#define java_lang_Finalizer_next(oop) getObject(oop, 2)
#define java_lang_ObjectMemory 159
#define java_lang_ObjectMemory_hash(oop) getInt(oop, 0)
#define java_lang_ObjectMemory_url(oop) getObject(oop, 1)
#define java_lang_ObjectMemory_start(oop) getObject(oop, 2)
#define java_lang_ObjectMemory_size(oop) getInt(oop, 3)
#define java_lang_ObjectMemory_root(oop) getObject(oop, 4)
#define java_lang_ObjectMemory_parent(oop) getObject(oop, 5)
#define java_lang_ObjectMemoryOutputStream 160
#define java_lang_ClassFileMember 161
#define java_lang_ClassFileMember_name(oop) getObject(oop, 0)
#define java_lang_ClassFileMember_modifiers(oop) getInt(oop, 1)
#define java_lang_ClassFileMember_offset(oop) getInt(oop, 2)
#define java_lang_KlassMetadata_Debug 162
#define java_lang_TranslatorInterface 163
#define java_lang_SymbolParser 164
#define java_lang_SymbolParser_sectionStart(oop) getObject(oop, 2)
#define java_lang_SymbolParser_sectionCount(oop) getObject(oop, 3)
#define java_lang_SymbolParser_modifiers(oop) getInt(oop, 4)
#define java_lang_SymbolParser_offset(oop) getInt(oop, 5)
#define java_lang_SymbolParser_nameLength(oop) getInt(oop, 6)
#define java_lang_SymbolParser_selection(oop) getShort(oop, 14)
#define java_lang_SymbolParser_nameStart(oop) getShort(oop, 15)
#define java_lang_SymbolParser_signatureStart(oop) getShort(oop, 16)
#define java_lang_SymbolParser_signatureCount(oop) getShort(oop, 17)
#define java_lang_SymbolParser_sectionsParsed(oop) getByte(oop, 36)
#define java_lang_SymbolParser_INSTANCE_FIELDS 0
#define java_lang_SymbolParser_STATIC_FIELDS 1
#define java_lang_SymbolParser_VIRTUAL_METHODS 2
#define java_lang_SymbolParser_STATIC_METHODS 3
#define java_lang_ExceptionHandler 165
#define java_lang_ExceptionHandler_start(oop) getInt(oop, 0)
#define java_lang_ExceptionHandler_end(oop) getInt(oop, 1)
#define java_lang_ExceptionHandler_handler(oop) getInt(oop, 2)
#define java_lang_ExceptionHandler_klass(oop) getObject(oop, 3)
#define java_lang_MethodMetadata 166
#define java_lang_MethodMetadata_id(oop) getInt(oop, 0)
#define java_lang_MethodMetadata_lnt(oop) getObject(oop, 1)
#define java_lang_ThreadQueue 167
#define java_lang_ThreadQueue_first(oop) getObject(oop, 0)
#define java_lang_ThreadQueue_count(oop) getInt(oop, 1)
#define java_lang_TimerQueue 168
#define java_lang_TimerQueue_first(oop) getObject(oop, 0)
#define java_lang_EventHashtable 169
#define java_lang_EventHashtable_isolate(oop) getObject(oop, 3)
#define java_lang_Monitor 170
#define java_lang_Monitor_owner(oop) getObject(oop, 0)
#define java_lang_Monitor_monitorQueue(oop) getObject(oop, 1)
#define java_lang_Monitor_condvarQueue(oop) getObject(oop, 2)
#define java_lang_Monitor_depth(oop) getShort(oop, 6)
#define java_lang_Monitor_hasHadWaiter(oop) getByte(oop, 14)
#define java_lang_ClassCastException 171
#define java_lang_ClassFileConstantField 172
#define java_lang_ClassFileConstantField_constantValue(oop) getLongAtWord(oop, 4)
#define java_lang_ExceptionInInitializerError 173
#define java_lang_ExceptionInInitializerError_exception(oop) getObject(oop, 3)
#define java_lang_FinalizerTest 174
#define java_lang_FinalizerTestParent 175
#define java_lang_FlashObjectMemoryLoader 176
#define java_lang_FlashObjectMemoryLoader_objectMemorySize(oop) getInt(oop, 2)
#define java_lang_FlashObjectMemoryLoader_memoryAddress(oop) getObject(oop, 3)
#define java_lang_ObjectMemoryLoader_GCDuringRelocationError 177
#define java_lang_ObjectMemoryLoader_OutputStreamSink 178
#define java_lang_ObjectMemoryLoader_OutputStreamSink_length(oop) getInt(oop, 0)
#define java_lang_ObjectMemoryLoader 179
#define java_lang_ObjectMemoryLoader_reader(oop) getObject(oop, 0)
#define java_lang_ObjectMemoryLoader_loadIntoReadOnlyMemory(oop) getByte(oop, 4)
#define java_lang_ObjectMemoryLoader_ATTRIBUTE_TYPEMAP 1
#define java_lang_ObjectMemoryLoader_ATTRIBUTE_32BIT 2
#define java_lang_ObjectMemoryReader 180
#define java_lang_FlashObjectMemoryReader 181
#define java_lang_FlashObjectMemoryReader_mis(oop) getObject(oop, 3)
#define java_lang_GC 182
#define java_lang_GC_PRUNE_ORPHAN 1
#define java_lang_GC_PRUNE_OWNED_BY_ISOLATE 2
#define java_lang_GC_TRACE_BASIC 1
#define java_lang_GC_TRACE_ALLOCATION 2
#define java_lang_GC_TRACE_COLLECTION 4
#define java_lang_GC_TRACE_OBJECT_GRAPH_COPYING 8
#define java_lang_GC_TRACE_HEAP 16
#define java_lang_ObjectAssociation 183
#define java_lang_ObjectAssociation_klass(oop) getObject(oop, 0)
#define java_lang_ObjectAssociation_virtualMethods(oop) getObject(oop, 1)
#define java_lang_ObjectAssociation_monitor(oop) getObject(oop, 2)
#define java_lang_ObjectAssociation_hashCode(oop) getInt(oop, 3)
#define java_lang_IllegalMonitorStateException 184
#define java_lang_IllegalStateException 185
#define java_lang_IllegalStoreException 186
#define java_lang_IllegalThreadStateException 187
#define java_lang_Integer 188
#define java_lang_Integer_value(oop) getInt(oop, 0)
#define java_lang_Integer_MIN_VALUE -2147483648
#define java_lang_Integer_MAX_VALUE 2147483647
#define java_lang_InternalError 189
#define java_lang_VirtualMachineError 190
#define java_lang_JavaApplicationManager 191
#define java_lang_Long 192
#define java_lang_Long_value(oop) getLongAtWord(oop, 0)
#define java_lang_Long_MIN_VALUE -9223372036854775808
#define java_lang_Long_MAX_VALUE 9223372036854775807
#define java_lang_Math 193
#define java_lang_Modifier 194
#define java_lang_Modifier_PUBLIC 1
#define java_lang_Modifier_PRIVATE 2
#define java_lang_Modifier_PROTECTED 4
#define java_lang_Modifier_STATIC 8
#define java_lang_Modifier_FINAL 16
#define java_lang_Modifier_SYNCHRONIZED 32
#define java_lang_Modifier_VOLATILE 64
#define java_lang_Modifier_TRANSIENT 128
#define java_lang_Modifier_NATIVE 256
#define java_lang_Modifier_INTERFACE 512
#define java_lang_Modifier_ABSTRACT 1024
#define java_lang_Modifier_STRICT 2048
#define java_lang_Modifier_CONSTRUCTOR 4096
#define java_lang_Modifier_CLASSINITIALIZER 8192
#define java_lang_Modifier_CONSTANT 16384
#define java_lang_Modifier_SUPER 32
#define java_lang_Modifier_MUSTCLINIT 65536
#define java_lang_Modifier_HASFINALIZER 131072
#define java_lang_Modifier_PRIMITIVE 262144
#define java_lang_Modifier_SYNTHETIC 524288
#define java_lang_Modifier_DOUBLEWORD 1048576
#define java_lang_Modifier_ARRAY 2097152
#define java_lang_Modifier_SQUAWKARRAY 4194304
#define java_lang_Modifier_SQUAWKPRIMITIVE 8388608
#define java_lang_Modifier_SQUAWKNATIVE 16777216
#define java_lang_NegativeArraySizeException 195
#define java_lang_NoClassDefFoundError 196
#define java_lang_NullPointerException 197
#define java_lang_OutOfMemoryError 198
#define java_lang_Runtime 199
#define java_lang_SecurityException 200
#define java_lang_ServiceOperation 201
#define java_lang_ServiceOperation_NONE 0
#define java_lang_ServiceOperation_EXTEND 1
#define java_lang_ServiceOperation_GARBAGE_COLLECT 2
#define java_lang_ServiceOperation_COPY_OBJECT_GRAPH 3
#define java_lang_ServiceOperation_THROW 4
#define java_lang_ServiceOperation_CHANNELIO 5
#define java_lang_Short 202
#define java_lang_Short_value(oop) getShort(oop, 0)
#define java_lang_StringIndexOutOfBoundsException 203
#define java_lang_SuiteCreator 204
#define java_lang_SuiteCreator_suiteName(oop) getObject(oop, 0)
#define java_lang_SuiteCreator_suiteType(oop) getInt(oop, 1)
#define java_lang_SuiteCreator_retainLNTs(oop) getByte(oop, 8)
#define java_lang_SuiteCreator_retainLVTs(oop) getByte(oop, 9)
#define java_lang_SuiteManager_1 205
#define java_lang_SuiteManager_1_lastSno(oop) getInt(oop, 0)
#define java_lang_SuiteManager_1_sno(oop) getInt(oop, 1)
#define java_lang_SuiteManager 206
#define java_lang_System 207
#define java_lang_Test_FOO 208
#define java_lang_Test_FOO_xxx(oop) getObject(oop, 0)
#define java_lang_Test_1 209
#define java_lang_Test_2 210
#define java_lang_Test 211
#define java_lang_VM 212
#define java_lang_VM_STREAM_STDOUT 0
#define java_lang_VM_STREAM_STDERR 1
#define java_lang_VM_STREAM_SYMBOLS 2
#define java_io_OutputStream 213
#define java_io_UnsupportedEncodingException 214
#define java_io_IOException 215
#define java_io_OutputStreamWriter 216
#define java_io_OutputStreamWriter_out(oop) getObject(oop, 2)
#define java_io_Writer 217
#define java_io_Writer_writeBuffer(oop) getObject(oop, 0)
#define java_io_Writer_lock(oop) getObject(oop, 1)
#define java_io_Writer_writeBufferSize -1
#define java_io_Reader 218
#define java_io_Reader_lock(oop) getObject(oop, 0)
#define java_io_Reader_skipBuffer(oop) getObject(oop, 1)
#define java_io_Reader_maxSkipBufferSize 8192
#define java_io_DataInputStream 219
#define java_io_DataInputStream_in(oop) getObject(oop, 0)
#define java_io_DataInput 220
#define java_io_DataOutputStream 221
#define java_io_DataOutputStream_out(oop) getObject(oop, 0)
#define java_io_DataOutput 222
#define java_io_ByteArrayOutputStream 223
#define java_io_ByteArrayOutputStream_buf(oop) getObject(oop, 0)
#define java_io_ByteArrayOutputStream_count(oop) getInt(oop, 1)
#define java_io_ByteArrayOutputStream_isClosed(oop) getByte(oop, 8)
#define java_io_Serializable 224
#define java_io_ByteArrayInputStream 225
#define java_io_ByteArrayInputStream_buf(oop) getObject(oop, 0)
#define java_io_ByteArrayInputStream_pos(oop) getInt(oop, 1)
#define java_io_ByteArrayInputStream_mark(oop) getInt(oop, 2)
#define java_io_ByteArrayInputStream_count(oop) getInt(oop, 3)
#define java_io_EOFException 226
#define java_io_InputStreamReader 227
#define java_io_InputStreamReader_in(oop) getObject(oop, 2)
#define java_io_InterruptedIOException 228
#define java_io_InterruptedIOException_bytesTransferred(oop) getInt(oop, 3)
#define java_io_NativePrintStream 229
#define java_io_UTFDataFormatException 230
#define java_util_Enumeration 231
#define java_util_Hashtable 232
#define java_util_Calendar 233
#define java_util_Calendar_time(oop) getLongAtWord(oop, 0)
#define java_util_Calendar_packed_time(oop) getInt(oop, 2)
#define java_util_Calendar_packed_date(oop) getInt(oop, 3)
#define java_util_Calendar_day_field(oop) getInt(oop, 4)
#define java_util_Calendar_dstOffset(oop) getInt(oop, 5)
#define java_util_Calendar_zone(oop) getObject(oop, 6)
#define java_util_Calendar_date(oop) getObject(oop, 7)
#define java_util_Calendar_hour_12hr(oop) getInt(oop, 8)
#define java_util_Calendar_am_pm_12hr(oop) getInt(oop, 9)
#define java_util_Calendar_dstSet(oop) getByte(oop, 40)
#define java_util_Calendar_millisSet(oop) getByte(oop, 41)
#define java_util_Calendar_YEAR 1
#define java_util_Calendar_MONTH 2
#define java_util_Calendar_DATE 5
#define java_util_Calendar_DAY_OF_MONTH 5
#define java_util_Calendar_DAY_OF_WEEK 7
#define java_util_Calendar_AM_PM 9
#define java_util_Calendar_HOUR 10
#define java_util_Calendar_HOUR_OF_DAY 11
#define java_util_Calendar_MINUTE 12
#define java_util_Calendar_SECOND 13
#define java_util_Calendar_MILLISECOND 14
#define java_util_Calendar_SUNDAY 1
#define java_util_Calendar_MONDAY 2
#define java_util_Calendar_TUESDAY 3
#define java_util_Calendar_WEDNESDAY 4
#define java_util_Calendar_THURSDAY 5
#define java_util_Calendar_FRIDAY 6
#define java_util_Calendar_SATURDAY 7
#define java_util_Calendar_JANUARY 0
#define java_util_Calendar_FEBRUARY 1
#define java_util_Calendar_MARCH 2
#define java_util_Calendar_APRIL 3
#define java_util_Calendar_MAY 4
#define java_util_Calendar_JUNE 5
#define java_util_Calendar_JULY 6
#define java_util_Calendar_AUGUST 7
#define java_util_Calendar_SEPTEMBER 8
#define java_util_Calendar_OCTOBER 9
#define java_util_Calendar_NOVEMBER 10
#define java_util_Calendar_DECEMBER 11
#define java_util_Calendar_AM 0
#define java_util_Calendar_PM 1
#define java_util_Calendar_JAN_1_1_JULIAN_DAY -1
#define java_util_Calendar_EPOCH_JULIAN_DAY -1
#define java_util_Calendar_EPOCH_YEAR -1
#define java_util_Calendar_ONE_SECOND -1
#define java_util_Calendar_ONE_MINUTE -1
#define java_util_Calendar_ONE_HOUR -1
#define java_util_Calendar_ONE_DAY -1
#define java_util_Calendar_ONE_WEEK -1
#define java_util_Calendar_gregorianCutover -1
#define java_util_Calendar_gregorianCutoverYear -1
#define java_util_TimeZone 234
#define java_util_Date 235
#define java_util_Date_fastTime(oop) getLongAtWord(oop, 0)
#define java_util_Date_calendar(oop) getObject(oop, 2)
#define java_util_Vector 236
#define java_util_EmptyStackException 237
#define java_util_NoSuchElementException 238
#define java_util_Random 239
#define java_util_Random_seed(oop) getLongAtWord(oop, 0)
#define java_util_Random_multiplier 25214903917
#define java_util_Random_addend 11
#define java_util_Random_mask 281474976710655
#define java_util_Random_BITS_PER_BYTE 8
#define java_util_Random_BYTES_PER_INT 4
#define java_util_Stack 240
#define java_util_StringTokenizer 241
#define java_util_StringTokenizer_currentPosition(oop) getInt(oop, 0)
#define java_util_StringTokenizer_maxPosition(oop) getInt(oop, 1)
#define java_util_StringTokenizer_str(oop) getObject(oop, 2)
#define java_util_StringTokenizer_delimiters(oop) getObject(oop, 3)
#define java_util_StringTokenizer_retTokens(oop) getByte(oop, 16)
#define java_util_Timer 242
#define java_util_TimerTask 243
#define java_util_TimerTask_nextExecutionTime(oop) getLongAtWord(oop, 0)
#define java_util_TimerTask_period(oop) getLongAtWord(oop, 2)
#define java_util_TimerTask_lock(oop) getObject(oop, 4)
#define java_util_TimerTask_state(oop) getInt(oop, 5)
#define java_util_TimerTask_VIRGIN 0
#define java_util_TimerTask_SCHEDULED 1
#define java_util_TimerTask_EXECUTED 2
#define java_util_TimerTask_CANCELLED 3
#define javax_microedition_io_ContentConnection 244
#define javax_microedition_io_StreamConnection 245
#define javax_microedition_io_InputConnection 246
#define javax_microedition_io_Connection 247
#define javax_microedition_io_OutputConnection 248
#define javax_microedition_io_StreamConnectionNotifier 249
#define javax_microedition_io_ConnectionNotFoundException 250
#define javax_microedition_io_Connector 251
#define javax_microedition_io_Connector_READ 1
#define javax_microedition_io_Connector_WRITE 2
#define javax_microedition_io_Connector_READ_WRITE 3
#define javax_microedition_io_Datagram 252
#define javax_microedition_io_DatagramConnection 253
#define com_sun_squawk_test_VerifyUseOfInterface 254
#define com_sun_squawk_test_VerifyUseOfInterface_vIface(oop) getObject(oop, 0)
#define com_sun_squawk_test_Base 255
#define com_sun_squawk_test_Interface 256
#define com_sun_squawk_test_SubClass 257
#define com_sun_squawk_test_AnotherSubClass 258
#define com_sun_squawk_translator_ci_ClassFileLoader_1 259
#define com_sun_squawk_translator_ci_ClassFileLoader_1_this_0(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ci_ClassFileLoader 260
#define com_sun_squawk_translator_ci_ClassFileLoader_classPath(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ci_ClassFileLoader_cf(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ci_ClassFileLoader_klass(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ci_ClassFileLoader_cfr(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ci_ClassFileLoader_pool(oop) getObject(oop, 4)
#define com_sun_squawk_translator_ci_Context 261
#define com_sun_squawk_translator_ci_ClassFileReader 262
#define com_sun_squawk_translator_ci_ConstantPool_ValidNameFormat 263
#define com_sun_squawk_translator_ci_ConstantPool_ValidNameFormat_asString(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ci_ConstantPool_ValidNameFormat_value(oop) getInt(oop, 1)
#define com_sun_squawk_translator_ci_ConstantPool_NameAndType 264
#define com_sun_squawk_translator_ci_ConstantPool_NameAndType_name(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ci_ConstantPool_NameAndType_sig(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ci_ConstantPool_FieldOrMethod 265
#define com_sun_squawk_translator_ci_ConstantPool_FieldOrMethod_classIndex(oop) getInt(oop, 0)
#define com_sun_squawk_translator_ci_ConstantPool_FieldOrMethod_nameAndTypeIndex(oop) getInt(oop, 1)
#define com_sun_squawk_translator_ci_ConstantPool 266
#define com_sun_squawk_translator_ci_ConstantPool_cfr(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ci_ConstantPool_definedClass(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ci_ConstantPool_tags(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ci_ConstantPool_entries(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ci_ConstantPool_methodSigCache(oop) getObject(oop, 4)
#define com_sun_squawk_translator_ci_ConstantPool_CONSTANT_Utf8 1
#define com_sun_squawk_translator_ci_ConstantPool_CONSTANT_Unicode 2
#define com_sun_squawk_translator_ci_ConstantPool_CONSTANT_Integer 3
#define com_sun_squawk_translator_ci_ConstantPool_CONSTANT_Float 4
#define com_sun_squawk_translator_ci_ConstantPool_CONSTANT_Long 5
#define com_sun_squawk_translator_ci_ConstantPool_CONSTANT_Double 6
#define com_sun_squawk_translator_ci_ConstantPool_CONSTANT_Class 7
#define com_sun_squawk_translator_ci_ConstantPool_CONSTANT_String 8
#define com_sun_squawk_translator_ci_ConstantPool_CONSTANT_Fieldref 9
#define com_sun_squawk_translator_ci_ConstantPool_CONSTANT_Methodref 10
#define com_sun_squawk_translator_ci_ConstantPool_CONSTANT_InterfaceMethodref 11
#define com_sun_squawk_translator_ci_ConstantPool_CONSTANT_NameAndType 12
#define com_sun_squawk_translator_ci_ConstantPool_CONSTANT_Object 14
#define com_sun_squawk_translator_ci_MethodSignature 267
#define com_sun_squawk_translator_ci_MethodSignature_returnType(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ci_MethodSignature_parameterTypes(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ci_CodeParser_1 268
#define com_sun_squawk_translator_ci_CodeParser_1_this_0(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ci_CodeParser_2 269
#define com_sun_squawk_translator_ci_CodeParser_PseudoOpcode 270
#define com_sun_squawk_translator_ci_CodeParser_PseudoOpcode_tag(oop) getInt(oop, 0)
#define com_sun_squawk_translator_ci_CodeParser_PseudoOpcode_index(oop) getInt(oop, 1)
#define com_sun_squawk_translator_ci_CodeParser_PseudoOpcode_context(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ci_CodeParser_PseudoOpcode_TRYEND 0
#define com_sun_squawk_translator_ci_CodeParser_PseudoOpcode_TRY 1
#define com_sun_squawk_translator_ci_CodeParser_PseudoOpcode_CATCH 2
#define com_sun_squawk_translator_ci_CodeParser_PseudoOpcode_TARGET 3
#define com_sun_squawk_translator_ci_CodeParser_PseudoOpcode_POSITION 4
#define com_sun_squawk_translator_ci_CodeParser 271
#define com_sun_squawk_translator_ci_CodeParser_method(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ci_CodeParser_constantPool(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ci_CodeParser_maxStack(oop) getInt(oop, 2)
#define com_sun_squawk_translator_ci_CodeParser_maxLocals(oop) getInt(oop, 3)
#define com_sun_squawk_translator_ci_CodeParser_exceptionHandlers(oop) getObject(oop, 4)
#define com_sun_squawk_translator_ci_CodeParser_cfr(oop) getObject(oop, 5)
#define com_sun_squawk_translator_ci_CodeParser_bcin(oop) getObject(oop, 6)
#define com_sun_squawk_translator_ci_CodeParser_pseudoOpcodes(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ci_CodeParser_UninitializedObjectClasses(oop) getObject(oop, 8)
#define com_sun_squawk_translator_ci_CodeParser_positions(oop) getObject(oop, 9)
#define com_sun_squawk_translator_ci_CodeParser_lineNumberTable(oop) getObject(oop, 10)
#define com_sun_squawk_translator_ci_CodeParser_targets(oop) getObject(oop, 11)
#define com_sun_squawk_translator_ci_CodeParser_lastOpcodeAddress(oop) getInt(oop, 12)
#define com_sun_squawk_translator_ci_CodeParser_T_BOOLEAN 4
#define com_sun_squawk_translator_ci_CodeParser_T_CHAR 5
#define com_sun_squawk_translator_ci_CodeParser_T_FLOAT 6
#define com_sun_squawk_translator_ci_CodeParser_T_DOUBLE 7
#define com_sun_squawk_translator_ci_CodeParser_T_BYTE 8
#define com_sun_squawk_translator_ci_CodeParser_T_SHORT 9
#define com_sun_squawk_translator_ci_CodeParser_T_INT 10
#define com_sun_squawk_translator_ci_CodeParser_T_LONG 11
#define com_sun_squawk_translator_ci_IndexedInputStream 272
#define com_sun_squawk_translator_ci_UninitializedObjectClass 273
#define com_sun_squawk_translator_ci_UninitializedObjectClass_initializedType(oop) getObject(oop, 18)
#define com_sun_squawk_translator_ci_LocalVariableTableEntry 274
#define com_sun_squawk_translator_ci_LocalVariableTableEntry_start(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ci_LocalVariableTableEntry_end(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ci_LocalVariableTableEntry_name(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ci_LocalVariableTableEntry_type(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ci_LocalVariableTableEntry_index(oop) getInt(oop, 4)
#define com_sun_squawk_translator_ci_LocalVariableTableEntry_local(oop) getObject(oop, 5)
#define com_sun_squawk_translator_ci_Opcode 275
#define com_sun_squawk_translator_ci_Opcode_opc_nop 0
#define com_sun_squawk_translator_ci_Opcode_opc_aconst_null 1
#define com_sun_squawk_translator_ci_Opcode_opc_iconst_m1 2
#define com_sun_squawk_translator_ci_Opcode_opc_iconst_0 3
#define com_sun_squawk_translator_ci_Opcode_opc_iconst_1 4
#define com_sun_squawk_translator_ci_Opcode_opc_iconst_2 5
#define com_sun_squawk_translator_ci_Opcode_opc_iconst_3 6
#define com_sun_squawk_translator_ci_Opcode_opc_iconst_4 7
#define com_sun_squawk_translator_ci_Opcode_opc_iconst_5 8
#define com_sun_squawk_translator_ci_Opcode_opc_lconst_0 9
#define com_sun_squawk_translator_ci_Opcode_opc_lconst_1 10
#define com_sun_squawk_translator_ci_Opcode_opc_fconst_0 11
#define com_sun_squawk_translator_ci_Opcode_opc_fconst_1 12
#define com_sun_squawk_translator_ci_Opcode_opc_fconst_2 13
#define com_sun_squawk_translator_ci_Opcode_opc_dconst_0 14
#define com_sun_squawk_translator_ci_Opcode_opc_dconst_1 15
#define com_sun_squawk_translator_ci_Opcode_opc_bipush 16
#define com_sun_squawk_translator_ci_Opcode_opc_sipush 17
#define com_sun_squawk_translator_ci_Opcode_opc_ldc 18
#define com_sun_squawk_translator_ci_Opcode_opc_ldc_w 19
#define com_sun_squawk_translator_ci_Opcode_opc_ldc2_w 20
#define com_sun_squawk_translator_ci_Opcode_opc_iload 21
#define com_sun_squawk_translator_ci_Opcode_opc_lload 22
#define com_sun_squawk_translator_ci_Opcode_opc_fload 23
#define com_sun_squawk_translator_ci_Opcode_opc_dload 24
#define com_sun_squawk_translator_ci_Opcode_opc_aload 25
#define com_sun_squawk_translator_ci_Opcode_opc_iload_0 26
#define com_sun_squawk_translator_ci_Opcode_opc_iload_1 27
#define com_sun_squawk_translator_ci_Opcode_opc_iload_2 28
#define com_sun_squawk_translator_ci_Opcode_opc_iload_3 29
#define com_sun_squawk_translator_ci_Opcode_opc_lload_0 30
#define com_sun_squawk_translator_ci_Opcode_opc_lload_1 31
#define com_sun_squawk_translator_ci_Opcode_opc_lload_2 32
#define com_sun_squawk_translator_ci_Opcode_opc_lload_3 33
#define com_sun_squawk_translator_ci_Opcode_opc_fload_0 34
#define com_sun_squawk_translator_ci_Opcode_opc_fload_1 35
#define com_sun_squawk_translator_ci_Opcode_opc_fload_2 36
#define com_sun_squawk_translator_ci_Opcode_opc_fload_3 37
#define com_sun_squawk_translator_ci_Opcode_opc_dload_0 38
#define com_sun_squawk_translator_ci_Opcode_opc_dload_1 39
#define com_sun_squawk_translator_ci_Opcode_opc_dload_2 40
#define com_sun_squawk_translator_ci_Opcode_opc_dload_3 41
#define com_sun_squawk_translator_ci_Opcode_opc_aload_0 42
#define com_sun_squawk_translator_ci_Opcode_opc_aload_1 43
#define com_sun_squawk_translator_ci_Opcode_opc_aload_2 44
#define com_sun_squawk_translator_ci_Opcode_opc_aload_3 45
#define com_sun_squawk_translator_ci_Opcode_opc_iaload 46
#define com_sun_squawk_translator_ci_Opcode_opc_laload 47
#define com_sun_squawk_translator_ci_Opcode_opc_faload 48
#define com_sun_squawk_translator_ci_Opcode_opc_daload 49
#define com_sun_squawk_translator_ci_Opcode_opc_aaload 50
#define com_sun_squawk_translator_ci_Opcode_opc_baload 51
#define com_sun_squawk_translator_ci_Opcode_opc_caload 52
#define com_sun_squawk_translator_ci_Opcode_opc_saload 53
#define com_sun_squawk_translator_ci_Opcode_opc_istore 54
#define com_sun_squawk_translator_ci_Opcode_opc_lstore 55
#define com_sun_squawk_translator_ci_Opcode_opc_fstore 56
#define com_sun_squawk_translator_ci_Opcode_opc_dstore 57
#define com_sun_squawk_translator_ci_Opcode_opc_astore 58
#define com_sun_squawk_translator_ci_Opcode_opc_istore_0 59
#define com_sun_squawk_translator_ci_Opcode_opc_istore_1 60
#define com_sun_squawk_translator_ci_Opcode_opc_istore_2 61
#define com_sun_squawk_translator_ci_Opcode_opc_istore_3 62
#define com_sun_squawk_translator_ci_Opcode_opc_lstore_0 63
#define com_sun_squawk_translator_ci_Opcode_opc_lstore_1 64
#define com_sun_squawk_translator_ci_Opcode_opc_lstore_2 65
#define com_sun_squawk_translator_ci_Opcode_opc_lstore_3 66
#define com_sun_squawk_translator_ci_Opcode_opc_fstore_0 67
#define com_sun_squawk_translator_ci_Opcode_opc_fstore_1 68
#define com_sun_squawk_translator_ci_Opcode_opc_fstore_2 69
#define com_sun_squawk_translator_ci_Opcode_opc_fstore_3 70
#define com_sun_squawk_translator_ci_Opcode_opc_dstore_0 71
#define com_sun_squawk_translator_ci_Opcode_opc_dstore_1 72
#define com_sun_squawk_translator_ci_Opcode_opc_dstore_2 73
#define com_sun_squawk_translator_ci_Opcode_opc_dstore_3 74
#define com_sun_squawk_translator_ci_Opcode_opc_astore_0 75
#define com_sun_squawk_translator_ci_Opcode_opc_astore_1 76
#define com_sun_squawk_translator_ci_Opcode_opc_astore_2 77
#define com_sun_squawk_translator_ci_Opcode_opc_astore_3 78
#define com_sun_squawk_translator_ci_Opcode_opc_iastore 79
#define com_sun_squawk_translator_ci_Opcode_opc_lastore 80
#define com_sun_squawk_translator_ci_Opcode_opc_fastore 81
#define com_sun_squawk_translator_ci_Opcode_opc_dastore 82
#define com_sun_squawk_translator_ci_Opcode_opc_aastore 83
#define com_sun_squawk_translator_ci_Opcode_opc_bastore 84
#define com_sun_squawk_translator_ci_Opcode_opc_castore 85
#define com_sun_squawk_translator_ci_Opcode_opc_sastore 86
#define com_sun_squawk_translator_ci_Opcode_opc_pop 87
#define com_sun_squawk_translator_ci_Opcode_opc_pop2 88
#define com_sun_squawk_translator_ci_Opcode_opc_dup 89
#define com_sun_squawk_translator_ci_Opcode_opc_dup_x1 90
#define com_sun_squawk_translator_ci_Opcode_opc_dup_x2 91
#define com_sun_squawk_translator_ci_Opcode_opc_dup2 92
#define com_sun_squawk_translator_ci_Opcode_opc_dup2_x1 93
#define com_sun_squawk_translator_ci_Opcode_opc_dup2_x2 94
#define com_sun_squawk_translator_ci_Opcode_opc_swap 95
#define com_sun_squawk_translator_ci_Opcode_opc_iadd 96
#define com_sun_squawk_translator_ci_Opcode_opc_ladd 97
#define com_sun_squawk_translator_ci_Opcode_opc_fadd 98
#define com_sun_squawk_translator_ci_Opcode_opc_dadd 99
#define com_sun_squawk_translator_ci_Opcode_opc_isub 100
#define com_sun_squawk_translator_ci_Opcode_opc_lsub 101
#define com_sun_squawk_translator_ci_Opcode_opc_fsub 102
#define com_sun_squawk_translator_ci_Opcode_opc_dsub 103
#define com_sun_squawk_translator_ci_Opcode_opc_imul 104
#define com_sun_squawk_translator_ci_Opcode_opc_lmul 105
#define com_sun_squawk_translator_ci_Opcode_opc_fmul 106
#define com_sun_squawk_translator_ci_Opcode_opc_dmul 107
#define com_sun_squawk_translator_ci_Opcode_opc_idiv 108
#define com_sun_squawk_translator_ci_Opcode_opc_ldiv 109
#define com_sun_squawk_translator_ci_Opcode_opc_fdiv 110
#define com_sun_squawk_translator_ci_Opcode_opc_ddiv 111
#define com_sun_squawk_translator_ci_Opcode_opc_irem 112
#define com_sun_squawk_translator_ci_Opcode_opc_lrem 113
#define com_sun_squawk_translator_ci_Opcode_opc_frem 114
#define com_sun_squawk_translator_ci_Opcode_opc_drem 115
#define com_sun_squawk_translator_ci_Opcode_opc_ineg 116
#define com_sun_squawk_translator_ci_Opcode_opc_lneg 117
#define com_sun_squawk_translator_ci_Opcode_opc_fneg 118
#define com_sun_squawk_translator_ci_Opcode_opc_dneg 119
#define com_sun_squawk_translator_ci_Opcode_opc_ishl 120
#define com_sun_squawk_translator_ci_Opcode_opc_lshl 121
#define com_sun_squawk_translator_ci_Opcode_opc_ishr 122
#define com_sun_squawk_translator_ci_Opcode_opc_lshr 123
#define com_sun_squawk_translator_ci_Opcode_opc_iushr 124
#define com_sun_squawk_translator_ci_Opcode_opc_lushr 125
#define com_sun_squawk_translator_ci_Opcode_opc_iand 126
#define com_sun_squawk_translator_ci_Opcode_opc_land 127
#define com_sun_squawk_translator_ci_Opcode_opc_ior 128
#define com_sun_squawk_translator_ci_Opcode_opc_lor 129
#define com_sun_squawk_translator_ci_Opcode_opc_ixor 130
#define com_sun_squawk_translator_ci_Opcode_opc_lxor 131
#define com_sun_squawk_translator_ci_Opcode_opc_iinc 132
#define com_sun_squawk_translator_ci_Opcode_opc_i2l 133
#define com_sun_squawk_translator_ci_Opcode_opc_i2f 134
#define com_sun_squawk_translator_ci_Opcode_opc_i2d 135
#define com_sun_squawk_translator_ci_Opcode_opc_l2i 136
#define com_sun_squawk_translator_ci_Opcode_opc_l2f 137
#define com_sun_squawk_translator_ci_Opcode_opc_l2d 138
#define com_sun_squawk_translator_ci_Opcode_opc_f2i 139
#define com_sun_squawk_translator_ci_Opcode_opc_f2l 140
#define com_sun_squawk_translator_ci_Opcode_opc_f2d 141
#define com_sun_squawk_translator_ci_Opcode_opc_d2i 142
#define com_sun_squawk_translator_ci_Opcode_opc_d2l 143
#define com_sun_squawk_translator_ci_Opcode_opc_d2f 144
#define com_sun_squawk_translator_ci_Opcode_opc_i2b 145
#define com_sun_squawk_translator_ci_Opcode_opc_i2c 146
#define com_sun_squawk_translator_ci_Opcode_opc_i2s 147
#define com_sun_squawk_translator_ci_Opcode_opc_lcmp 148
#define com_sun_squawk_translator_ci_Opcode_opc_fcmpl 149
#define com_sun_squawk_translator_ci_Opcode_opc_fcmpg 150
#define com_sun_squawk_translator_ci_Opcode_opc_dcmpl 151
#define com_sun_squawk_translator_ci_Opcode_opc_dcmpg 152
#define com_sun_squawk_translator_ci_Opcode_opc_ifeq 153
#define com_sun_squawk_translator_ci_Opcode_opc_ifne 154
#define com_sun_squawk_translator_ci_Opcode_opc_iflt 155
#define com_sun_squawk_translator_ci_Opcode_opc_ifge 156
#define com_sun_squawk_translator_ci_Opcode_opc_ifgt 157
#define com_sun_squawk_translator_ci_Opcode_opc_ifle 158
#define com_sun_squawk_translator_ci_Opcode_opc_if_icmpeq 159
#define com_sun_squawk_translator_ci_Opcode_opc_if_icmpne 160
#define com_sun_squawk_translator_ci_Opcode_opc_if_icmplt 161
#define com_sun_squawk_translator_ci_Opcode_opc_if_icmpge 162
#define com_sun_squawk_translator_ci_Opcode_opc_if_icmpgt 163
#define com_sun_squawk_translator_ci_Opcode_opc_if_icmple 164
#define com_sun_squawk_translator_ci_Opcode_opc_if_acmpeq 165
#define com_sun_squawk_translator_ci_Opcode_opc_if_acmpne 166
#define com_sun_squawk_translator_ci_Opcode_opc_goto 167
#define com_sun_squawk_translator_ci_Opcode_opc_jsr 168
#define com_sun_squawk_translator_ci_Opcode_opc_ret 169
#define com_sun_squawk_translator_ci_Opcode_opc_tableswitch 170
#define com_sun_squawk_translator_ci_Opcode_opc_lookupswitch 171
#define com_sun_squawk_translator_ci_Opcode_opc_ireturn 172
#define com_sun_squawk_translator_ci_Opcode_opc_lreturn 173
#define com_sun_squawk_translator_ci_Opcode_opc_freturn 174
#define com_sun_squawk_translator_ci_Opcode_opc_dreturn 175
#define com_sun_squawk_translator_ci_Opcode_opc_areturn 176
#define com_sun_squawk_translator_ci_Opcode_opc_return 177
#define com_sun_squawk_translator_ci_Opcode_opc_getstatic 178
#define com_sun_squawk_translator_ci_Opcode_opc_putstatic 179
#define com_sun_squawk_translator_ci_Opcode_opc_getfield 180
#define com_sun_squawk_translator_ci_Opcode_opc_putfield 181
#define com_sun_squawk_translator_ci_Opcode_opc_invokevirtual 182
#define com_sun_squawk_translator_ci_Opcode_opc_invokespecial 183
#define com_sun_squawk_translator_ci_Opcode_opc_invokestatic 184
#define com_sun_squawk_translator_ci_Opcode_opc_invokeinterface 185
#define com_sun_squawk_translator_ci_Opcode_opc_xxxunusedxxx 186
#define com_sun_squawk_translator_ci_Opcode_opc_new 187
#define com_sun_squawk_translator_ci_Opcode_opc_newarray 188
#define com_sun_squawk_translator_ci_Opcode_opc_anewarray 189
#define com_sun_squawk_translator_ci_Opcode_opc_arraylength 190
#define com_sun_squawk_translator_ci_Opcode_opc_athrow 191
#define com_sun_squawk_translator_ci_Opcode_opc_checkcast 192
#define com_sun_squawk_translator_ci_Opcode_opc_instanceof 193
#define com_sun_squawk_translator_ci_Opcode_opc_monitorenter 194
#define com_sun_squawk_translator_ci_Opcode_opc_monitorexit 195
#define com_sun_squawk_translator_ci_Opcode_opc_wide 196
#define com_sun_squawk_translator_ci_Opcode_opc_multianewarray 197
#define com_sun_squawk_translator_ci_Opcode_opc_ifnull 198
#define com_sun_squawk_translator_ci_Opcode_opc_ifnonnull 199
#define com_sun_squawk_translator_ci_Opcode_opc_goto_w 200
#define com_sun_squawk_translator_ci_Opcode_opc_jsr_w 201
#define com_sun_squawk_translator_ci_Opcode_opc_breakpoint 202
#define com_sun_squawk_translator_ci_StackMap 276
#define com_sun_squawk_translator_ci_StackMap_ITEM_Top 0
#define com_sun_squawk_translator_ci_StackMap_ITEM_Integer 1
#define com_sun_squawk_translator_ci_StackMap_ITEM_Float 2
#define com_sun_squawk_translator_ci_StackMap_ITEM_Double 3
#define com_sun_squawk_translator_ci_StackMap_ITEM_Long 4
#define com_sun_squawk_translator_ci_StackMap_ITEM_Null 5
#define com_sun_squawk_translator_ci_StackMap_ITEM_UninitializedThis 6
#define com_sun_squawk_translator_ci_StackMap_ITEM_Object 7
#define com_sun_squawk_translator_ci_StackMap_ITEM_Uninitialized 8
#define com_sun_squawk_translator_ClassFile_1 277
#define com_sun_squawk_translator_ClassFile_1_this_0(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ClassFile_2 278
#define com_sun_squawk_translator_ClassFile_2_this_0(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ClassFile 279
#define com_sun_squawk_translator_ClassFile_definedClass(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ClassFile_virtualMethods(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ClassFile_staticMethods(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ClassFile_constantPool(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ClassFile_objectTable(oop) getObject(oop, 4)
#define com_sun_squawk_translator_ClassFile_nextIndex(oop) getInt(oop, 5)
#define com_sun_squawk_translator_Code 280
#define com_sun_squawk_translator_Code_code(oop) getObject(oop, 0)
#define com_sun_squawk_translator_Code_codeParser(oop) getObject(oop, 1)
#define com_sun_squawk_translator_Code_irBuilder(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ir_IRBuilder_OverwroteThisInConstructorError 281
#define com_sun_squawk_translator_ir_IRBuilder_OverwroteThisInConstructorError_this_0(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_IRBuilder 282
#define com_sun_squawk_translator_ir_IRBuilder_method(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ir_IRBuilder_codeParser(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ir_IRBuilder_ir(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ir_IRBuilder_frame(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_IRBuilder_handlers(oop) getObject(oop, 4)
#define com_sun_squawk_translator_ir_IRBuilder_copyOfThis(oop) getObject(oop, 5)
#define com_sun_squawk_translator_ir_IRBuilder_thisOverwritten(oop) getByte(oop, 24)
#define com_sun_squawk_translator_ir_instr_Position 283
#define com_sun_squawk_translator_ir_instr_PseudoInstruction 284
#define com_sun_squawk_translator_ir_instr_LoadLocal 285
#define com_sun_squawk_translator_ir_instr_LoadLocal_local(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_LoadLocal_isThis(oop) getByte(oop, 32)
#define com_sun_squawk_translator_ir_instr_StackProducer 286
#define com_sun_squawk_translator_ir_instr_StackProducer_type(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_StackProducer_useCount(oop) getInt(oop, 4)
#define com_sun_squawk_translator_ir_instr_StackProducer_spillLocal(oop) getObject(oop, 5)
#define com_sun_squawk_translator_ir_instr_StackProducer_isDuped(oop) getByte(oop, 24)
#define com_sun_squawk_translator_ir_instr_Mutator 287
#define com_sun_squawk_translator_ir_instr_LocalVariable 288
#define com_sun_squawk_translator_ir_instr_Constant 289
#define com_sun_squawk_translator_ir_instr_Constant_tag(oop) getInt(oop, 7)
#define com_sun_squawk_translator_ir_instr_Constant_value(oop) getObject(oop, 8)
#define com_sun_squawk_translator_ir_instr_TargetedInstruction 290
#define com_sun_squawk_translator_ir_instr_Catch 291
#define com_sun_squawk_translator_ir_instr_Catch_target(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_ArithmeticOp 292
#define com_sun_squawk_translator_ir_instr_ArithmeticOp_left(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_ArithmeticOp_right(oop) getObject(oop, 8)
#define com_sun_squawk_translator_ir_instr_ArithmeticOp_opcode(oop) getInt(oop, 9)
#define com_sun_squawk_translator_ir_instr_ArrayLength 293
#define com_sun_squawk_translator_ir_instr_ArrayLength_array(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_ArrayLoad 294
#define com_sun_squawk_translator_ir_instr_ArrayLoad_array(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_ArrayLoad_index(oop) getObject(oop, 8)
#define com_sun_squawk_translator_ir_instr_ArrayStore 295
#define com_sun_squawk_translator_ir_instr_ArrayStore_componentType(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_ArrayStore_array(oop) getObject(oop, 4)
#define com_sun_squawk_translator_ir_instr_ArrayStore_index(oop) getObject(oop, 5)
#define com_sun_squawk_translator_ir_instr_ArrayStore_value(oop) getObject(oop, 6)
#define com_sun_squawk_translator_ir_instr_Branch 296
#define com_sun_squawk_translator_ir_instr_Branch_target(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_Branch_isForward(oop) getByte(oop, 16)
#define com_sun_squawk_translator_ir_instr_CheckCast 297
#define com_sun_squawk_translator_ir_instr_CheckCast_object(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_ConversionOp 298
#define com_sun_squawk_translator_ir_instr_ConversionOp_opcode(oop) getInt(oop, 7)
#define com_sun_squawk_translator_ir_instr_ConversionOp_value(oop) getObject(oop, 8)
#define com_sun_squawk_translator_ir_instr_ComparisonOp 299
#define com_sun_squawk_translator_ir_instr_ComparisonOp_left(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_ComparisonOp_right(oop) getObject(oop, 8)
#define com_sun_squawk_translator_ir_instr_ComparisonOp_opcode(oop) getInt(oop, 9)
#define com_sun_squawk_translator_ir_instr_Try 300
#define com_sun_squawk_translator_ir_instr_TryEnd 301
#define com_sun_squawk_translator_ir_instr_If 302
#define com_sun_squawk_translator_ir_instr_If_value(oop) getObject(oop, 5)
#define com_sun_squawk_translator_ir_instr_If_opcode(oop) getInt(oop, 6)
#define com_sun_squawk_translator_ir_instr_IfCompare 303
#define com_sun_squawk_translator_ir_instr_IfCompare_right(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_IncDecLocal 304
#define com_sun_squawk_translator_ir_instr_IncDecLocal_local(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_IncDecLocal_increment(oop) getByte(oop, 16)
#define com_sun_squawk_translator_ir_instr_InstanceOf 305
#define com_sun_squawk_translator_ir_instr_InstanceOf_object(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_InstanceOf_checkType(oop) getObject(oop, 8)
#define com_sun_squawk_translator_ir_instr_FindSlot 306
#define com_sun_squawk_translator_ir_instr_FindSlot_method(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_FindSlot_receiver(oop) getObject(oop, 8)
#define com_sun_squawk_translator_ir_instr_InvokeSlot 307
#define com_sun_squawk_translator_ir_instr_Invoke 308
#define com_sun_squawk_translator_ir_instr_Invoke_method(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_Invoke_parameters(oop) getObject(oop, 8)
#define com_sun_squawk_translator_ir_instr_InvokeStatic 309
#define com_sun_squawk_translator_ir_instr_InvokeSuper 310
#define com_sun_squawk_translator_ir_instr_InvokeVirtual 311
#define com_sun_squawk_translator_ir_instr_GetField 312
#define com_sun_squawk_translator_ir_instr_GetField_field(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_GetField_object(oop) getObject(oop, 8)
#define com_sun_squawk_translator_ir_instr_InstanceFieldAccessor 313
#define com_sun_squawk_translator_ir_instr_FieldAccessor 314
#define com_sun_squawk_translator_ir_instr_GetStatic 315
#define com_sun_squawk_translator_ir_instr_GetStatic_field(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_LookupSwitch 316
#define com_sun_squawk_translator_ir_instr_LookupSwitch_caseValues(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_Switch 317
#define com_sun_squawk_translator_ir_instr_Switch_key(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_Switch_targets(oop) getObject(oop, 4)
#define com_sun_squawk_translator_ir_instr_Switch_defaultTarget(oop) getObject(oop, 5)
#define com_sun_squawk_translator_ir_instr_Switch_padding(oop) getInt(oop, 6)
#define com_sun_squawk_translator_ir_instr_MonitorEnter 318
#define com_sun_squawk_translator_ir_instr_MonitorEnter_object(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_MonitorExit 319
#define com_sun_squawk_translator_ir_instr_MonitorExit_object(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_NegationOp 320
#define com_sun_squawk_translator_ir_instr_NegationOp_value(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_NegationOp_opcode(oop) getInt(oop, 8)
#define com_sun_squawk_translator_ir_instr_NewArray 321
#define com_sun_squawk_translator_ir_instr_NewArray_length(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_NewDimension 322
#define com_sun_squawk_translator_ir_instr_NewDimension_array(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_NewDimension_length(oop) getObject(oop, 8)
#define com_sun_squawk_translator_ir_instr_New 323
#define com_sun_squawk_translator_ir_instr_Phi 324
#define com_sun_squawk_translator_ir_instr_Phi_target(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_Pop 325
#define com_sun_squawk_translator_ir_instr_Pop_value(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_Return 326
#define com_sun_squawk_translator_ir_instr_Return_value(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_PutField 327
#define com_sun_squawk_translator_ir_instr_PutField_field(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_PutField_value(oop) getObject(oop, 4)
#define com_sun_squawk_translator_ir_instr_PutField_object(oop) getObject(oop, 5)
#define com_sun_squawk_translator_ir_instr_PutStatic 328
#define com_sun_squawk_translator_ir_instr_PutStatic_field(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_PutStatic_value(oop) getObject(oop, 4)
#define com_sun_squawk_translator_ir_instr_StoreLocal 329
#define com_sun_squawk_translator_ir_instr_StoreLocal_value(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_StoreLocal_local(oop) getObject(oop, 4)
#define com_sun_squawk_translator_ir_instr_StoreLocal_isThis(oop) getByte(oop, 20)
#define com_sun_squawk_translator_ir_instr_StackMerge_ProducerVisitor 330
#define com_sun_squawk_translator_ir_instr_StackMerge 331
#define com_sun_squawk_translator_ir_instr_StackMerge_producers(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_instr_StackOp 332
#define com_sun_squawk_translator_ir_instr_StackOp_opcode(oop) getInt(oop, 3)
#define com_sun_squawk_translator_ir_instr_TableSwitch 333
#define com_sun_squawk_translator_ir_instr_TableSwitch_low(oop) getInt(oop, 7)
#define com_sun_squawk_translator_ir_instr_TableSwitch_high(oop) getInt(oop, 8)
#define com_sun_squawk_translator_ir_instr_Throw 334
#define com_sun_squawk_translator_ir_instr_Throw_throwable(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_instr_ConstantInt 335
#define com_sun_squawk_translator_ir_instr_ConstantLong 336
#define com_sun_squawk_translator_ir_instr_ConstantObject 337
#define com_sun_squawk_translator_ir_Instruction 338
#define com_sun_squawk_translator_ir_Instruction_offset(oop) getInt(oop, 0)
#define com_sun_squawk_translator_ir_Instruction_next(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ir_Instruction_previous(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ir_Instruction_OFFSETNOTDEFINED -99999
#define com_sun_squawk_translator_ir_Target 339
#define com_sun_squawk_translator_ir_Target_address(oop) getInt(oop, 0)
#define com_sun_squawk_translator_ir_Target_stack(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ir_Target_derivedStack(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ir_Target_locals(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_Target_instruction(oop) getObject(oop, 4)
#define com_sun_squawk_translator_ir_Target_isCatchTarget(oop) getByte(oop, 20)
#define com_sun_squawk_translator_ir_Target_isForwardBranchTarget(oop) getByte(oop, 21)
#define com_sun_squawk_translator_ir_Target_isBackwardBranchTarget(oop) getByte(oop, 22)
#define com_sun_squawk_translator_ir_IR_1 340
#define com_sun_squawk_translator_ir_IR_1_instruction(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ir_IR_1_this_0(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ir_IR_1_val_reverse(oop) getByte(oop, 8)
#define com_sun_squawk_translator_ir_IR 341
#define com_sun_squawk_translator_ir_IR_head(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ir_IR_tail(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ir_IR_exceptionHandlers(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ir_IR_targets(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_Frame 342
#define com_sun_squawk_translator_ir_Frame_codeParser(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ir_Frame_finallyTargetForSynchronizedMethod(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ir_Frame_localValues(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ir_Frame_localTypes(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_Frame_parameterLocalsCount(oop) getInt(oop, 4)
#define com_sun_squawk_translator_ir_Frame_stack(oop) getObject(oop, 5)
#define com_sun_squawk_translator_ir_Frame_sp(oop) getInt(oop, 6)
#define com_sun_squawk_translator_ir_Frame_maxStack(oop) getInt(oop, 7)
#define com_sun_squawk_translator_ir_Frame_nextSpillLocalId(oop) getInt(oop, 8)
#define com_sun_squawk_translator_ir_InstructionVisitor 343
#define com_sun_squawk_translator_ir_OperandVisitor 344
#define com_sun_squawk_translator_ir_IRExceptionHandler 345
#define com_sun_squawk_translator_ir_IRExceptionHandler_entry(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ir_IRExceptionHandler_exit(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ir_IRExceptionHandler_target(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ir_Local 346
#define com_sun_squawk_translator_ir_Local_type(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ir_Local_javacIndex(oop) getInt(oop, 1)
#define com_sun_squawk_translator_ir_Local_parameterIndex(oop) getInt(oop, 2)
#define com_sun_squawk_translator_ir_Local_slot(oop) getObject(oop, 3)
#define com_sun_squawk_translator_ir_Local_lastUse(oop) getObject(oop, 4)
#define com_sun_squawk_translator_ir_Local_isDead(oop) getByte(oop, 20)
#define com_sun_squawk_translator_ir_Local_uninitializedAtGC(oop) getByte(oop, 21)
#define com_sun_squawk_translator_ir_Slot 347
#define com_sun_squawk_translator_ir_Slot_type(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ir_Slot_squawkIndex(oop) getInt(oop, 1)
#define com_sun_squawk_translator_ir_Slot_free(oop) getByte(oop, 8)
#define com_sun_squawk_translator_ir_Slot_isForStack(oop) getByte(oop, 9)
#define com_sun_squawk_translator_ir_Slot_needsClearing(oop) getByte(oop, 10)
#define com_sun_squawk_translator_ir_SlotAllocator 348
#define com_sun_squawk_translator_ir_SlotAllocator_method(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ir_SlotAllocator_ir(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ir_SlotAllocator_slots(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ir_InstructionEmitter 349
#define com_sun_squawk_translator_ir_InstructionEmitter_ir(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ir_InstructionEmitter_code(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ir_InstructionEmitter_typeMap(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ir_InstructionEmitter_clearedSlots(oop) getInt(oop, 3)
#define com_sun_squawk_translator_ir_InstructionEmitter_count(oop) getInt(oop, 4)
#define com_sun_squawk_translator_ir_InstructionEmitter_lastOpcode(oop) getInt(oop, 5)
#define com_sun_squawk_translator_ir_InstructionEmitter_classFile(oop) getObject(oop, 6)
#define com_sun_squawk_translator_ir_InstructionEmitter_method(oop) getObject(oop, 7)
#define com_sun_squawk_translator_ir_InstructionEmitter_state(oop) getInt(oop, 8)
#define com_sun_squawk_translator_ir_InstructionEmitter_resultType(oop) getByte(oop, 36)
#define com_sun_squawk_translator_ir_InstructionEmitter_sizeUnknown(oop) getByte(oop, 37)
#define com_sun_squawk_translator_ir_InstructionEmitter_isAppClass(oop) getByte(oop, 38)
#define com_sun_squawk_translator_ir_InstructionEmitter_NONE 0
#define com_sun_squawk_translator_ir_InstructionEmitter_INIT 1
#define com_sun_squawk_translator_ir_InstructionEmitter_CHECK 2
#define com_sun_squawk_translator_ir_InstructionEmitter_EMIT 3
#define com_sun_squawk_translator_ir_IRTransformer 350
#define com_sun_squawk_translator_ir_IRTransformer_method(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ir_IRTransformer_ir(oop) getObject(oop, 1)
#define com_sun_squawk_translator_ir_IRTransformer_frame(oop) getObject(oop, 2)
#define com_sun_squawk_translator_ir_IRTransformer_oneOrMoreOperandsSpilt(oop) getByte(oop, 12)
#define com_sun_squawk_translator_ir_IRUseCounter 351
#define com_sun_squawk_translator_ObjectCounter 352
#define com_sun_squawk_translator_ObjectCounter_object(oop) getObject(oop, 0)
#define com_sun_squawk_translator_ObjectCounter_index(oop) getInt(oop, 1)
#define com_sun_squawk_translator_ObjectCounter_counter(oop) getInt(oop, 2)
#define com_sun_squawk_translator_Translator 353
#define com_sun_squawk_translator_Translator_suite(oop) getObject(oop, 0)
#define com_sun_squawk_translator_Translator_classPath(oop) getObject(oop, 1)
#define com_sun_squawk_translator_Translator_classFiles(oop) getObject(oop, 2)
#define java_lang_VM_addToClassStateCache 0
#define java_lang_VM_allocate 1
#define java_lang_VM_allocateVirtualStack 2
#define java_lang_VM_asKlass 3
#define java_lang_VM_asThread 4
#define java_lang_VM_callStaticNoParm 5
#define java_lang_VM_callStaticOneParm 6
#define java_lang_VM_deadbeef 7
#define java_lang_VM_executeCIO 8
#define java_lang_VM_executeCOG 9
#define java_lang_VM_executeGC 10
#define java_lang_VM_fatalVMError 11
#define java_lang_VM_getBranchCount 12
#define java_lang_VM_getFP 13
#define java_lang_VM_getGlobalAddr 14
#define java_lang_VM_getGlobalAddrCount 15
#define java_lang_VM_getGlobalInt 16
#define java_lang_VM_getGlobalIntCount 17
#define java_lang_VM_getGlobalOop 18
#define java_lang_VM_getGlobalOopCount 19
#define java_lang_VM_getGlobalOopTable 20
#define java_lang_VM_getMP 21
#define java_lang_VM_getPreviousFP 22
#define java_lang_VM_getPreviousIP 23
#define java_lang_VM_hasVirtualMonitorObject 24
#define java_lang_VM_hashcode 25
#define java_lang_VM_invalidateClassStateCache 26
#define java_lang_VM_isBigEndian 27
#define java_lang_VM_removeVirtualMonitorObject 28
#define java_lang_VM_serviceResult 29
#define java_lang_VM_setGlobalAddr 30
#define java_lang_VM_setGlobalInt 31
#define java_lang_VM_setGlobalOop 32
#define java_lang_VM_setPreviousFP 33
#define java_lang_VM_setPreviousIP 34
#define java_lang_VM_setWriteBarrier 35
#define java_lang_VM_threadSwitch 36
#define java_lang_VM_zeroWords 37
#define java_lang_Address_add 38
#define java_lang_Address_addOffset 39
#define java_lang_Address_and 40
#define java_lang_Address_diff 41
#define java_lang_Address_eq 42
#define java_lang_Address_fromObject 43
#define java_lang_Address_hi 44
#define java_lang_Address_hieq 45
#define java_lang_Address_isMax 46
#define java_lang_Address_isZero 47
#define java_lang_Address_lo 48
#define java_lang_Address_loeq 49
#define java_lang_Address_max 50
#define java_lang_Address_ne 51
#define java_lang_Address_or 52
#define java_lang_Address_roundDown 53
#define java_lang_Address_roundDownToWord 54
#define java_lang_Address_roundUp 55
#define java_lang_Address_roundUpToWord 56
#define java_lang_Address_sub 57
#define java_lang_Address_subOffset 58
#define java_lang_Address_toObject 59
#define java_lang_Address_toUWord 60
#define java_lang_Address_zero 61
#define java_lang_UWord_and 62
#define java_lang_UWord_eq 63
#define java_lang_UWord_fromPrimitive 64
#define java_lang_UWord_hi 65
#define java_lang_UWord_hieq 66
#define java_lang_UWord_isMax 67
#define java_lang_UWord_isZero 68
#define java_lang_UWord_lo 69
#define java_lang_UWord_loeq 70
#define java_lang_UWord_max 71
#define java_lang_UWord_ne 72
#define java_lang_UWord_or 73
#define java_lang_UWord_toInt 74
#define java_lang_UWord_toOffset 75
#define java_lang_UWord_toPrimitive 76
#define java_lang_UWord_zero 77
#define java_lang_Offset_add 78
#define java_lang_Offset_eq 79
#define java_lang_Offset_fromPrimitive 80
#define java_lang_Offset_ge 81
#define java_lang_Offset_gt 82
#define java_lang_Offset_isZero 83
#define java_lang_Offset_le 84
#define java_lang_Offset_lt 85
#define java_lang_Offset_ne 86
#define java_lang_Offset_sub 87
#define java_lang_Offset_toInt 88
#define java_lang_Offset_toPrimitive 89
#define java_lang_Offset_toUWord 90
#define java_lang_Offset_zero 91
#define java_lang_Unsafe_charAt 92
#define java_lang_Unsafe_copyTypes 93
#define java_lang_Unsafe_getAsByte 94
#define java_lang_Unsafe_getAsUWord 95
#define java_lang_Unsafe_getByte 96
#define java_lang_Unsafe_getChar 97
#define java_lang_Unsafe_getInt 98
#define java_lang_Unsafe_getLong 99
#define java_lang_Unsafe_getLongAtWord 100
#define java_lang_Unsafe_getObject 101
#define java_lang_Unsafe_getShort 102
#define java_lang_Unsafe_getType 103
#define java_lang_Unsafe_getUWord 104
#define java_lang_Unsafe_setAddress 105
#define java_lang_Unsafe_setByte 106
#define java_lang_Unsafe_setChar 107
#define java_lang_Unsafe_setInt 108
#define java_lang_Unsafe_setLong 109
#define java_lang_Unsafe_setLongAtWord 110
#define java_lang_Unsafe_setObject 111
#define java_lang_Unsafe_setShort 112
#define java_lang_Unsafe_setType 113
#define java_lang_Unsafe_setUWord 114
#define java_lang_CheneyCollector_memoryProtect 115
#define java_lang_ServiceOperation_cioExecute 116
#define java_lang_VM_lcmp 117
#define ENTRY_COUNT 118
#define java_lang_VM_do_startup Address_add(java_lang_VM_romStart, 4616)
#define java_lang_VM_do_undefinedNativeMethod Address_add(java_lang_VM_romStart, 4736)
#define java_lang_VM_do_callRun Address_add(java_lang_VM_romStart, 4784)
#define java_lang_VM_do_getStaticOop Address_add(java_lang_VM_romStart, 4812)
#define java_lang_VM_do_getStaticInt Address_add(java_lang_VM_romStart, 4852)
#define java_lang_VM_do_getStaticLong Address_add(java_lang_VM_romStart, 4896)
#define java_lang_VM_do_putStaticOop Address_add(java_lang_VM_romStart, 4936)
#define java_lang_VM_do_putStaticInt Address_add(java_lang_VM_romStart, 4980)
#define java_lang_VM_do_putStaticLong Address_add(java_lang_VM_romStart, 5028)
#define java_lang_VM_do_yield Address_add(java_lang_VM_romStart, 5072)
#define java_lang_VM_do_nullPointerException Address_add(java_lang_VM_romStart, 5100)
#define java_lang_VM_do_arrayIndexOutOfBoundsException Address_add(java_lang_VM_romStart, 5132)
#define java_lang_VM_do_arithmeticException Address_add(java_lang_VM_romStart, 5164)
#define java_lang_VM_do_arrayOopStore Address_add(java_lang_VM_romStart, 5196)
#define java_lang_VM_do_findSlot Address_add(java_lang_VM_romStart, 5260)
#define java_lang_VM_do_monitorenter Address_add(java_lang_VM_romStart, 5300)
#define java_lang_VM_do_monitorexit Address_add(java_lang_VM_romStart, 5332)
#define java_lang_VM_do_instanceof Address_add(java_lang_VM_romStart, 5364)
#define java_lang_VM_do_checkcast Address_add(java_lang_VM_romStart, 5412)
#define java_lang_VM_do_lookup_b Address_add(java_lang_VM_romStart, 5456)
#define java_lang_VM_do_lookup_s Address_add(java_lang_VM_romStart, 5528)
#define java_lang_VM_do_lookup_i Address_add(java_lang_VM_romStart, 5600)
#define java_lang_VM_do_class_clinit Address_add(java_lang_VM_romStart, 5672)
#define java_lang_VM_do_new Address_add(java_lang_VM_romStart, 5700)
#define java_lang_VM_do_newarray Address_add(java_lang_VM_romStart, 5732)
#define java_lang_VM_do_newdimension Address_add(java_lang_VM_romStart, 5764)
#define java_lang_VM_do_lcmp Address_add(java_lang_VM_romStart, 5804)
const char *AddressType_Mnemonics = "-ZbBSIFLlDdRU";
char *getOpcodeName(int code) {
    switch(code) {
        case 0: return "const_0";
        case 1: return "const_1";
        case 2: return "const_2";
        case 3: return "const_3";
        case 4: return "const_4";
        case 5: return "const_5";
        case 6: return "const_6";
        case 7: return "const_7";
        case 8: return "const_8";
        case 9: return "const_9";
        case 10: return "const_10";
        case 11: return "const_11";
        case 12: return "const_12";
        case 13: return "const_13";
        case 14: return "const_14";
        case 15: return "const_15";
        case 16: return "object_0";
        case 17: return "object_1";
        case 18: return "object_2";
        case 19: return "object_3";
        case 20: return "object_4";
        case 21: return "object_5";
        case 22: return "object_6";
        case 23: return "object_7";
        case 24: return "object_8";
        case 25: return "object_9";
        case 26: return "object_10";
        case 27: return "object_11";
        case 28: return "object_12";
        case 29: return "object_13";
        case 30: return "object_14";
        case 31: return "object_15";
        case 32: return "load_0";
        case 33: return "load_1";
        case 34: return "load_2";
        case 35: return "load_3";
        case 36: return "load_4";
        case 37: return "load_5";
        case 38: return "load_6";
        case 39: return "load_7";
        case 40: return "load_8";
        case 41: return "load_9";
        case 42: return "load_10";
        case 43: return "load_11";
        case 44: return "load_12";
        case 45: return "load_13";
        case 46: return "load_14";
        case 47: return "load_15";
        case 48: return "store_0";
        case 49: return "store_1";
        case 50: return "store_2";
        case 51: return "store_3";
        case 52: return "store_4";
        case 53: return "store_5";
        case 54: return "store_6";
        case 55: return "store_7";
        case 56: return "store_8";
        case 57: return "store_9";
        case 58: return "store_10";
        case 59: return "store_11";
        case 60: return "store_12";
        case 61: return "store_13";
        case 62: return "store_14";
        case 63: return "store_15";
        case 64: return "loadparm_0";
        case 65: return "loadparm_1";
        case 66: return "loadparm_2";
        case 67: return "loadparm_3";
        case 68: return "loadparm_4";
        case 69: return "loadparm_5";
        case 70: return "loadparm_6";
        case 71: return "loadparm_7";
        case 72: return "wide_m1";
        case 73: return "wide_0";
        case 74: return "wide_1";
        case 75: return "wide_short";
        case 76: return "wide_int";
        case 77: return "escape";
        case 78: return "escape_wide_m1";
        case 79: return "escape_wide_0";
        case 80: return "escape_wide_1";
        case 81: return "escape_wide_short";
        case 82: return "escape_wide_int";
        case 83: return "catch";
        case 84: return "const_null";
        case 85: return "const_m1";
        case 86: return "const_byte";
        case 87: return "const_short";
        case 88: return "const_char";
        case 89: return "const_int";
        case 90: return "const_long";
        case 91: return "object";
        case 92: return "load";
        case 93: return "load_i2";
        case 94: return "store";
        case 95: return "store_i2";
        case 96: return "loadparm";
        case 97: return "loadparm_i2";
        case 98: return "storeparm";
        case 99: return "storeparm_i2";
        case 100: return "inc";
        case 101: return "dec";
        case 102: return "incparm";
        case 103: return "decparm";
        case 104: return "goto";
        case 105: return "if_eq_o";
        case 106: return "if_ne_o";
        case 107: return "if_cmpeq_o";
        case 108: return "if_cmpne_o";
        case 109: return "if_eq_i";
        case 110: return "if_ne_i";
        case 111: return "if_lt_i";
        case 112: return "if_le_i";
        case 113: return "if_gt_i";
        case 114: return "if_ge_i";
        case 115: return "if_cmpeq_i";
        case 116: return "if_cmpne_i";
        case 117: return "if_cmplt_i";
        case 118: return "if_cmple_i";
        case 119: return "if_cmpgt_i";
        case 120: return "if_cmpge_i";
        case 121: return "if_eq_l";
        case 122: return "if_ne_l";
        case 123: return "if_lt_l";
        case 124: return "if_le_l";
        case 125: return "if_gt_l";
        case 126: return "if_ge_l";
        case 127: return "if_cmpeq_l";
        case 128: return "if_cmpne_l";
        case 129: return "if_cmplt_l";
        case 130: return "if_cmple_l";
        case 131: return "if_cmpgt_l";
        case 132: return "if_cmpge_l";
        case 133: return "getstatic_i";
        case 134: return "getstatic_o";
        case 135: return "getstatic_l";
        case 136: return "class_getstatic_i";
        case 137: return "class_getstatic_o";
        case 138: return "class_getstatic_l";
        case 139: return "putstatic_i";
        case 140: return "putstatic_o";
        case 141: return "putstatic_l";
        case 142: return "class_putstatic_i";
        case 143: return "class_putstatic_o";
        case 144: return "class_putstatic_l";
        case 145: return "getfield_i";
        case 146: return "getfield_b";
        case 147: return "getfield_s";
        case 148: return "getfield_c";
        case 149: return "getfield_o";
        case 150: return "getfield_l";
        case 151: return "this_getfield_i";
        case 152: return "this_getfield_b";
        case 153: return "this_getfield_s";
        case 154: return "this_getfield_c";
        case 155: return "this_getfield_o";
        case 156: return "this_getfield_l";
        case 157: return "putfield_i";
        case 158: return "putfield_b";
        case 159: return "putfield_s";
        case 160: return "putfield_o";
        case 161: return "putfield_l";
        case 162: return "this_putfield_i";
        case 163: return "this_putfield_b";
        case 164: return "this_putfield_s";
        case 165: return "this_putfield_o";
        case 166: return "this_putfield_l";
        case 167: return "invokevirtual_i";
        case 168: return "invokevirtual_v";
        case 169: return "invokevirtual_l";
        case 170: return "invokevirtual_o";
        case 171: return "invokestatic_i";
        case 172: return "invokestatic_v";
        case 173: return "invokestatic_l";
        case 174: return "invokestatic_o";
        case 175: return "invokesuper_i";
        case 176: return "invokesuper_v";
        case 177: return "invokesuper_l";
        case 178: return "invokesuper_o";
        case 179: return "invokenative_i";
        case 180: return "invokenative_v";
        case 181: return "invokenative_l";
        case 182: return "invokenative_o";
        case 183: return "findslot";
        case 184: return "extend";
        case 185: return "invokeslot_i";
        case 186: return "invokeslot_v";
        case 187: return "invokeslot_l";
        case 188: return "invokeslot_o";
        case 189: return "return_v";
        case 190: return "return_i";
        case 191: return "return_l";
        case 192: return "return_o";
        case 193: return "tableswitch_i";
        case 194: return "tableswitch_s";
        case 195: return "extend0";
        case 196: return "add_i";
        case 197: return "sub_i";
        case 198: return "and_i";
        case 199: return "or_i";
        case 200: return "xor_i";
        case 201: return "shl_i";
        case 202: return "shr_i";
        case 203: return "ushr_i";
        case 204: return "mul_i";
        case 205: return "div_i";
        case 206: return "rem_i";
        case 207: return "neg_i";
        case 208: return "i2b";
        case 209: return "i2s";
        case 210: return "i2c";
        case 211: return "add_l";
        case 212: return "sub_l";
        case 213: return "mul_l";
        case 214: return "div_l";
        case 215: return "rem_l";
        case 216: return "and_l";
        case 217: return "or_l";
        case 218: return "xor_l";
        case 219: return "neg_l";
        case 220: return "shl_l";
        case 221: return "shr_l";
        case 222: return "ushr_l";
        case 223: return "l2i";
        case 224: return "i2l";
        case 225: return "throw";
        case 226: return "pop_1";
        case 227: return "pop_2";
        case 228: return "monitorenter";
        case 229: return "monitorexit";
        case 230: return "class_monitorenter";
        case 231: return "class_monitorexit";
        case 232: return "arraylength";
        case 233: return "new";
        case 234: return "newarray";
        case 235: return "newdimension";
        case 236: return "class_clinit";
        case 237: return "bbtarget_sys";
        case 238: return "bbtarget_app";
        case 239: return "instanceof";
        case 240: return "checkcast";
        case 241: return "aload_i";
        case 242: return "aload_b";
        case 243: return "aload_s";
        case 244: return "aload_c";
        case 245: return "aload_o";
        case 246: return "aload_l";
        case 247: return "astore_i";
        case 248: return "astore_b";
        case 249: return "astore_s";
        case 250: return "astore_o";
        case 251: return "astore_l";
        case 252: return "lookup_i";
        case 253: return "lookup_b";
        case 254: return "lookup_s";
        case 255: return "res_0";
        default: return "Unknown opcode";
    }
}
const char* getGlobalAddrName(int index) {
    switch(index) {
        case 10: return "java_lang_GC_ramStart";
        case 7: return "java_lang_GC_nvmAllocationPointer";
        case 5: return "writeBarrierBase";
        case 3: return "cheneyEndMemoryProtect";
        case 17: return "java_lang_VM_romEnd";
        case 4: return "writeBarrier";
        case 12: return "java_lang_GC_ramAllocationPointer";
        case 8: return "java_lang_GC_nvmEnd";
        case 16: return "java_lang_VM_romStart";
        case 2: return "cheneyStartMemoryProtect";
        case 9: return "java_lang_GC_nvmStart";
        case 6: return "java_lang_Thread_serviceStack";
        case 18: return "java_lang_VM_romFileName";
        case 13: return "java_lang_GC_ramAllocationStartPointer";
        case 15: return "java_lang_VM_argv";
        case 14: return "java_lang_GC_ramAllocationEndPointer";
        case 1: return "java_lang_ServiceOperation_o2";
        case 0: return "java_lang_ServiceOperation_o1";
        case 11: return "java_lang_GC_ramEnd";
        default: return "getGlobalAddrName: unknown global index";
    }
}
const char* getGlobalOopName(int index) {
    switch(index) {
        case 3: return "java_lang_Thread_serviceThread";
        case 6: return "java_lang_Thread_runnableThreads";
        case 11: return "java_lang_GC_collector";
        case 14: return "java_lang_VM_vmbufferDecoder";
        case 5: return "java_lang_Thread_timerQueue";
        case 13: return "java_lang_GC_readOnlyObjectMemories";
        case 12: return "java_lang_GC_stackChunks";
        case 9: return "com_sun_squawk_util_Tracer__out";
        case 0: return "java_lang_VM_currentIsolate";
        case 15: return "java_lang_VM_outOfMemoryError";
        case 2: return "java_lang_Thread_otherThread";
        case 4: return "java_lang_ServiceOperation_pendingException";
        case 10: return "com_sun_squawk_util_Tracer_filter";
        case 7: return "java_lang_Thread_events";
        case 1: return "java_lang_Thread_currentThread";
        case 8: return "com_sun_squawk_util_Tracer__features";
        default: return "getGlobalOopName: unknown global index";
    }
}
const char* getGlobalIntName(int index) {
    switch(index) {
        case 38: return "java_lang_VM_exceptionsEnabled";
        case 32: return "java_lang_GC_gcEnabled";
        case 26: return "writeBarrierSize";
        case 24: return "tracing";
        case 36: return "java_lang_VM_argc";
        case 30: return "java_lang_GC_fullCollectionCount";
        case 34: return "java_lang_GC_partialCollectionCount";
        case 28: return "newHits";
        case 25: return "runningOnServiceThread";
        case 9: return "java_lang_ServiceOperation_op";
        case 33: return "java_lang_GC_allocationEnabled";
        case 29: return "java_lang_GC_excessiveGC";
        case 7: return "java_lang_ServiceOperation_code";
        case 41: return "java_lang_VM_nextHashcode";
        case 17: return "java_lang_ServiceOperation_result";
        case 18: return "branchCountHigh";
        case 31: return "java_lang_GC_traceThreshold";
        case 0: return "java_lang_VM_extendsEnabled";
        case 20: return "traceStartHigh";
        case 10: return "java_lang_ServiceOperation_channel";
        case 1: return "java_lang_VM_usingTypeMap";
        case 2: return "java_lang_GC_traceFlags";
        case 5: return "java_lang_GC_monitorReleaseCount";
        case 4: return "java_lang_GC_monitorExitCount";
        case 21: return "traceStartLow";
        case 19: return "branchCountLow";
        case 8: return "java_lang_ServiceOperation_context";
        case 39: return "java_lang_VM_romHash";
        case 22: return "traceEndHigh";
        case 16: return "java_lang_ServiceOperation_i6";
        case 15: return "java_lang_ServiceOperation_i5";
        case 14: return "java_lang_ServiceOperation_i4";
        case 6: return "java_lang_Thread_nextThreadNumber";
        case 27: return "newCount";
        case 13: return "java_lang_ServiceOperation_i3";
        case 12: return "java_lang_ServiceOperation_i2";
        case 3: return "java_lang_GC_collecting";
        case 11: return "java_lang_ServiceOperation_i1";
        case 40: return "java_lang_VM_verboseLevel";
        case 35: return "java_lang_VM_allowUserGC";
        case 37: return "java_lang_VM_synchronizationEnabled";
        case 23: return "traceEndLow";
        default: return "getGlobalIntName: unknown global index";
    }
}
#define java_lang_VM_exceptionsEnabled (Ints[38])
#define java_lang_GC_gcEnabled (Ints[32])
#define writeBarrierSize (Ints[26])
#define tracing (Ints[24])
#define java_lang_VM_argc (Ints[36])
#define java_lang_GC_fullCollectionCount (Ints[30])
#define java_lang_GC_partialCollectionCount (Ints[34])
#define newHits (Ints[28])
#define runningOnServiceThread (Ints[25])
#define java_lang_ServiceOperation_op (Ints[9])
#define java_lang_GC_allocationEnabled (Ints[33])
#define java_lang_GC_excessiveGC (Ints[29])
#define java_lang_ServiceOperation_code (Ints[7])
#define java_lang_VM_nextHashcode (Ints[41])
#define java_lang_ServiceOperation_result (Ints[17])
#define branchCountHigh (Ints[18])
#define java_lang_GC_traceThreshold (Ints[31])
#define java_lang_VM_extendsEnabled (Ints[0])
#define traceStartHigh (Ints[20])
#define java_lang_ServiceOperation_channel (Ints[10])
#define java_lang_VM_usingTypeMap (Ints[1])
#define java_lang_GC_traceFlags (Ints[2])
#define java_lang_GC_monitorReleaseCount (Ints[5])
#define java_lang_GC_monitorExitCount (Ints[4])
#define traceStartLow (Ints[21])
#define branchCountLow (Ints[19])
#define java_lang_ServiceOperation_context (Ints[8])
#define java_lang_VM_romHash (Ints[39])
#define traceEndHigh (Ints[22])
#define java_lang_ServiceOperation_i6 (Ints[16])
#define java_lang_ServiceOperation_i5 (Ints[15])
#define java_lang_ServiceOperation_i4 (Ints[14])
#define java_lang_Thread_nextThreadNumber (Ints[6])
#define newCount (Ints[27])
#define java_lang_ServiceOperation_i3 (Ints[13])
#define java_lang_ServiceOperation_i2 (Ints[12])
#define java_lang_GC_collecting (Ints[3])
#define java_lang_ServiceOperation_i1 (Ints[11])
#define java_lang_VM_verboseLevel (Ints[40])
#define java_lang_VM_allowUserGC (Ints[35])
#define java_lang_VM_synchronizationEnabled (Ints[37])
#define traceEndLow (Ints[23])
#define java_lang_GC_ramStart (Addrs[10])
#define java_lang_GC_nvmAllocationPointer (Addrs[7])
#define writeBarrierBase (Addrs[5])
#define cheneyEndMemoryProtect (Addrs[3])
#define java_lang_VM_romEnd (Addrs[17])
#define writeBarrier (Addrs[4])
#define java_lang_GC_ramAllocationPointer (Addrs[12])
#define java_lang_GC_nvmEnd (Addrs[8])
#define java_lang_VM_romStart (Addrs[16])
#define cheneyStartMemoryProtect (Addrs[2])
#define java_lang_GC_nvmStart (Addrs[9])
#define java_lang_Thread_serviceStack (Addrs[6])
#define java_lang_VM_romFileName (Addrs[18])
#define java_lang_GC_ramAllocationStartPointer (Addrs[13])
#define java_lang_VM_argv (Addrs[15])
#define java_lang_GC_ramAllocationEndPointer (Addrs[14])
#define java_lang_ServiceOperation_o2 (Addrs[1])
#define java_lang_ServiceOperation_o1 (Addrs[0])
#define java_lang_GC_ramEnd (Addrs[11])
#define java_lang_Thread_serviceThread (Oops[3])
#define java_lang_Thread_runnableThreads (Oops[6])
#define java_lang_GC_collector (Oops[11])
#define java_lang_VM_vmbufferDecoder (Oops[14])
#define java_lang_Thread_timerQueue (Oops[5])
#define java_lang_GC_readOnlyObjectMemories (Oops[13])
#define java_lang_GC_stackChunks (Oops[12])
#define com_sun_squawk_util_Tracer__out (Oops[9])
#define java_lang_VM_currentIsolate (Oops[0])
#define java_lang_VM_outOfMemoryError (Oops[15])
#define java_lang_Thread_otherThread (Oops[2])
#define java_lang_ServiceOperation_pendingException (Oops[4])
#define com_sun_squawk_util_Tracer_filter (Oops[10])
#define java_lang_Thread_events (Oops[7])
#define java_lang_Thread_currentThread (Oops[1])
#define com_sun_squawk_util_Tracer__features (Oops[8])
#define ROM_BIG_ENDIAN 0
#define ROM_REVERSE_PARAMETERS 1
#define ROM_GLOBAL_INT_COUNT  42
#define ROM_GLOBAL_OOP_COUNT  16
#define ROM_GLOBAL_ADDR_COUNT 19
