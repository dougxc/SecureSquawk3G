/*
 * Created on 23-Nov-2004
 *
 */
package com.syn.squawk.suiteconverter;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * @author Dave
 *
 */
public class Suite {
   int parentHash;
   String parentURL;
   int rootOffset;
   int memorySize;
   byte[] oopMap;
   byte[] objectMemory;
   int canonicalStart;
   Suite parentSuite = null;
   int outputHeaderSize;
   private int versions;
private int unpaddedHdrSize;
   
   static private final boolean isBigEndian() {
      // ARM target is little endian
      return false;
   }

   public void loadFromStream(DataInputStream dis) throws IOException {
      int magic = dis.readInt();
      if (magic != 0xDEADBEEF) {
      	throw new IOException("Suite file has wrong magic word");
      }
      versions = dis.readInt(); // version
      dis.readInt(); // attributes
      parentHash = dis.readInt();
      parentURL = dis.readUTF();
      rootOffset = dis.readInt();
      memorySize = dis.readInt();
      int oopMapSize = calculateOopMapSizeInBytes(memorySize);
      oopMap = new byte[oopMapSize];
      dis.readFully(oopMap);

      if (hasParent()) {
         parentSuite = new Suite();
         // skip "file://"
         parentSuite.loadFromFile(parentURL.substring(7));
         canonicalStart = parentSuite.getCanonicalEnd();
         unpaddedHdrSize = 24 + 2 + parentURL.length();
         outputHeaderSize = ((unpaddedHdrSize + 3) / 4) * 4; 
      } else {
         outputHeaderSize = 12;
      }
 
      // skip padding
      dis.skipBytes((4 - ((oopMapSize + parentURL.length() + 2) % 4)) % 4);
      objectMemory = new byte[memorySize];
      dis.readFully(objectMemory);      
   }
   
   public void writeToStreamRelocated(DataOutputStream dos, int[] memoryAddrs) throws IOException {
      if (hasParent()) {
		 /*       u4 magic               // 0xDEADBEEF
		 *        u2 minor_version;
		 *        u2 major_version;
		 *        u4 attributes;         // mask of the ATTRIBUTE_* constants in this class
		 *        u4 parent_hash;
		 *        utf8 parent_url;
		 *        u4 root;               // offset (in bytes) in 'memory' of the root of the graph
		 *        u4 size;               // size (in bytes) of memory
		 *        u1 padding[n];         // 0 <= n < HDR.BYTES_PER_WORD to align 'memory' on a word boundary
		 *        u1 memory[size];
		 */
         dos.writeInt(0xDEADBEEF);
         dos.writeInt(versions);
         dos.writeInt(2); // 32 bit
         dos.writeInt(getParent().getHash());
         dos.writeUTF(parentURL);
         dos.writeInt(rootOffset);
         dos.writeInt(memorySize);
         writePad(dos, outputHeaderSize - unpaddedHdrSize);
      } else {
         writeLittleEndianInt(dos, rootOffset + memoryAddrs[0] + outputHeaderSize);
         writeLittleEndianInt(dos, getHash());
         writeLittleEndianInt(dos, memorySize);
      }
      byte[] relocatedMemory = relocateMemory(memoryAddrs);
      dos.write(relocatedMemory);
   }
   
   /**
    * @return
    */
   private int getHash() {
      int hash = objectMemory.length;
      for (int i = 0; i != objectMemory.length; ++i) {
         hash += objectMemory[i];
      }
      return hash;
   }

   /**
    * @param dos
    * @param i
    * @throws IOException
    */
   private void writeLittleEndianInt(DataOutputStream dos, int i) throws IOException {
      dos.write((i >>>  0) & 0xFF);
      dos.write((i >>>  8) & 0xFF);
      dos.write((i >>> 16) & 0xFF);
      dos.write((i >>> 24) & 0xFF);
   }

   /**
    * @param 
 * @throws IOException
    * 
    */
   private void writePad(DataOutputStream dos, int padCount) throws IOException {
      for (int i=0; i < padCount; i++) {
         dos.writeByte(0);
      }
   }

   /**
    * @param memoryAddrs
    * @param headerSize
    * @return
    */
   private byte[] relocateMemory(int[] memoryAddrs) {
      byte[] result = new byte[objectMemory.length];
      System.arraycopy(objectMemory, 0, result, 0, objectMemory.length);
      for (int i=0 ; i < oopMap.length; i++) {
         byte currentByte = oopMap[i];
         for (int j=0 ; j < 8; j++ ) {
            if (((currentByte >> j) & 1) == 1) {
               int index = 4 * ((i * 8) + j);
               int pointer = getObjectMemoryWord(objectMemory, index);
               writeObjectMemoryWord(result, index, this.mapPointer(pointer, memoryAddrs));
            }
         }
      }
      return result;
   }

   /**
    * pointer is canonical. If it points into our memory space, then
    * assume our flash memory base is the first element of parentMemoryAddrs
    * and adjust accordingly. If it doesn't then delegate to our parent, 
    * having stripped our flash memory base from the array.
    * 
    * @param pointer
    * @param parentMemoryAddrs
    * @return
    */
   private int mapPointer(int pointer, int[] memoryAddrs) {
      if (pointer == 0) {
         return 0;
      } else {
         if (pointer < canonicalStart) {
            //map pointer against parent memory address
            int[] parentMemoryAddrs = new int[memoryAddrs.length - 1];
            System.arraycopy(memoryAddrs, 1, parentMemoryAddrs, 0, parentMemoryAddrs.length);
            return getParent().mapPointer(pointer, parentMemoryAddrs);
         } else {
            //map pointer against our memory address
            return memoryAddrs[0] - canonicalStart + pointer + outputHeaderSize;
         }
      }
   }

   /**
    * @param result
    * @param index
    * @param replacementPointer
    */
   private void writeObjectMemoryWord(byte[] memory, int index, int value) {
      if (isBigEndian()) {
         memory[index + 0] = (byte) (value >> 24);
         memory[index + 1] = (byte) (value >> 16);
         memory[index + 2] = (byte) (value >> 8);
         memory[index + 3] = (byte) (value >> 0);
     }
     else {
         memory[index + 0] = (byte) (value >> 0);
         memory[index + 1] = (byte) (value >> 8);
         memory[index + 2] = (byte) (value >> 16);
         memory[index + 3] = (byte) (value >> 24);
     }

   }

   /**
    * @param objectMemory2
    * @param index
    * @return
    */
   static private int getObjectMemoryWord(byte[] memory, int index) {
      int b0 = memory[index + 0] & 0xFF;
      int b1 = memory[index + 1] & 0xFF;
      int b2 = memory[index + 2] & 0xFF;
      int b3 = memory[index + 3] & 0xFF;
      if (isBigEndian()) {
          return (b0<<24) | (b1<<16) | (b2<<8) | b3;
      } else {
          return (b3<<24) | (b2<<16) | (b1<<8) | b0;
      }
   }
   
   /**
    * @return
    * @throws IOException
    */
   private int getCanonicalEnd() {
      return memorySize + canonicalStart;
   }

   /**
    * @return
    */
   private boolean hasParent() {
      return !parentURL.equals("");
   }

   /**
    * @return
    * @throws IOException
    */
   private Suite getParent() {
      return parentSuite;
   }

   /**
    * @param parentURL2
    * @throws IOException
    */
   public void loadFromFile(String parentFilename) throws IOException {
      File inputFile = new File(parentFilename);
      FileInputStream fis = new FileInputStream(inputFile);
      loadFromStream(new DataInputStream(fis));
      fis.close();
   }

   private int calculateOopMapSizeInBytes(int size) {
      return ((size / 4) + 7) / 8;
  }

}
