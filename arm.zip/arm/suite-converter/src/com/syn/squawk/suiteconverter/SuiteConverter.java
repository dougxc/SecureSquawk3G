/*
 * Created on Nov 23, 2004
 *
 */
package com.syn.squawk.suiteconverter;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * @author danielsj
 *
 */
public class SuiteConverter {
   public static void main(String[] args){
      String inputFilename = null;
      String outputFilename = null;
      int[] addresses = null;
      for (int i = 0; i < args.length; i++) {
         switch (args[i].charAt(1)) {
            case 'i':
            case 'I':
               inputFilename=args[i].substring(2);
               break;
            case 'o':
            case 'O':
               outputFilename=args[i].substring(2);
               break;
            case 'a':
            case 'A':
               String addressesString=args[i].substring(2);
               String[] addressStrings = addressesString.split(":");
               addresses = new int[addressStrings.length];
               for (int j = 0; j < addressStrings.length; j++) {
                  addresses[j] = Integer.parseInt(addressStrings[j], 16);
               }
               
               break;
            default:
               System.out.println("Bad argument: " + args[i]);
               usage();
               System.exit(-1);
         }
      }
      if (inputFilename == null || outputFilename == null || addresses == null) {
         usage();
         System.exit(-1);
      }
      try {
         new SuiteConverter().convert(inputFilename, outputFilename, addresses);
      } catch (IOException e) {
         e.printStackTrace();
      }
   }
   
   static private void usage() {
      System.out.println("suite-converter -iInputFile -oOutputFile -aAddress1:Address2:...");
      System.out.println("");
      System.out.println("Each address should be a hex number, 01a0000 style (no leading \"0x\")");
      
   }

	/**
	 * @param inputFile
	 * @param outputFile
	 * @param memoryAddrs
	 * @throws IOException
	 */
	public void convert(String inputFilename, String outputFilename, int[] memoryAddrs) throws IOException {
      Suite suite = new Suite();
      suite.loadFromFile(inputFilename);
      File outputFile = new File(outputFilename);
      FileOutputStream fos = new FileOutputStream(outputFile);
      suite.writeToStreamRelocated(new DataOutputStream(fos), memoryAddrs);
      fos.close();
	}
}
