/*
 * Created on Nov 23, 2004
 *
 */
package com.syn.squawk.suiteconverter.test;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.syn.squawk.suiteconverter.SuiteConverter;

import junit.framework.TestCase;

/**
 * @author danielsj
 *
 */
public class SuiteConverterTests extends TestCase {

	static private int bootHash;

	/**
	 * 
	 */
	public SuiteConverterTests() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public SuiteConverterTests(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public void testBootstrapConversion () throws Exception {
		
		// run the conversion
		System.out.println("running testBootstrapConversion");
		String inputFile = "squawk.suite";
		String outputFile = "bootOut.bin";
		int memoryAddrs[] = new int[] {0x1140000};
		SuiteConverter target = new SuiteConverter();
		target.convert(inputFile, outputFile, memoryAddrs);
		
		// check results
		DataInputStream dis = new DataInputStream(new FileInputStream(new File(outputFile)));
		// bootstrap has these three words in its header:
		//  root offset
		//	hash
		//	memory size
		assertEquals ("Bad offset", 0x1140000 + 0xc + 4, readLittleEndianInt(dis));
		//assertEquals ("Bad hash", getHash(), readLittleEndianInt(dis));
		bootHash = readLittleEndianInt(dis); // skip the hash
		assertEquals ("Bad memory size", 32, readLittleEndianInt(dis));
		
		// check pointer mapping
		assertEquals ("Bad mem[0]", 0x87654321, readLittleEndianInt(dis));
		assertEquals ("Bad mem[1]", 0x01140003 + 0xC, readLittleEndianInt(dis));
		assertEquals ("Bad mem[2]", 0x01234567, readLittleEndianInt(dis));
		assertEquals ("Bad mem[3]", 0x00000000, readLittleEndianInt(dis));
		assertEquals ("Bad mem[4]", 0x00000007, readLittleEndianInt(dis));
		assertEquals ("Bad mem[5]", 0x12345678, readLittleEndianInt(dis));
		assertEquals ("Bad mem[6]", 0xABCDEF01, readLittleEndianInt(dis));
		assertEquals ("Bad mem[7]", 0x11223344, readLittleEndianInt(dis));
		
		assertTrue ("File too long", dis.read() == -1);
	}

	public void testAppConversion () throws Exception {
		// run the conversion
		System.out.println("running testAppConversion");
		String inputFile = "app.suite";
		String outputFile = "appOut.bin";
		int memoryAddrs[] = new int[] {0x11A0000, 0x1140000};
		SuiteConverter target = new SuiteConverter();
		target.convert(inputFile, outputFile, memoryAddrs);
		checkAppResults(outputFile);
	}
		
	protected void checkAppResults(String fileName) throws IOException {
		// check results
		DataInputStream dis = new DataInputStream(new FileInputStream(new File(fileName)));
		assertEquals ("Bad magic", 0xDEADBEEF, dis.readInt());
		assertEquals ("Bad minor", 1, dis.readShort());
		assertEquals ("Bad major", 1, dis.readShort());
		assertEquals ("Bad attrib", 2, dis.readInt()); // no type map
		assertEquals ("Bad hash", bootHash, dis.readInt());
		String parentSuiteName = "file://squawk.suite";
		assertEquals ("Bad hash", parentSuiteName, dis.readUTF());
		int fullHdr = parentSuiteName.length() + 2 + 24; // name + utf count + oopmap
		int pad = (4 - (fullHdr % 4)) % 4;
		fullHdr = fullHdr + pad;
		assertEquals ("Bad root", 4, dis.readInt());
		assertEquals ("Bad memory size", 32, dis.readInt());
		dis.skipBytes(pad);

		// check pointer mapping
		int canonStart = 32;
		int parentHdr = 12;
		assertEquals ("Bad mem[0]", 0x87654321, readLittleEndianInt(dis));
		assertEquals ("Bad mem[1]", 0x011A0000 + fullHdr + 8, readLittleEndianInt(dis)); // pointer to this suite
		assertEquals ("Bad mem[2]", 0x01, readLittleEndianInt(dis));
		assertEquals ("Bad mem[3]", 0x01140000 + parentHdr + 12, readLittleEndianInt(dis)); // pointer to parent 
		assertEquals ("Bad mem[4]", 0x02, readLittleEndianInt(dis));
		assertEquals ("Bad mem[5]", 0x0, readLittleEndianInt(dis));
		assertEquals ("Bad mem[6]", 0x03, readLittleEndianInt(dis));
		assertEquals ("Bad mem[7]", 0x011A0000 + fullHdr + 12, readLittleEndianInt(dis));
		
		assertTrue ("File too long", dis.read() == -1);
	}
   
   public void testMainInterface() throws Exception {
      System.out.println("running testMainInterface");
      String inputFile = "app.suite";
      String outputFile = "appOut.bin";
      String memoryAddrs = "011A0000:01140000";
      SuiteConverter.main(new String[] {"-i" + inputFile, "-o" + outputFile, "-a" + memoryAddrs});
      checkAppResults(outputFile);
   }

    public void setUp() {
    	try {
			createBootInputFile("squawk.suite");
			createAppInputFile("app.suite");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    protected void createBootInputFile (String fileName) throws IOException {
		File outputFile = new File(fileName);
		DataOutputStream dos = new DataOutputStream (new FileOutputStream(outputFile));
		 /*       u4 magic               // 0xDEADBEEF
		 *        u2 minor_version;
		 *        u2 major_version;
		 *        u4 attributes;         // mask of the ATTRIBUTE_* constants in this class
		 *        u4 parent_hash;
		 *        utf8 parent_url;
		 *        u4 root;               // offset (in bytes) in 'memory' of the root of the graph
		 *        u4 size;               // size (in bytes) of memory
		 *        u1 oopmap[((size / HDR.BYTES_PER_WORD) + 7) / 8];
		 *        u1 padding[n];         // 0 <= n < HDR.BYTES_PER_WORD to align 'memory' on a word boundary
		 *        u1 memory[size];
		 *        u1 typemap[size];      // only present if ATTRIBUTE_TYPEMAP is set
		 */
		dos.writeInt(0xDEADBEEF);
		dos.writeShort(0x1);
		dos.writeShort(0x1);
		dos.writeInt(0x3); // has type map; is 32 bit
		dos.writeInt(0); // hash
		String suiteName = "";
		dos.writeUTF(suiteName);
		dos.writeInt(0x4); // root offset in bytes
		dos.writeInt(32);  // 8 words
		//oopmap
		dos.writeByte(0x0A); // 0:N, 1:Y, 2:N, 3:Y, 4:N, 5:N, 6:N, 7:N
		int varHdr = suiteName.length() + 2 + 1; // name + utf count + oopmap
		int pad = (4 - (varHdr % 4)) % 4;
		while (pad > 0) {
			dos.writeByte(0);
			pad--;
		}
		writeLittleEndianInt(dos, 0x87654321); // not a pointer
		writeLittleEndianInt(dos, 0x00000003); // pointer to this suite
		writeLittleEndianInt(dos, 0x01234567); // not a pointer
		writeLittleEndianInt(dos, 0x00000000); // 0 pointer 
		writeLittleEndianInt(dos, 0x00000007); // not a pointer
		writeLittleEndianInt(dos, 0x12345678); // not a pointer
		writeLittleEndianInt(dos, 0xABCDEF01); // not a pointer
		writeLittleEndianInt(dos, 0x11223344); // not a pointer
		
		dos.close();
}

    protected void createAppInputFile (String fileName) throws IOException {
		File outputFile = new File(fileName);
		DataOutputStream dos = new DataOutputStream (new FileOutputStream(outputFile));
		 /*       u4 magic               // 0xDEADBEEF
		 *        u2 minor_version;
		 *        u2 major_version;
		 *        u4 attributes;         // mask of the ATTRIBUTE_* constants in this class
		 *        u4 parent_hash;
		 *        utf8 parent_url;
		 *        u4 root;               // offset (in bytes) in 'memory' of the root of the graph
		 *        u4 size;               // size (in bytes) of memory
		 *        u1 oopmap[((size / HDR.BYTES_PER_WORD) + 7) / 8];
		 *        u1 padding[n];         // 0 <= n < HDR.BYTES_PER_WORD to align 'memory' on a word boundary
		 *        u1 memory[size];
		 *        u1 typemap[size];      // only present if ATTRIBUTE_TYPEMAP is set
		 */
		dos.writeInt(0xDEADBEEF);
		dos.writeShort(0x1);
		dos.writeShort(0x1);
		dos.writeInt(0x3); // has type map; is 32 bit
		dos.writeInt(0x1234); // hash
		String suiteName = "file://squawk.suite";
		dos.writeUTF(suiteName);
		dos.writeInt(0x4); // root offset in bytes
		dos.writeInt(32);  // 8 words
		//oopmap
		dos.writeByte(0xAA); // 0:N, 1:Y, 2:N, 3:Y, 4:N, 5:Y, 6:N, 7:Y
		int varHdr = suiteName.length() + 2 + 1; // name + utf count + oopmap
		int pad = (4 - (varHdr % 4)) % 4;
		while (pad > 0) {
			dos.writeByte(0);
			pad--;
		}
		int canonStart = 32;
		writeLittleEndianInt(dos, 0x87654321); // not a pointer
		writeLittleEndianInt(dos, canonStart + 8); // pointer to this suite
		writeLittleEndianInt(dos, 0x1); // not a pointer
		writeLittleEndianInt(dos, 12); // pointer to parent
		writeLittleEndianInt(dos, 0x2); // not a pointer
		writeLittleEndianInt(dos, 0); // 0 pointer
		writeLittleEndianInt(dos, 0x3); // not a pointer
		writeLittleEndianInt(dos, canonStart + 12); // pointer to this suite
		
		dos.close();
   }

    private int readLittleEndianInt(DataInputStream dis) throws IOException {
        int res = 0;
        res = dis.readByte() & 0xFF;
        res = res + ((dis.readByte() & 0xFF) << 8);
        res = res + ((dis.readByte() & 0xFF) << 16);
        res = res + ((dis.readByte() & 0xFF) << 24);
        return res;
     }

    private void writeLittleEndianInt(DataOutputStream dos, int i) throws IOException {
        dos.write((i >>>  0) & 0xFF);
        dos.write((i >>>  8) & 0xFF);
        dos.write((i >>> 16) & 0xFF);
        dos.write((i >>> 24) & 0xFF);
     }

}
